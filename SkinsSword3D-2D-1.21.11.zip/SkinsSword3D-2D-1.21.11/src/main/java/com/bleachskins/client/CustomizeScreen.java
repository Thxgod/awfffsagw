package com.bleachskins.client;

import com.bleachskins.core.Config;
import com.bleachskins.core.Library;
import com.bleachskins.core.Looks;
import com.bleachskins.core.PackSource;
import com.bleachskins.core.Retexture;
import com.bleachskins.core.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Stream;

/** Re-skin anything in the game: pick a pack's version, a recolour, your own drawing. Applies for you only. */
public class CustomizeScreen extends Screen {
    private static final int TILE_W = 62, TILE_H = 68, GAP = 5;

    private record Btn(int x, int y, int w, int h, Supplier<String> label, Runnable action, boolean main, ItemStack icon) {
        boolean in(double mx, double my) { return mx >= x && my >= y && mx < x + w && my < y + h; }
    }
    private record Tile(String key, String name, String badge, int badgeColor, Supplier<BufferedImage> img, Runnable click, Supplier<Boolean> on, Object live,
                        Supplier<BufferedImage> side, Supplier<BufferedImage> top) {
        Tile(String key, String name, String badge, int badgeColor, Supplier<BufferedImage> img, Runnable click, Supplier<Boolean> on, Object live) {
            this(key, name, badge, badgeColor, img, click, on, live, img, img);
        }
        Tile faces(Supplier<BufferedImage> s, Supplier<BufferedImage> t) { return new Tile(key, name, badge, badgeColor, img, click, on, live, s, t); }
        Tile(String key, String name, String badge, int badgeColor, Supplier<BufferedImage> img, Runnable click, Supplier<Boolean> on) {
            this(key, name, badge, badgeColor, img, click, on, null);
        }
    }

    /** percent setting, steps of 5 */
    private static final class PercentSlider extends net.minecraft.client.gui.components.AbstractSliderButton {
        private final String label; private final int min, max; private final java.util.function.Consumer<Float> set;
        PercentSlider(int x, int y, int w, int h, String label, int max, float cur, java.util.function.Consumer<Float> set) {
            this(x, y, w, h, label, 0, max, cur, set);
        }
        PercentSlider(int x, int y, int w, int h, String label, int min, int max, float cur, java.util.function.Consumer<Float> set) {
            super(x, y, w, h, Component.empty(), (cur * 100.0 - min) / (max - min));
            this.label = label; this.min = min; this.max = max; this.set = set;
            updateMessage();
        }
        private int percent() { return (int) (Math.round((min + value * (max - min)) / 5.0) * 5); }
        @Override protected void updateMessage() {
            setMessage(Component.literal(label + ": " + (percent() == 0 ? ts("off") : percent() + "%")));
        }
        @Override protected void applyValue() {
            set.accept(percent() / 100f);
            SkinManager.cfg.save(SkinManager.cfgFile);
        }
    }

    private final Screen parent;
    private static String section = "crystal";
    private String group = "crystal";            // what the option tiles change; null while browsing textures
    private String search = "";
    private int scroll = 0;
    private String status = "";
    private static final int TOP = 6, TOOLS = 30;
    private long fireChangedAt = 0, cobwebChangedAt = 0;
    private static final int PREVIEW_W = 112;
    private Object preview;
    private boolean picking = false;
    private ColorPicker picker;
    private int customRgb = 0x9B5CFF;
    private final List<Btn> buttons = new ArrayList<>();
    private final List<Tile> tiles = new ArrayList<>();
    private int gx, gy, gw, gh, cols;

    public CustomizeScreen(Screen parent) {
        super(Component.translatable("gui.bleachskins.custom_title"));
        this.parent = parent;
        openSection(section);
    }

    /** open on one section of the sidebar */
    CustomizeScreen at(String s) { openSection(s); return this; }

    /** used by the drawing screen when it comes back */
    CustomizeScreen open(String g) { group = g; return this; }

    private static String ts(String k) { return Component.translatable("gui.bleachskins." + k).getString(); }
    private static Theme th() { return SkinManager.cfg.theme; }

    static Path drawings() { return SkinManager.libDir.getParent().resolve("drawings"); }

    private void openSection(String s) {
        section = s;
        MainScreen.rememberLook(s);
        group = s.startsWith("browse:") ? null : s;
        scroll = 0;
    }

    private String sectionLabel(String s) {
        return ts("look_" + s.replace("browse:", "browse_").replace("/", ""));
    }

    /** the whole picture, or only the first frame when the texture is really animated */
    private static BufferedImage frame(BufferedImage im, boolean animated) {
        return im != null && animated ? com.bleachskins.core.Voxel.firstFrame(im) : im;
    }

    private static Supplier<BufferedImage> vanillaImg(String file) {
        return () -> frame(Retexture.image(VanillaAssets.read("assets/minecraft/textures/" + file + ".png")),
            VanillaAssets.read("assets/minecraft/textures/" + file + ".png.mcmeta") != null);
    }

    private void choose(String g, Config.Choice c) {
        if (c == null) SkinManager.cfg.choices.remove(g); else SkinManager.cfg.choices.put(g, c);
        status = SkinManager.applyLook(g) ? ts("applied") : ts("applied_next");
    }

    private boolean is(String g, String kind, String v) {
        Config.Choice c = SkinManager.cfg.choices.get(g);
        if (c == null) return kind.equals("vanilla");
        return kind.equals(c.kind) && switch (kind) {
            case "pack" -> v.equals(c.pack);
            case "drawn", "shape" -> v.equals(c.drawn);
            case "style" -> v.equals(String.valueOf(c.rgb));
            default -> false;
        };
    }

    private void buildTiles() {
        tiles.clear();
        if (group == null) {
            String prefix = section.substring("browse:".length()), q = search.toLowerCase(Locale.ROOT);
            for (String f : VanillaAssets.textures()) {
                if (!f.startsWith(prefix) || (!q.isEmpty() && !f.contains(q))) continue;
                String g = Looks.SINGLE + f;
                boolean changed = SkinManager.cfg.choices.containsKey(g);
                tiles.add(new Tile("v:" + f, f.substring(f.lastIndexOf('/') + 1), changed ? ts("badge_changed") : "", 0xFF7CFF9B, vanillaImg(f),
                    () -> { group = g; scroll = 0; picking = false; rebuildWidgets(); }, () -> changed, LivePreview.forTexture(f)));
            }
            return;
        }
        final String g = group;
        if ("combat".equals(g)) return;                 // only colours here, they are in the palette
        List<String> files = Looks.files(g);
        if (files.isEmpty()) return;
        String first = Looks.iconFile(g);
        String sideF = sideFile(g), topF = topFile(g);
        tiles.add(new Tile("v:" + first, "Vanilla", "VANILLA", 0xFFAAAAAA, () -> icon(g, vanillaImg(first).get()), () -> choose(g, null), () -> is(g, "vanilla", ""))
            .faces(vanillaImg(sideF), vanillaImg(topF)));
        tiles.add(new Tile(COLOUR, ts("colour_tile"), "", 0, () -> colourImage(g, first), () -> chooseColour(g, colourRgb), () -> currentColour() == colourRgb)
            .faces(() -> tinted(sideF), () -> tinted(topF)));
        if ("plants".equals(g)) tiles.add(new Tile("erase", ts("plants_erase"), "ERASE", 0xFFFF5C5C,
            () -> new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB), () -> {
                Config.Choice c = new Config.Choice(); c.kind = "erase"; choose(g, c);
            }, () -> { Config.Choice c = SkinManager.cfg.choices.get(g); return c != null && "erase".equals(c.kind); }));
        if ("crosshair".equals(g)) for (String shape : Looks.CROSSHAIRS) {
            tiles.add(new Tile("x:" + shape, shape.replace('_', ' '), "SHAPE", 0xFF8FD6FF, () -> Retexture.crosshair(shape, 0xFFFFFF), () -> {
                Config.Choice c = new Config.Choice();
                c.kind = "shape"; c.drawn = shape;
                Config.Choice cur = SkinManager.cfg.choices.get(g);
                c.rgb = cur != null && "shape".equals(cur.kind) ? cur.rgb : 0xFFFFFF;
                choose(g, c);
            }, () -> is(g, "shape", shape)));
        }

        // packs that contain this texture
        List<PackSource> packs = Library.open(SkinManager.libDir);
        for (PackSource p : packs) {
            if (!SkinManager.cfg.enabled(p.slug())) continue;
            boolean has = false;
            String src = null;
            String iconSrc = Looks.find(p, first);
            for (String f : files) { String s = Looks.find(p, f); if (s != null) { has = true; if (src == null) src = s; } }
            boolean ownIcon = iconSrc != null;
            if (ownIcon) src = iconSrc;
            if (!has) continue;
            byte[] data;
            boolean animated = p.exists(src + ".mcmeta");
            try { data = p.read(src); } catch (Exception e) { continue; }
            final String slug = p.slug();
            byte[] sideData = packFace(p, sideF), topData = packFace(p, topF);
            boolean sideAnim = isAnimated(p, sideF), topAnim = isAnimated(p, topF);
            tiles.add(new Tile("p:" + slug + ":" + src, p.name(), "PACK", 0xFF5CE1FF, () -> ownIcon ? skip(g, frame(Retexture.image(data), animated)) : icon(g, frame(Retexture.image(data), animated)), () -> {
                Config.Choice c = new Config.Choice(); c.kind = "pack"; c.pack = slug; choose(g, c);
            }, () -> is(g, "pack", slug))
                .faces(() -> sideData != null ? frame(Retexture.image(sideData), sideAnim) : vanillaImg(sideF).get(),
                       () -> topData != null ? frame(Retexture.image(topData), topAnim) : vanillaImg(topF).get()));
        }
        Library.closeAll(packs);

        // your drawings
        Path dir = drawings().resolve(Retexture.safe(g));
        if (Files.isDirectory(dir)) try (Stream<Path> s = Files.list(dir)) {
            for (Path d : (Iterable<Path>) s.sorted()::iterator) {
                String name = d.getFileName().toString();
                Path img = null;
                for (String f : files) { Path c = d.resolve(Retexture.safe(f) + ".png"); if (Files.isRegularFile(c)) { img = c; break; } }
                if (img == null) continue;
                final Path pic = img;
                tiles.add(new Tile("d:" + pic + ":" + lastModified(pic), name, "DRAWN", 0xFFFFC857, () -> icon(g, frame(readFile(pic), Files.isRegularFile(Path.of(pic + ".mcmeta")))), () -> {
                    Config.Choice c = new Config.Choice(); c.kind = "drawn"; c.drawn = name; choose(g, c);
                }, () -> is(g, "drawn", name))
                    .faces(() -> drawnFace(d, sideF, ff -> vanillaImg(ff).get()), () -> drawnFace(d, topF, ff -> vanillaImg(ff).get())));
            }
        } catch (Exception ignored) {}

    }

    private static long lastModified(Path p) { try { return Files.getLastModifiedTime(p).toMillis(); } catch (Exception e) { return 0; } }
    private static BufferedImage readFile(Path p) { try { return Retexture.image(Files.readAllBytes(p)); } catch (Exception e) { return null; } }

    // ---- the colours, in a palette under the preview
    private static final int SWATCH = 14, SWATCH_GAP = 2;
    private int palX, palY, palW = 0;

    private List<Map.Entry<String, Integer>> palette() {
        List<Map.Entry<String, Integer>> l = new ArrayList<>(Looks.STYLES.entrySet());
        if (group == null) return l;
        int cur = currentColour();
        if (cur >= 0 && !Looks.STYLES.containsValue(cur)) l.add(Map.entry("Custom", cur));
        return l;
    }

    /** the colour this page uses now, -1 for none */
    private int currentColour() {
        if ("combat".equals(group)) return combatSlot == 2 ? SkinManager.cfg.combatHitColour() : SkinManager.cfg.combatReady;
        Config.Choice c = SkinManager.cfg.choices.get(group);
        return c != null && ("style".equals(c.kind) || "shape".equals(c.kind)) ? c.rgb : -1;
    }

    private int swatchAt(double mx, double my) {
        if (palW <= 0 || mx < palX || my < palY) return -1;
        int per = Math.max(1, (palW + SWATCH_GAP) / (SWATCH + SWATCH_GAP));
        int c = (int) (mx - palX) / (SWATCH + SWATCH_GAP), r = (int) (my - palY) / (SWATCH + SWATCH_GAP);
        if (c >= per || (mx - palX) % (SWATCH + SWATCH_GAP) >= SWATCH || (my - palY) % (SWATCH + SWATCH_GAP) >= SWATCH) return -1;
        int i = r * per + c;
        return i < palette().size() ? i : -1;
    }

    private void paintPalette(GuiGraphics g, int mx, int my, Theme t) {
        if (palW <= 0) return;
        List<Map.Entry<String, Integer>> l = palette();
        int per = Math.max(1, (palW + SWATCH_GAP) / (SWATCH + SWATCH_GAP)), cur = currentColour(), hover = picking ? -1 : swatchAt(mx, my);
        for (int i = 0; i < l.size(); i++) {
            int x = palX + (i % per) * (SWATCH + SWATCH_GAP), y = palY + (i / per) * (SWATCH + SWATCH_GAP), rgb = l.get(i).getValue();
            g.fill(x, y, x + SWATCH, y + SWATCH, 0xFF000000 | rgb);
            if (rgb == cur || i == hover) g.renderOutline(x - 1, y - 1, SWATCH + 2, SWATCH + 2, rgb == cur ? 0xFFFFFFFF : t.solid(t.dim));
        }
        int rows = (l.size() + per - 1) / per, ny = palY + rows * (SWATCH + SWATCH_GAP) + 1;
        String n = hover >= 0 ? l.get(hover).getKey() : "";
        if (!n.isEmpty()) g.drawString(font, font.plainSubstrByWidth(n, palW), palX, ny, t.solid(t.text));
    }

    // ---- second altar: the vanilla picture in the colour you are choosing, changes the moment you pick one
    private static final String COLOUR = "colour";
    private int colourRgb = 0x9B5CFF;

    private BufferedImage colourImage(String g, String first) {
        Config.Choice cur = SkinManager.cfg.choices.get(g);
        if ("crosshair".equals(g) && cur != null && "shape".equals(cur.kind)) return Retexture.crosshair(cur.drawn, colourRgb);
        BufferedImage im = vanillaImg(first).get();
        return im == null ? null : icon(g, Retexture.tint(im, colourRgb));
    }

    // ---- how an option turns on its altar
    private static final int FLAT = 0, ITEM = 1, CUBE = 2;
    private static final java.util.Set<String> CUBES = java.util.Set.of("anchor", "glowstone", "obsidian", "tnt", "stone", "deepslate", "grass", "snow");
    private static final java.util.Set<String> FLATS = java.util.Set.of("hearts", "food", "crosshair", "sun", "glint");

    private static int shape(String g) {
        if (g.startsWith(Looks.SINGLE)) {
            String f = g.substring(Looks.SINGLE.length());
            return f.startsWith("block/") ? CUBE : f.startsWith("item/") ? ITEM : FLAT;
        }
        return CUBES.contains(g) ? CUBE : FLATS.contains(g) ? FLAT : ITEM;
    }

    private static String sideFile(String g) {
        List<String> files = Looks.files(g);
        for (String f : files) if (f.contains("side")) return f;
        return files.get(0);
    }

    private static String topFile(String g) {
        for (String f : Looks.files(g)) if (f.endsWith("_top")) return f;
        return sideFile(g);
    }

    private static byte[] packFace(PackSource p, String file) {
        try { String s = Looks.find(p, file); return s == null ? null : p.read(s); } catch (Exception e) { return null; }
    }
    private static boolean isAnimated(PackSource p, String file) {
        try { String s = Looks.find(p, file); return s != null && p.exists(s + ".mcmeta"); } catch (Exception e) { return false; }
    }
    private static BufferedImage drawnFace(Path dir, String file, java.util.function.Function<String, BufferedImage> vanilla) {
        Path f = dir.resolve(Retexture.safe(file) + ".png");
        return Files.isRegularFile(f) ? frame(readFile(f), Files.isRegularFile(Path.of(f + ".mcmeta"))) : vanilla.apply(file);
    }
    private BufferedImage tinted(String file) {
        BufferedImage im = vanillaImg(file).get();
        return im == null ? null : Retexture.tint(im, colourRgb);
    }

    private void tileArt(GuiGraphics g, Tile tile, int x, int y, int size, float phase) {
        if (tile.live != null) { LivePreview.draw(g, tile.live, x, y, size); return; }
        String key = tile.key;
        if (COLOUR.equals(key)) {
            Config.Choice cur = SkinManager.cfg.choices.get(group);
            key = "colour:" + group + ":" + (cur != null ? cur.drawn : "") + ":" + colourRgb;
        }
        switch (shape(group)) {
            case CUBE -> Spin3D.cube(g, key, tile.side, tile.top, "grass".equals(group) && !COLOUR.equals(tile.key) ? 0x91BD59 : 0xFFFFFF, x, y, size, phase);
            case ITEM -> Spin3D.item(g, key, tile.img, x, y, size, phase);
            default -> Thumbs.draw(g, key, tile.img, x, y, size);
        }
    }

    // ---- combat page: a little scene that plays what your settings do
    private int simX, simY, simW, simH;
    private static final float[][] BOX_XZ = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};

    /** one thin quad per line, however long: thousands of little dots cost a lot of frames */
    private static void dots(GuiGraphics g, float x0, float y0, float x1, float y1, int argb) {
        float dx = x1 - x0, dy = y1 - y0, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f) return;
        g.pose().pushMatrix();
        g.pose().mul(new org.joml.Matrix3x2f(dx, dy, -dy / len, dx / len, x0, y0));
        g.fill(0, 0, 1, 1, argb);
        g.pose().popMatrix();
    }

    /** the same turning box the game draws around a mob */
    private static void box(GuiGraphics g, int x, int y, int size, float width, float height, int argb) {
        float big = Math.max(width, height), k = size * 0.72f / big, cx = x + size / 2f, cy = y + size / 2f, hw = width / 2 * k, hh = height / 2 * k;
        double yaw = (System.currentTimeMillis() % 9000L) / 9000.0 * Math.PI * 2;
        float c = (float) Math.cos(yaw), s = (float) Math.sin(yaw), tilt = 0.2f;
        float[] sx = new float[4], sd = new float[4];
        for (int i = 0; i < 4; i++) {
            float bx = BOX_XZ[i][0] * hw, bz = BOX_XZ[i][1] * hw;
            sx[i] = cx + bx * c - bz * s;
            sd[i] = (bx * s + bz * c) * tilt;
        }
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) % 4;
            dots(g, sx[i], cy - hh + sd[i], sx[j], cy - hh + sd[j], argb);
            dots(g, sx[i], cy + hh + sd[i], sx[j], cy + hh + sd[j], argb);
            dots(g, sx[i], cy - hh + sd[i], sx[i], cy + hh + sd[i], argb);
        }
    }

    private static ItemStack simHead;     // made on first use: items are not ready while the game is starting

    private static void simMob(GuiGraphics g, int x, int y, int size) {
        float k = size * 0.72f / 1.95f;
        int cx = x + size / 2, feet = y + size / 2 + Math.round(0.975f * k), body = Math.round(0.3f * k), head = Math.round(0.5f * k);
        int legs = feet - Math.round(0.75f * k), torso = legs - Math.round(0.7f * k);
        g.fill(cx - body / 2 - 1, legs, cx + body / 2 + 1, feet, 0xFF3B3B8F);
        g.fill(cx - body, torso, cx + body, legs, 0xFF00A5A8);
        g.fill(cx - body - body / 2, torso, cx - body, legs, 0xFF5E8F3F);
        g.fill(cx + body, torso, cx + body + body / 2, legs, 0xFF5E8F3F);
        float s = head / 16f * 1.3f;
        g.pose().pushMatrix();
        g.pose().translate(cx, torso - head / 2f);
        g.pose().scale(s, s);
        if (simHead == null) simHead = new ItemStack(net.minecraft.world.item.Items.ZOMBIE_HEAD);
        g.renderItem(simHead, -8, -8);
        g.pose().popMatrix();
    }

    private void paintCombatSim(GuiGraphics g, Theme t) {
        if (simW < 120) return;
        Config c = SkinManager.cfg;
        Ui.rect(g, simX, simY, simW, simH, t.radius(), t.a(t.card));
        g.drawString(font, ts("sim_title"), simX + 6, simY + 5, t.solid(t.dim));
        double p = (System.currentTimeMillis() % 5000L) / 5000.0;
        boolean aim = p >= 0.2 && p < 0.6, hit = p >= 0.6 && p < 0.8;
        int size = Math.max(40, Math.min(90, Math.min(simH - 46, (simW - 12) * 2 / 5))), top = simY + 18;   // small: mobs are drawn again every frame
        int ax = simX + 6, bx = ax + size + 2;
        float width = 0.6f, height = 1.95f;
        simMob(g, ax, top, size);          // simple pictures: a real mob here is drawn again every frame and costs a lot
        simMob(g, bx, top, size);
        g.nextStratum();
        int normal = 0xFFFFFFFF;
        if (c.combatBox) {
            if (aim || hit) box(g, ax, top, size, width, height, 0xFF000000 | CombatBox.shaded(hit ? c.combatHitColour() : c.combatReady));
            else if (c.combatBoxAll) box(g, ax, top, size, width, height, normal);
            if (c.combatBoxAll) box(g, bx, top, size, width, height, normal);
        }
        // the crosshair comes in, stays on the first mob, then moves off
        float cross = aim || hit ? 0f : p < 0.2 ? (float) (1 - p / 0.2) : (float) ((p - 0.8) / 0.2);
        int chx = ax + size / 2 + Math.round(cross * (size + 6)), chy = top + size / 2;
        g.fill(chx - 4, chy, chx + 5, chy + 1, 0xFFFFFFFF);
        g.fill(chx, chy - 4, chx + 1, chy + 5, 0xFFFFFFFF);
        if (hit) g.drawString(font, "!", ax + size / 2 + 8, chy - 10, 0xFFFF5C5C);
        String note = !c.combatBox ? ts("sim_off") : hit ? ts("sim_hit") : aim ? ts("sim_aim") : ts("sim_idle");
        g.drawString(font, font.plainSubstrByWidth(note, simW - 12), simX + 6, top + size + 3, t.solid(t.text));

        // mining: bits fly off the block unless they are turned off
        int mx = bx + size + 8, room = simX + simW - mx;
        if (room >= 40) {
            int bs = Math.min(36, room - 8), by = top + size / 2 - bs / 2;
            Spin3D.cube(g, "v:block/stone", vanillaImg("block/stone"), vanillaImg("block/stone"), 0xFFFFFF, mx, by, bs, 0f);
            if (!c.noBlockParticles) for (int i = 0; i < 7; i++) {
                double q = (System.currentTimeMillis() / 900.0 + i * 0.137) % 1.0;
                int dx = (int) (Math.sin(i * 12.9898) * bs * 0.7 * q), dy = (int) (-bs * 0.35 * q + bs * q * q);
                g.fill(mx + bs / 2 + dx, by + bs / 2 + dy, mx + bs / 2 + dx + 2, by + bs / 2 + dy + 2, 0xFF8A8A8A);
            }
            String m = font.plainSubstrByWidth(ts(c.noBlockParticles ? "sim_nobits" : "sim_bits"), room - 2);
            g.drawString(font, m, mx, by + bs + 4, t.solid(t.dim));
        }
    }

    private boolean hasAltar() { return group != null && !"combat".equals(group); }

    private static BufferedImage swatch(int rgb) {
        BufferedImage im = new BufferedImage(8, 8, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) im.setRGB(x, y, 0xFF000000 | rgb);
        return im;
    }

    /** which colour the combat page sets: 0 aim and hit together, 1 aim only, 2 hit only */
    private int combatSlot = 0;

    private void setCombatColour(int rgb) {
        Config c = SkinManager.cfg;
        if (combatSlot == 0) { c.combatReady = rgb; c.combatHit = -1; }
        else if (combatSlot == 1) { c.combatHit = c.combatHitColour(); c.combatReady = rgb; }   // keeps the hit colour as it looks now
        else c.combatHit = rgb;
        SkinManager.cfg.save(SkinManager.cfgFile);
    }

    /** a colour keeps the crosshair shape you picked; anything else is recoloured */
    private void chooseColour(String g, int rgb) {
        if ("combat".equals(g)) { setCombatColour(rgb); return; }
        colourRgb = rgb;
        altar.select(1);
        Config.Choice cur = SkinManager.cfg.choices.get(g), c = new Config.Choice();
        c.kind = "style"; c.rgb = rgb;
        if ("crosshair".equals(g) && cur != null && "shape".equals(cur.kind)) { c.kind = "shape"; c.drawn = cur.drawn; }
        choose(g, c);
    }

    /** what a whole texture sheet looks like in the game, when it isn't a picture of the thing already */
    private static BufferedImage icon(String g, BufferedImage sheet) {
        if (sheet == null) return null;
        if ("crystal".equals(g) && sheet.getWidth() >= 2 * sheet.getHeight()) return Retexture.crystalIcon(sheet);
        if ("shield".equals(g)) return Retexture.shieldIcon(sheet);
        return sheet;
    }
    private static BufferedImage skip(String g, BufferedImage im) { return "shield".equals(g) ? icon(g, im) : im; }

    private void btn(int x, int y, int w, int h, Supplier<String> label, Runnable action) { buttons.add(new Btn(x, y, w, h, label, action, false, null)); }

    @Override
    protected void init() {
        buttons.clear();
        preview = null;
        int clearW = 84, clearX = width - 10 - 18 - 4 - clearW;
        btn(width - 28, TOP, 18, 18, () -> "X", this::onClose);
        addRenderableWidget(new PercentSlider(clearX, TOP, clearW, 18, ts("ui_clear"), 0, 95, 1f - th().opacity, v -> th().opacity = 1f - v));
        if (parent instanceof MainScreen main) menu.build(main, section, s -> { openSection(s); picking = false; rebuildWidgets(); }, 10, TOP, clearX - 14);
        palW = 0;
        gx = 10; gy = TOOLS + 22; gw = width - gx - 10; gh = height - gy - 34;
        cols = Math.max(1, (gw + GAP) / (TILE_W + GAP));

        if (group == null) {
            EditBox box = new EditBox(font, 10, TOOLS + 2, Math.min(200, gw), 14, Component.empty());
            box.setHint(Component.translatable("gui.bleachskins.custom_search"));
            box.setValue(search);
            box.setResponder(v -> { search = v; scroll = 0; buildTiles(); });
            addRenderableWidget(box);
            int allX = 10 + Math.min(200, gw) + 6;
            addRenderableWidget(new PercentSlider(allX, TOOLS, Math.max(70, Math.min(150, width - 10 - allX)), 18, ts("held_all"), 10, 200, SkinManager.cfg.heldAll, v -> SkinManager.cfg.heldAll = v));
        } else {
            final String g = group;
            int bw = 70, bx = width - 10 - bw;
            if ("fire".equals(g)) {
                int sx = 10 + font.width(sectionLabel(g)) + 8, sw = Math.max(70, Math.min(130, (bx - bw - 12 - sx) / 2));
                addRenderableWidget(new PercentSlider(sx, TOOLS, sw, 18, ts("fire_height"), 100, SkinManager.cfg.fireHeight, v -> SkinManager.cfg.fireHeight = v));
                addRenderableWidget(new PercentSlider(sx + sw + 4, TOOLS, sw, 18, ts("fire_block_height"), 15, 100, SkinManager.cfg.blockFireHeight, v -> {
                    SkinManager.cfg.blockFireHeight = v;
                    fireChangedAt = System.currentTimeMillis();
                }));
            }
            if ("totem".equals(g)) {
                int sx = 10 + font.width(sectionLabel(g)) + 8, sw = Math.max(70, Math.min(150, bx - bw - 4 - 4 - 44 - 4 - sx));
                addRenderableWidget(new PercentSlider(sx, TOOLS, sw, 18, ts("totem_pop"), 300, SkinManager.cfg.totemPopScale, v -> SkinManager.cfg.totemPopScale = v));
                btn(sx + sw + 4, TOOLS, 44, 18, () -> ts("totem_test"), () -> minecraft.gameRenderer.displayItemActivation(new ItemStack(net.minecraft.world.item.Items.TOTEM_OF_UNDYING)));
            }
            if (!"combat".equals(g)) btn(bx, TOOLS, bw, 18, () -> ts(centreDrawing() != null ? "custom_edit" : "custom_draw"), () -> minecraft.setScreen(new DrawScreen(this, g, centreDrawing())));
            preview = group.startsWith(Looks.SINGLE) ? LivePreview.forTexture(group.substring(Looks.SINGLE.length()))
                : "crystal".equals(group) ? LivePreview.forTexture("entity/end_crystal/end_crystal") : LivePreview.forTexture("item/" + Looks.ICONS.getOrDefault(group, ""));
            if ("combat".equals(g)) {
                preview = null;
                Config c = SkinManager.cfg;
                int w = Math.min(170, (gw - 8) / 3), x = gx;
                simX = x + 2 * w + 14; simY = gy; simW = gx + gw - simX; simH = gh;
                btn(x, gy, w, 18, () -> ts(c.combatBox ? "combat_on" : "combat_off"), () -> {
                    c.combatBox = !c.combatBox;
                    CombatBox.setShown(c.combatBox);
                    c.save(SkinManager.cfgFile);
                });
                btn(x + w + 4, gy, w, 18, () -> ts(c.combatBoxAll ? "combat_all" : "combat_only"), () -> { c.combatBoxAll = !c.combatBoxAll; c.save(SkinManager.cfgFile); });
                btn(x, gy + 22, w, 18, () -> ts(c.noBlockParticles ? "mining_fx_off" : "mining_fx_on"), () -> { c.noBlockParticles = !c.noBlockParticles; c.save(SkinManager.cfgFile); });
                btn(x + w + 4, gy + 22, w, 18, () -> ts(combatSlot == 0 ? "combat_slot_both" : combatSlot == 1 ? "combat_slot_aim" : "combat_slot_hit"), () -> combatSlot = (combatSlot + 1) % 3);
                addRenderableWidget(new PercentSlider(x, gy + 44, w, 18, ts("combat_darker"), 0, 70, c.combatDarker, v -> c.combatDarker = v));
                addRenderableWidget(new PercentSlider(x + w + 4, gy + 44, w, 18, ts("combat_width"), 100, 400, c.combatWidth, v -> c.combatWidth = v));
                btn(x, gy + 66, w, 18, () -> ts(c.noExplosionFx ? "explosion_fx_off" : "explosion_fx_on"), () -> { c.noExplosionFx = !c.noExplosionFx; c.save(SkinManager.cfgFile); });
                gy += 90; gh -= 90;
                palX = gx; palY = gy; palW = 2 * w + 4;
            }
            if (preview != null) {
                gw -= PREVIEW_W + 6; cols = Math.max(1, (gw + GAP) / (TILE_W + GAP));
                int px = width - 10 - PREVIEW_W, py = gy + PREVIEW_W + 20;
                String held = preview instanceof ItemStack st ? BuiltInRegistries.ITEM.getKey(st.getItem()).getPath() : Looks.heldItem(g);
                if (Looks.heldItem(g) != null && held != null) {
                    float cur = SkinManager.cfg.heldScale.getOrDefault(held, SkinManager.cfg.heldAll);
                    addRenderableWidget(new PercentSlider(px, py, PREVIEW_W, 18, ts("held_size"), 10, 200, cur, v -> SkinManager.cfg.heldScale.put(held, v)));
                    py += 21;
                }
                if ("cobweb".equals(g)) {
                    addRenderableWidget(new PercentSlider(px, py, PREVIEW_W, 18, ts("cobweb_size"), 100, SkinManager.cfg.cobwebSize, v -> { SkinManager.cfg.cobwebSize = v; cobwebChangedAt = System.currentTimeMillis(); }));
                    py += 21;
                    addRenderableWidget(new PercentSlider(px, py, PREVIEW_W, 18, ts("cobweb_opacity"), 10, 100, SkinManager.cfg.cobwebOpacity, v -> { SkinManager.cfg.cobwebOpacity = v; cobwebChangedAt = System.currentTimeMillis(); }));
                    py += 21;
                    btn(px, py, PREVIEW_W, 18, () -> ts(SkinManager.cfg.cobwebFrame ? "cobweb_frame_on" : "cobweb_frame_off"), () -> {
                        SkinManager.cfg.cobwebFrame = !SkinManager.cfg.cobwebFrame;
                        status = SkinManager.applyLook("cobweb") ? ts("applied") : ts("applied_next");
                        rebuildWidgets();
                    });
                }
                if ("gapple".equals(g)) {
                    addRenderableWidget(new PercentSlider(px, py, PREVIEW_W, 18, ts("eat_shrink"), 5, 100, SkinManager.cfg.eatShrink, v -> SkinManager.cfg.eatShrink = v));
                    py += 21;
                }
                if (!Looks.files(g).isEmpty()) { palX = px; palY = py + 2; palW = PREVIEW_W; }
            }
            if ("crosshair".equals(g)) {
                int sx = 10 + font.width(sectionLabel(g)) + 8, sw = Math.max(70, Math.min(150, bx - bw - 8 - sx));
                addRenderableWidget(new PercentSlider(sx, TOOLS, sw, 18, ts("crosshair_size"), 25, 400, SkinManager.cfg.crosshairScale, v -> SkinManager.cfg.crosshairScale = v));
            }
            btn(bx - bw - 4, TOOLS, bw, 18, () -> ts("custom_color"), () -> {
                picking = !picking;
                picker = new ColorPicker(gx + 4, gy + 4, 120, 96);
                picker.set(customRgb);
                if (picking && hasAltar()) altar.select(1);
            });
            if (section.startsWith("browse:")) btn(bx - 2 * bw - TOOLS, TOOLS, bw, 18, () -> "< " + ts("custom_list"), () -> { group = null; scroll = 0; picking = false; rebuildWidgets(); });
        }
        if (hasAltar()) {
            int ax = gx + gw / 2, uw = Math.min(150, Math.max(70, gw / 3)), ay = gy + gh - 20;
            btn(ax - uw / 2 - 24, ay, 20, 20, () -> "<", () -> altar.step(-1));
            buttons.add(new Btn(ax - uw / 2, ay, uw, 20, () -> ts("equip") + (altar.index < tiles.size() ? ": " + tiles.get(altar.index).name : ""), this::useCentre, true, null));
            btn(ax + uw / 2 + 4, ay, 20, 20, () -> ">", () -> altar.step(1));
            btn(gx, ay, 50, 20, () -> ts(altar.grid ? "altar_view" : "grid_view"), altar::toggleGrid);
            altar.bounds(gx, gy, gw, gh - 24);
        }
        int by = height - 26;
        int w = 84, x = width - 10 - w;
        buttons.add(new Btn(x, by, w, 20, () -> ts("custom_reload"), () -> { SkinManager.applyAndReload(); status = ts("applied"); }, true, null));
        x -= w + 4;
        btn(x, by, w, 20, () -> ts("custom_reset"), this::resetPage);
        x -= w + 4;
        btn(x, by, w, 20, () -> ts("custom_delete"), this::deleteDrawing);
        x -= w + 4;
        btn(x, by, w, 20, () -> ts("open_folder"), () -> net.minecraft.util.Util.getPlatform().openPath(SkinManager.libDir));
        buildTiles();
        altar.sizeScale = new float[] {0.8f, 1f, 1.2f}[th().cardSize];
        altar.count(tiles.size());
        if (hasAltar() && !group.equals(altarFor)) {              // a new page opens on what you are using now
            int use = 0;
            for (int i = 0; i < tiles.size(); i++) if (tiles.get(i).on.get()) { use = i; break; }
            altar.snap(use);
            int now = currentColour();
            colourRgb = now >= 0 ? now : customRgb;
        }
        altarFor = group;
    }

    /** Puts back the defaults of the page you are on, and nothing else. */
    private void resetPage() {
        Config cfg = SkinManager.cfg;
        if (group == null) {                         // a list page: every texture changed in this list, plus the shared hand size
            String prefix = Looks.SINGLE + section.substring("browse:".length());
            for (String g : new ArrayList<>(cfg.choices.keySet())) if (g.startsWith(prefix)) choose(g, null);
            cfg.heldAll = 1f;
        } else {
            String held = preview instanceof ItemStack st ? BuiltInRegistries.ITEM.getKey(st.getItem()).getPath() : Looks.heldItem(group);
            if (held != null) cfg.heldScale.remove(held);
            boolean layer = false;
            switch (group) {
                case "totem" -> cfg.totemPopScale = 1f;
                case "gapple" -> cfg.eatShrink = 0.25f;
                case "crosshair" -> cfg.crosshairScale = 1f;
                case "combat" -> {
                    if (cfg.combatBox) CombatBox.setShown(false);
                    cfg.combatBox = false; cfg.combatBoxAll = true; cfg.combatReady = 0x4CE05A; cfg.combatHit = -1; cfg.noExplosionFx = true; cfg.combatDarker = 0.25f; cfg.combatWidth = 1.6f; cfg.noBlockParticles = false;
                }
                case "fire" -> { cfg.fireHeight = 1f; cfg.blockFireHeight = 1f; fireChangedAt = 0; }
                case "cobweb" -> {
                    layer = cfg.cobwebOpacity < 1f;
                    cfg.cobwebFrame = false; cfg.cobwebSize = 1f; cfg.cobwebOpacity = 1f; cobwebChangedAt = 0;
                }
                default -> { }
            }
            choose(group, null);
            if ("fire".equals(group)) SkinManager.applyLook("soul_fire");   // both fires share the ground height
            if (layer) minecraft.levelRenderer.allChanged();
        }
        cfg.save(SkinManager.cfgFile);
        status = ts("custom_reset_done");
        altarFor = null;
        rebuildWidgets();
    }

    /** the drawing standing in the middle right now, null when the middle one isn't a drawing */
    private String centreDrawing() {
        if (!hasAltar() || altar.index >= tiles.size()) return null;
        Tile t = tiles.get(altar.index);
        return t.key.startsWith("d:") ? t.name : null;
    }

    private void deleteDrawing() {
        if (group == null) return;
        String name = centreDrawing();
        if (name == null) { status = ts("custom_delete_hint"); return; }
        try { com.bleachskins.core.Generator.deleteTree(Retexture.drawing(drawings(), group, name)); } catch (Exception ignored) {}
        Config.Choice c = SkinManager.cfg.choices.get(group);
        if (c != null && "drawn".equals(c.kind) && name.equals(c.drawn)) choose(group, null);
        rebuildWidgets();
    }

    /** low fire is applied just after the slider stops moving */
    @Override
    public void tick() {
        if (cobwebChangedAt != 0 && System.currentTimeMillis() - cobwebChangedAt > 250) {
            cobwebChangedAt = 0;
            status = SkinManager.applyLook("cobweb") ? ts("applied") : ts("applied_next");
            minecraft.levelRenderer.allChanged();                // see-through webs are drawn in another layer
        }
        if (fireChangedAt != 0 && System.currentTimeMillis() - fireChangedAt > 250) {
            fireChangedAt = 0;
            boolean live = SkinManager.applyLook("fire") & SkinManager.applyLook("soul_fire");
            status = live ? ts("applied") : ts("applied_next");
        }
    }

    /** closes the whole menu; the next time it opens on this page */
    @Override public void onClose() {
        SkinManager.cfg.save(SkinManager.cfgFile);
        if (parent instanceof MainScreen main) main.closeAll(); else minecraft.setScreen(parent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        if (menu.clicked(mx, my)) return true;
        if (picking && picker != null) {
            if (picker.pick(mx, my)) return true;
            if (mx >= picker.x && mx < picker.x + picker.w && my >= picker.y + picker.h + 4 && my < picker.y + picker.h + 22) {
                customRgb = picker.rgb();
                chooseColour(group, customRgb); picking = false; buildTiles();
                return true;
            }
        }
        for (Btn b : buttons) if (b.in(mx, my)) { b.action.run(); return true; }
        if (!picking && group != null) {
            int sw = swatchAt(mx, my);
            if (sw >= 0) { chooseColour(group, palette().get(sw).getValue()); return true; }
        }
        if (!picking && hasAltar()) {
            if (altar.press(mx, my)) return true;
            int i = altar.hit(mx, my);
            if (i >= 0) {
                if (altar.grid) { altar.toggleGrid(); altar.snap(i); }     // from the table, straight onto the altar
                else if (i == altar.index) useCentre();
                else altar.select(i);                                      // a side one comes to the middle, the middle one is used
                return true;
            }
        }
        if (!picking && group == null) {
            int i = tileAt(mx, my);
            if (i >= 0) { tiles.get(i).click.run(); return true; }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (picking && picker != null && picker.pick(e.x(), e.y())) return true;
        if (altar.drag(e.x())) return true;
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        altar.release();
        return super.mouseReleased(e);
    }

    private int tileAt(double mx, double my) {
        if (mx < gx || my < gy || mx >= gx + gw || my >= gy + gh) return -1;
        int c = (int) (mx - gx) / (TILE_W + GAP), r = (int) (my - gy + scroll) / (TILE_H + GAP);
        if (c >= cols || (mx - gx) % (TILE_W + GAP) >= TILE_W || (my - gy + scroll) % (TILE_H + GAP) >= TILE_H) return -1;
        int i = r * cols + c;
        return i < tiles.size() ? i : -1;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (group != null) {
            if (hasAltar() && altar.grid) altar.gridWheel(sy);
            else if (hasAltar() && sy != 0) altar.step(sy < 0 ? 1 : -1);
            return true;
        }
        int rows = (tiles.size() + cols - 1) / cols;
        scroll = Math.max(0, Math.min(Math.max(0, rows * (TILE_H + GAP) - gh), scroll - (int) (sy * 30)));
        return true;
    }

    @Override public void renderBackground(GuiGraphics g, int mx, int my, float d) { }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent e) {
        if (hasAltar() && !altar.grid && !(getFocused() instanceof EditBox)) {
            if (e.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT) { altar.step(-1); return true; }
            if (e.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT) { altar.step(1); return true; }
        }
        return super.keyPressed(e);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float d) {
        Theme t = th();
        int acc = t.accentAt(System.currentTimeMillis());
        Thumbs.frame();
        colourBudget = 2;
        if (picking && picker != null && hasAltar()) colourRgb = picker.rgb() & 0xF8F8F8;    // the altar follows the picker
        g.fillGradient(0, 0, width, height, t.a(t.panel), t.a(t.bg));
        g.fill(0, 0, width, TOP + 21, t.a(t.bg));

        for (Btn b : buttons) paint(g, b, mx, my, acc);
        String title = group == null ? sectionLabel(section) : group.startsWith(Looks.SINGLE) ? group.substring(Looks.SINGLE.length()) : sectionLabel(group);
        if (group != null) g.drawString(font, title, 10, TOOLS + 5, t.solid(t.text));

        paintPalette(g, mx, my, t);
        if ("combat".equals(group)) paintCombatSim(g, t);
        if (hasAltar()) altar.paint(g, altarCell(acc), mx, my, t);
        else if (group == null) {
            g.enableScissor(gx, gy, gx + gw, gy + gh);
            int first = scroll / (TILE_H + GAP) * cols;
            for (int i = first; i < tiles.size(); i++) {
                int r = i / cols, x = gx + (i % cols) * (TILE_W + GAP), y = gy + r * (TILE_H + GAP) - scroll;
                if (y >= gy + gh) break;
                paintTile(g, tiles.get(i), x, y, mx, my, acc);
            }
            g.disableScissor();
        }
        if (tiles.isEmpty() && !"combat".equals(group)) g.drawString(font, ts("custom_empty"), gx + 4, gy + 4, t.solid(t.dim));
        if (preview != null) {
            int px = width - 10 - PREVIEW_W;
            Ui.rect(g, px, gy, PREVIEW_W, PREVIEW_W + 16, t.radius(), t.a(t.card));
            Tile using = null;                                      // same sharp picture as the altars
            if (preview instanceof ItemStack && hasAltar()) {
                for (Tile tile : tiles) if (tile.on.get()) { using = tile; break; }
                if (using == null && !tiles.isEmpty()) using = tiles.get(0);
            }
            if (using != null) tileArt(g, using, px + 8, gy + 8, PREVIEW_W - 16, 0f);
            else LivePreview.draw(g, preview, px + 8, gy + 8, PREVIEW_W - 16);
            String note = font.plainSubstrByWidth(ts("custom_live"), PREVIEW_W - 6);
            g.drawString(font, note, px + (PREVIEW_W - font.width(note)) / 2, gy + PREVIEW_W + 3, t.solid(t.dim));
        }

        if (picking && picker != null) {
            g.nextStratum();
            Ui.rect(g, picker.x - 4, picker.y - 4, picker.w + 8, picker.h + 30, t.radius(), 0xF0101018);
            picker.render(g);
            Ui.rect(g, picker.x, picker.y + picker.h + 4, picker.w, 18, t.radius(), 0xFF000000 | picker.rgb());
            g.drawCenteredString(font, Component.translatable("gui.bleachskins.custom_use_color"), picker.x + picker.w / 2, picker.y + picker.h + 9, 0xFFFFFFFF);
        }
        if (!status.isEmpty()) g.drawString(font, status, 10, height - 20, 0xFF7CFF9B);
        super.render(g, mx, my, d);
        menu.paint(g, mx, my, acc, t);
    }

    private final TopMenu menu = new TopMenu();
    private final AltarCarousel altar = new AltarCarousel();
    private String altarFor = null;
    private final Map<String, Integer> tileColours = new java.util.HashMap<>();
    private int colourBudget = 0;

    private int tileColour(Tile tile, int acc) {
        Integer c = tileColours.get(tile.key);
        if (c != null) return c;
        if (colourBudget-- <= 0) return acc;
        int found;
        try { found = AltarCarousel.dominant(tile.img.get(), acc); } catch (Throwable e) { found = acc; }
        tileColours.put(tile.key, found);
        return found;
    }

    private AltarCarousel.Cell altarCell(int acc) {
        return new AltarCarousel.Cell() {
            @Override public void art(GuiGraphics g, int i, int x, int y, int size) {
                tileArt(g, tiles.get(i), x, y, size, i * 0.5f);
            }
            @Override public String name(int i) { return tiles.get(i).name; }
            @Override public int rgb(int i) { return COLOUR.equals(tiles.get(i).key) ? colourRgb : tileColour(tiles.get(i), acc); }
            @Override public boolean inUse(int i) { return tiles.get(i).on.get(); }
        };
    }

    private void useCentre() {
        if (altar.index < tiles.size()) { tiles.get(altar.index).click.run(); }
    }

    private void paint(GuiGraphics g, Btn b, int mx, int my, int acc) {
        Theme t = th();
        boolean hot = b.in(mx, my), sel = false;
        if (b.main) Ui.rect(g, b.x, b.y, b.w, b.h, t.radius(), 0xFF000000 | (hot ? Ui.lighten(t.action, 1.15f) : t.action));
        else Ui.rect(g, b.x, b.y, b.w, b.h, t.radius(), hot ? t.a(t.hot) : t.a(t.card));
        if (b.icon != null) {
            g.renderItem(b.icon, b.x + 1, b.y + 1);
            g.drawString(font, font.plainSubstrByWidth(b.label.get(), b.w - 22), b.x + 20, b.y + 5, t.solid(t.text));
            return;
        }
        String s = font.plainSubstrByWidth(b.label.get(), b.w - 4);
        g.drawString(font, s, b.x + (b.w - font.width(s)) / 2, b.y + (b.h - 8) / 2 + 1, t.solid(t.text));
    }

    private void paintTile(GuiGraphics g, Tile tile, int x, int y, int mx, int my, int acc) {
        Theme t = th();
        boolean on = tile.on.get(), hot = !picking && mx >= x && my >= y && mx < x + TILE_W && my < y + TILE_H && my >= gy && my < gy + gh;
        Ui.rect(g, x, y, TILE_W, TILE_H, t.radius(), hot ? t.a(t.hot) : t.a(t.card));
        if (on) Ui.outline(g, x, y, TILE_W, TILE_H, t.radius(), acc);
        if (tile.live != null) LivePreview.draw(g, tile.live, x + (TILE_W - 40) / 2, y + 4, 40);
        else Thumbs.draw(g, tile.key, tile.img, x + (TILE_W - 40) / 2, y + 4, 40);
        String n = font.plainSubstrByWidth(tile.name, TILE_W - 4);
        g.drawString(font, n, x + (TILE_W - font.width(n)) / 2, y + 47, t.solid(t.text));
        if (!tile.badge.isEmpty()) g.drawString(font, tile.badge, x + (TILE_W - font.width(tile.badge)) / 2, y + 57, tile.badgeColor);
    }
}
