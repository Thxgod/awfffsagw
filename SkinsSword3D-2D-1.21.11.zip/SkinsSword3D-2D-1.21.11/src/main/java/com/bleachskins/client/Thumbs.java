package com.bleachskins.client;

import com.bleachskins.core.Retexture;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/** Small pictures for the tiles: loaded when first shown, oldest dropped after 300. */
final class Thumbs {
    private Thumbs() {}

    private record T(Identifier id, int w, int h) {}
    private static final T NONE = new T(null, 0, 0);
    private static int next = 0, budget = 0;

    private static final Map<String, T> CACHE = new LinkedHashMap<>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, T> e) {
            if (size() <= 300) return false;
            if (e.getValue().id != null) Minecraft.getInstance().getTextureManager().release(e.getValue().id);
            return true;
        }
    };

    /** call once per frame: loading is limited so scrolling stays smooth */
    static void frame() { budget = 6; }

    static void draw(GuiGraphics g, String key, Supplier<BufferedImage> src, int x, int y, int size) {
        T t = CACHE.get(key);
        if (t == null) {
            if (budget-- <= 0) return;
            t = load(src);
            CACHE.put(key, t);
        }
        if (t.id == null) return;
        int w = t.w >= t.h ? size : Math.max(1, size * t.w / t.h), h = t.h >= t.w ? size : Math.max(1, size * t.h / t.w);
        g.blit(RenderPipelines.GUI_TEXTURED, t.id, x + (size - w) / 2, y + (size - h) / 2, 0f, 0f, w, h, t.w, t.h, t.w, t.h, 0xFFFFFFFF);
    }

    /** the picture stretched over a square of `size`, in this colour; the pose gives it its shape */
    static void fill(GuiGraphics g, String key, Supplier<BufferedImage> src, int size, int argb) { fill(g, key, src, size, argb, false); }

    static void fill(GuiGraphics g, String key, Supplier<BufferedImage> src, int size, int argb, boolean mirror) {
        T t = CACHE.get(key);
        if (t == null) {
            if (budget-- <= 0) return;
            t = load(src);
            CACHE.put(key, t);
        }
        if (t.id != null) g.blit(RenderPipelines.GUI_TEXTURED, t.id, 0, 0, mirror ? t.w : 0f, 0f, size, size, mirror ? -t.w : t.w, t.h, t.w, t.h, argb);
    }

    private static T load(Supplier<BufferedImage> src) {
        try {
            BufferedImage im = src.get();
            if (im == null) return NONE;
            NativeImage ni = NativeImage.read(new ByteArrayInputStream(Retexture.png(im)));
            Identifier id = Identifier.fromNamespaceAndPath("bleachskins", "thumb/" + (next++));
            final int n = next;
            Minecraft.getInstance().getTextureManager().register(id, new DynamicTexture(() -> "bleachskins_thumb_" + n, ni));
            return new T(id, ni.getWidth(), ni.getHeight());
        } catch (Throwable e) {
            return NONE;
        }
    }
}
