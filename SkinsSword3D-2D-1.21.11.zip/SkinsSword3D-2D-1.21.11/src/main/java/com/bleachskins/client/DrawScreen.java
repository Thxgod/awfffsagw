package com.bleachskins.client;

import com.bleachskins.core.Config;
import com.bleachskins.core.Looks;
import com.bleachskins.core.Retexture;
import com.bleachskins.core.Theme;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.awt.image.BufferedImage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Pixel editor. Starts from the game's texture; several frames make an animation (items and blocks only). */
public class DrawScreen extends Screen {
    private static final int[] PALETTE = {
        0xFFFFFF, 0xC0C0C0, 0x808080, 0x404040, 0x101010, 0xE0483E, 0xFF8A1F, 0xFFD93B, 0x4CE05A, 0x2EE6D6, 0x3B8CFF, 0x9B5CFF, 0xFF5CD0, 0x8A5A2B
    };
    private static final int PENCIL = 0, ERASE = 1, PICK = 2, FILL = 3;

    /** one texture being edited */
    private static final class Doc {
        final String file; final int w, h; final List<int[]> frames = new ArrayList<>(); int frameTime = 4; boolean touched = false;
        Doc(String file, int w, int h) { this.file = file; this.w = w; this.h = h; }
    }
    private record Btn(int x, int y, int w, int h, Supplier<String> label, Runnable action, BooleanSupplier on) {
        boolean in(double mx, double my) { return mx >= x && my >= y && mx < x + w && my < y + h; }
    }

    private final CustomizeScreen parent;
    private final String group;
    private final String edit;
    private final Map<String, Doc> docs = new HashMap<>();
    private final List<String> files;
    private int fileIndex = 0, frame = 0, tool = PENCIL;
    private boolean mirror = false, showGrid = true;
    private final Deque<int[]> undo = new ArrayDeque<>();
    private final List<Btn> buttons = new ArrayList<>();
    private ColorPicker picker;
    private EditBox nameBox;
    private String name = "";
    private String status = "";
    private int cell = 8, cx, cy;
    private boolean painting = false;
    private static final Identifier CANVAS = Identifier.fromNamespaceAndPath("bleachskins", "draw_canvas");
    private NativeImage canvasImg;
    private DynamicTexture canvasTex;
    private int[] shown;

    /** @param edit name of the drawing to open, or null to start from the game's own texture */
    public DrawScreen(CustomizeScreen parent, String group, String edit) {
        super(Component.translatable("gui.bleachskins.custom_draw"));
        this.parent = parent;
        this.group = group;
        this.files = Looks.files(group);
        this.edit = edit;
        if (edit != null) name = edit;
    }

    private static String ts(String k) { return Component.translatable("gui.bleachskins." + k).getString(); }

    private Doc doc() {
        String f = files.get(fileIndex);
        return docs.computeIfAbsent(f, this::load);
    }

    private Doc load(String f) {
        BufferedImage im = null;
        int savedSpeed = 0;
        if (edit != null) try {
            Path dir = Retexture.drawing(CustomizeScreen.drawings(), group, edit);
            Path png = dir.resolve(Retexture.safe(f) + ".png"), meta = dir.resolve(Retexture.safe(f) + ".png.mcmeta");
            if (Files.isRegularFile(png)) im = Retexture.image(Files.readAllBytes(png));
            if (Files.isRegularFile(meta)) {
                var m = java.util.regex.Pattern.compile("frametime\\D*(\\d+)").matcher(Files.readString(meta));
                if (m.find()) savedSpeed = Integer.parseInt(m.group(1));
            }
        } catch (Exception ignored) {}
        if (im == null) im = Retexture.image(VanillaAssets.read("assets/minecraft/textures/" + f + ".png"));
        if (im == null) { Doc d = new Doc(f, 16, 16); d.frames.add(new int[256]); return d; }
        int w = im.getWidth(), fh = im.getHeight() > w && im.getHeight() % w == 0 ? w : im.getHeight();
        Doc d = new Doc(f, w, fh);
        for (int n = 0; n < im.getHeight() / fh; n++) d.frames.add(im.getRGB(0, n * fh, w, fh, null, 0, w));
        if (savedSpeed > 0) d.frameTime = savedSpeed;
        return d;
    }

    private void btn(int x, int y, int w, int h, Supplier<String> label, BooleanSupplier on, Runnable action) { buttons.add(new Btn(x, y, w, h, label, action, on)); }
    private static final BooleanSupplier OFF = () -> false;

    @Override
    protected void init() {
        buttons.clear();
        int rw = 170, rx = width - rw - 8, hw = (rw - 3) / 2, y = 8;
        Doc d = doc();
        cell = Math.max(1, Math.min((rx - 20) / d.w, (height - 20) / d.h));
        cx = 8 + (rx - 16 - cell * d.w) / 2;
        cy = (height - cell * d.h) / 2;

        if (files.size() > 1) {
            btn(rx, y, rw, 14, () -> files.get(fileIndex).substring(files.get(fileIndex).lastIndexOf('/') + 1), OFF, () -> { fileIndex = (fileIndex + 1) % files.size(); frame = 0; undo.clear(); rebuildWidgets(); });
            y += 17;
        }
        String[] tools = {"draw_pencil", "draw_erase", "draw_pick", "draw_fill"};
        int qw = (rw - 9) / 4;
        for (int i = 0; i < 4; i++) { final int k = i; btn(rx + i * (qw + 3), y, qw, 14, () -> ts(tools[k]), () -> tool == k, () -> tool = k); }
        y += 17;
        btn(rx, y, qw, 14, () -> ts("draw_mirror"), () -> mirror, () -> mirror = !mirror);
        btn(rx + qw + 3, y, qw, 14, () -> ts("draw_grid"), () -> showGrid, () -> showGrid = !showGrid);
        btn(rx + 2 * (qw + 3), y, qw, 14, () -> ts("draw_undo"), OFF, this::popUndo);
        btn(rx + 3 * (qw + 3), y, qw, 14, () -> ts("draw_clear"), OFF, () -> { pushUndo(); java.util.Arrays.fill(cur(), 0); doc().touched = true; });
        y += 18;
        int keep = picker == null ? 0xFFFFFF : picker.rgb();
        picker = new ColorPicker(rx, y, rw, 76);
        picker.set(keep);
        y += 80;
        int ps = rw / PALETTE.length;
        for (int i = 0; i < PALETTE.length; i++) { final int c = PALETTE[i]; final int px = rx + i * ps, py = y; buttons.add(new Btn(px, py, ps - 1, 10, () -> "", () -> picker.set(c), OFF)); }
        y += 13;
        // animation
        btn(rx, y, 16, 14, () -> "<", OFF, () -> { frame = Math.floorMod(frame - 1, doc().frames.size()); undo.clear(); });
        btn(rx + rw - 16, y, 16, 14, () -> ">", OFF, () -> { frame = (frame + 1) % doc().frames.size(); undo.clear(); });
        btn(rx + 18, y, rw - 36, 14, () -> ts("draw_add_frame") + " (" + (frame + 1) + "/" + doc().frames.size() + ")", OFF, () -> {
            doc().frames.add(frame + 1, cur().clone()); frame++; doc().touched = true; undo.clear();
        });
        y += 17;
        btn(rx, y, hw, 14, () -> ts("draw_del_frame"), OFF, () -> {
            if (doc().frames.size() > 1) { doc().frames.remove(frame); frame = Math.min(frame, doc().frames.size() - 1); doc().touched = true; undo.clear(); }
        });
        btn(rx + hw + 3, y, hw, 14, () -> ts("draw_speed") + ": " + doc().frameTime, OFF, () -> doc().frameTime = doc().frameTime >= 20 ? 1 : doc().frameTime + 1);
        y += 18;

        nameBox = new EditBox(font, rx, height - 46, rw, 14, Component.empty());
        nameBox.setMaxLength(24);
        nameBox.setHint(Component.translatable("gui.bleachskins.draw_name"));
        nameBox.setValue(name);
        nameBox.setResponder(v -> name = v);
        addRenderableWidget(nameBox);
        btn(rx, height - 28, hw, 20, () -> ts("draw_save"), OFF, this::save);
        btn(rx + hw + 3, height - 28, hw, 20, () -> ts("draw_cancel"), OFF, this::onClose);
    }

    private int[] cur() { return doc().frames.get(Math.min(frame, doc().frames.size() - 1)); }

    private void pushUndo() { undo.push(cur().clone()); while (undo.size() > 64) undo.removeLast(); }
    private void popUndo() { if (!undo.isEmpty()) { int[] u = undo.pop(); System.arraycopy(u, 0, cur(), 0, u.length); } }

    private void paintAt(double mx, double my, boolean erase) {
        Doc d = doc();
        int px = (int) Math.floor((mx - cx) / cell), py = (int) Math.floor((my - cy) / cell);
        if (px < 0 || py < 0 || px >= d.w || py >= d.h) return;
        int[] a = cur();
        int t = erase ? ERASE : tool;
        if (t == PICK) { int c = a[py * d.w + px]; if ((c >>> 24) != 0) picker.set(c & 0xFFFFFF); tool = PENCIL; return; }
        int color = t == ERASE ? 0 : 0xFF000000 | picker.rgb();
        d.touched = true;
        if (t == FILL) { fill(a, d, px, py, color); return; }
        a[py * d.w + px] = color;
        if (mirror) a[py * d.w + (d.w - 1 - px)] = color;
    }

    private static void fill(int[] a, Doc d, int x, int y, int color) {
        int from = a[y * d.w + x];
        if (from == color) return;
        Deque<int[]> q = new ArrayDeque<>();
        q.add(new int[] {x, y});
        while (!q.isEmpty()) {
            int[] p = q.poll();
            if (p[0] < 0 || p[1] < 0 || p[0] >= d.w || p[1] >= d.h || a[p[1] * d.w + p[0]] != from) continue;
            a[p[1] * d.w + p[0]] = color;
            q.add(new int[] {p[0] + 1, p[1]}); q.add(new int[] {p[0] - 1, p[1]}); q.add(new int[] {p[0], p[1] + 1}); q.add(new int[] {p[0], p[1] - 1});
        }
    }

    private void save() {
        String n = name.trim();
        if (n.isEmpty()) { status = ts("draw_need_name"); return; }
        boolean any = false;
        try {
            Path dir = Retexture.drawing(CustomizeScreen.drawings(), group, n);
            Files.createDirectories(dir);
            for (Doc d : docs.values()) {
                if (!d.touched) continue;
                BufferedImage im = new BufferedImage(d.w, d.h * d.frames.size(), BufferedImage.TYPE_INT_ARGB);
                for (int i = 0; i < d.frames.size(); i++) im.setRGB(0, i * d.h, d.w, d.h, d.frames.get(i), 0, d.w);
                Files.write(dir.resolve(Retexture.safe(d.file) + ".png"), Retexture.png(im));
                Path meta = dir.resolve(Retexture.safe(d.file) + ".png.mcmeta");
                if (d.frames.size() > 1) Files.writeString(meta, "{\"animation\":{\"frametime\":" + d.frameTime + "}}"); else Files.deleteIfExists(meta);
                any = true;
            }
        } catch (Exception e) {
            BleachSkinsClient.LOGGER.warn("Could not save the drawing", e);
            status = ts("draw_failed");
            return;
        }
        // saved under a new name: bring along the parts of the old drawing you didn't touch
        if (edit != null) try {
            Path from = Retexture.drawing(CustomizeScreen.drawings(), group, edit), to = Retexture.drawing(CustomizeScreen.drawings(), group, n);
            if (!from.equals(to) && Files.isDirectory(from)) try (var s = Files.list(from)) {
                for (Path p : (Iterable<Path>) s::iterator) if (!Files.exists(to.resolve(p.getFileName().toString()))) {
                    Files.copy(p, to.resolve(p.getFileName().toString()));
                    any = true;
                }
            }
            if (from.equals(to) && Files.isDirectory(from)) any = true;
        } catch (Exception ignored) {}
        if (!any) { status = ts("draw_nothing"); return; }
        Config.Choice c = new Config.Choice();
        c.kind = "drawn"; c.drawn = Retexture.safe(n);
        SkinManager.cfg.choices.put(group, c);
        SkinManager.applyLook(group);
        minecraft.setScreen(parent.open(group));
    }

    @Override public void onClose() { minecraft.setScreen(parent.open(group)); }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        double mx = e.x(), my = e.y();
        for (Btn b : buttons) if (b.in(mx, my)) { b.action.run(); return true; }
        if (picker.pick(mx, my)) return true;
        Doc d = doc();
        if (mx >= cx && my >= cy && mx < cx + d.w * cell && my < cy + d.h * cell) {
            pushUndo();
            painting = tool != FILL && tool != PICK;
            paintAt(mx, my, e.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT);
            return true;
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (painting) { paintAt(e.x(), e.y(), e.button() == GLFW.GLFW_MOUSE_BUTTON_RIGHT); return true; }
        if (picker.pick(e.x(), e.y())) return true;
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) { painting = false; return super.mouseReleased(e); }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (e.key() == GLFW.GLFW_KEY_Z && (e.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) { popUndo(); return true; }
        return super.keyPressed(e);
    }

    @Override public void renderBackground(GuiGraphics g, int mx, int my, float d) { }

    /** The picture is one texture, refreshed only when a pixel changed (one quad a frame, however big it is). */
    private void syncCanvas(Doc d, int[] a) {
        if (canvasImg == null || canvasImg.getWidth() != d.w || canvasImg.getHeight() != d.h) {
            canvasImg = new NativeImage(d.w, d.h, false);
            canvasTex = new DynamicTexture(() -> "bleachskins_draw_canvas", canvasImg);
            minecraft.getTextureManager().register(CANVAS, canvasTex);
            shown = null;
        }
        if (java.util.Arrays.equals(shown, a)) return;
        shown = a.clone();
        for (int y = 0; y < d.h; y++) for (int x = 0; x < d.w; x++) {
            int c = a[y * d.w + x], k = (c >>> 24);
            int bg = ((x + y) & 1) == 0 ? 0x2A : 0x3A;
            int r = (((c >> 16) & 255) * k + bg * (255 - k)) / 255, gg = (((c >> 8) & 255) * k + bg * (255 - k)) / 255, b = ((c & 255) * k + bg * (255 - k)) / 255;
            canvasImg.setPixel(x, y, 0xFF000000 | (r << 16) | (gg << 8) | b);
        }
        canvasTex.upload();
    }

    @Override
    public void removed() {
        if (canvasTex != null) minecraft.getTextureManager().release(CANVAS);
        canvasTex = null; canvasImg = null; shown = null;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float dl) {
        Theme t = SkinManager.cfg.theme;
        int acc = t.accentAt(System.currentTimeMillis());
        g.fillGradient(0, 0, width, height, t.a(t.panel), t.a(t.bg));
        Doc d = doc();
        int[] a = cur();
        syncCanvas(d, a);
        g.blit(RenderPipelines.GUI_TEXTURED, CANVAS, cx, cy, 0f, 0f, d.w * cell, d.h * cell, d.w, d.h, d.w, d.h, 0xFFFFFFFF);
        if (showGrid && cell >= 4) {
            for (int x = 0; x <= d.w; x++) g.fill(cx + x * cell, cy, cx + x * cell + 1, cy + d.h * cell, 0x30FFFFFF);
            for (int y = 0; y <= d.h; y++) g.fill(cx, cy + y * cell, cx + d.w * cell, cy + y * cell + 1, 0x30FFFFFF);
        }
        picker.render(g);
        for (Btn b : buttons) {
            boolean hot = b.in(mx, my), on = b.on.getAsBoolean();
            String s = b.label.get();
            if (s.isEmpty()) continue;
            Ui.rect(g, b.x, b.y, b.w, b.h, t.radius(), on ? acc : hot ? t.a(t.hot) : t.a(t.card));
            s = font.plainSubstrByWidth(s, b.w - 2);
            g.drawString(font, s, b.x + (b.w - font.width(s)) / 2, b.y + (b.h - 8) / 2 + 1, t.solid(t.text));
        }
        int rw = 170, rx = width - rw - 8, ps = rw / PALETTE.length, py = -1;
        for (Btn b : buttons) if (b.label.get().isEmpty()) { py = b.y; break; }
        if (py >= 0) for (int i = 0; i < PALETTE.length; i++) g.fill(rx + i * ps, py, rx + i * ps + ps - 1, py + 10, 0xFF000000 | PALETTE[i]);
        if (!status.isEmpty()) g.drawString(font, status, rx, height - 58, 0xFFFF9F4A);
        super.render(g, mx, my, dl);
    }
}
