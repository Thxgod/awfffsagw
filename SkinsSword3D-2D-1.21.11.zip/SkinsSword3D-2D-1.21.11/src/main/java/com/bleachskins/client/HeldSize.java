package com.bleachskins.client;

import com.bleachskins.core.Looks;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUseAnimation;

import java.util.HashMap;
import java.util.Map;

/** How big a held item is drawn in first person. */
public final class HeldSize {
    private HeldSize() {}

    public static float of(LivingEntity entity, ItemStack stack, ItemDisplayContext ctx) {
        if (ctx != ItemDisplayContext.FIRST_PERSON_RIGHT_HAND && ctx != ItemDisplayContext.FIRST_PERSON_LEFT_HAND) return 1f;
        if (stack.isEmpty()) return 1f;
        String key = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
        var sizes = SkinManager.cfg.heldScale;
        Float own = sizes.get(key);
        if (own == null && key.equals("enchanted_golden_apple")) own = sizes.get("golden_apple");
        float k = own != null ? own : SkinManager.cfg.heldAll;
        return k * eating(entity, stack);
    }

    private static final Map<String, Identifier> BITES = new HashMap<>();

    /** How far through eating this stack is, 0..1, or -1 when it isn't being eaten. */
    private static float eatProgress(LivingEntity entity, ItemStack stack) {
        if (!entity.isUsingItem() || !ItemStack.isSameItem(stack, entity.getUseItem())) return -1f;
        int total = stack.getUseDuration(entity);
        if (total <= 0) return -1f;
        float partial = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(false);
        return Math.max(0f, Math.min(1f, (total - entity.getUseItemRemainingTicks() + partial) / total));
    }

    /** The bitten model for food you are eating right now, or null. */
    static Identifier biteModel(LivingEntity entity, ItemStack stack) {
        if (stack.getUseAnimation() != ItemUseAnimation.EAT) return null;
        float p = eatProgress(entity, stack);
        int stage = (int) (p * (Looks.BITE_STAGES + 1));
        if (stage < 1) return null;
        String food = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
        if (!Looks.FOODS.containsKey(food)) return null;
        String name = food + "_" + Math.min(stage, Looks.BITE_STAGES);
        return BITES.computeIfAbsent(name, n -> Identifier.fromNamespaceAndPath("bleachskins", "bite/" + n));
    }

    /** shrinks smoothly from full size to the chosen size while the food is being eaten */
    private static float eating(LivingEntity entity, ItemStack stack) {
        float end = SkinManager.cfg.eatShrink;
        if (end >= 1f || !entity.isUsingItem() || !ItemStack.isSameItem(stack, entity.getUseItem())) return 1f;
        ItemUseAnimation anim = stack.getUseAnimation();
        if (anim != ItemUseAnimation.EAT && anim != ItemUseAnimation.DRINK) return 1f;
        float done = eatProgress(entity, stack);
        return done < 0f ? 1f : 1f + (end - 1f) * done;
    }
}
