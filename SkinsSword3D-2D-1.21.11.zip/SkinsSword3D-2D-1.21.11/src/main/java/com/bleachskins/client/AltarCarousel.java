package com.bleachskins.client;

import com.bleachskins.core.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Options in a row: the one in the middle stands on an altar in a beam of light, the picture floats above it. */
final class AltarCarousel {
    interface Cell {
        void art(GuiGraphics g, int i, int x, int y, int size);
        String name(int i);
        int rgb(int i);
        boolean inUse(int i);
        default String tag(int i) { return ""; }
    }

    int index = 0, count = 0;
    float sizeScale = 1f;
    private float pos = 0f;
    private long last = 0;
    private int x, y, w, h;
    /** everything at once as a scrolling table, for long lists */
    boolean grid = false;
    private boolean dragging = false;
    private int gridScroll = 0;
    private static final int CELL_W = 58, CELL_H = 62, CELL_GAP = 4, SCRUB = 8;

    void bounds(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }
    void count(int n) { count = n; index = Math.max(0, Math.min(n - 1, index)); }
    void select(int i) { index = Math.max(0, Math.min(count - 1, i)); }
    void snap(int i) { select(i); pos = index; }
    void step(int d) { select(index + d); }

    void toggleGrid() {
        grid = !grid;
        dragging = false;
        if (grid) gridScroll = Math.max(0, index / gridCols() * (CELL_H + CELL_GAP) - h / 3);
    }

    private int gridCols() { return Math.max(1, (w - 6 + CELL_GAP) / (CELL_W + CELL_GAP)); }
    private int gridMax() { return Math.max(0, (count + gridCols() - 1) / gridCols() * (CELL_H + CELL_GAP) - h); }
    void gridWheel(double amount) { gridScroll = Math.max(0, Math.min(gridMax(), gridScroll - (int) (amount * 40))); }

    // ---- the bar under the altars: drag it to jump anywhere in the list
    private boolean onScrub(double mx, double my) { return !grid && count > 1 && mx >= x && mx < x + w && my >= y + h - SCRUB && my < y + h; }
    private int thumb() { return Math.max(10, w / Math.max(1, count)); }
    private void scrubTo(double mx) {
        float k = (float) ((mx - x - thumb() / 2.0) / Math.max(1, w - thumb()));
        snap(Math.round(Math.max(0f, Math.min(1f, k)) * (count - 1)));
    }
    boolean press(double mx, double my) {
        if (!onScrub(mx, my)) return false;
        dragging = true;
        scrubTo(mx);
        return true;
    }
    boolean drag(double mx) {
        if (!dragging) return false;
        scrubTo(mx);
        return true;
    }
    /** @return true when a drag has just ended */
    boolean release() {
        boolean was = dragging;
        dragging = false;
        return was;
    }

    /** this option stands in the middle right now */
    boolean centred(int i) { return i == index && Math.abs(i - pos) < 0.5f; }

    private int pedestal(int size) { return Math.max(8, size / 4); }
    private int size() {
        int s = (int) (Math.min(h - 48, w / 3) * sizeScale);
        return Math.max(20, Math.min(Math.min(h - 42, 140), s));
    }
    private int base(int size) { return y + h - 13 - SCRUB - pedestal(size); }

    private float offset(float d, int size) {
        float a = Math.abs(d), near = Math.max(size * 0.95f, w * 0.2f), far = Math.max(size * 0.55f, w * 0.11f);
        float o = a <= 1f ? a * near : near + (a - 1f) * far;
        return d < 0 ? -o : o;
    }
    private static float scale(float d) {
        float a = Math.abs(d);
        return a <= 1f ? 1f - 0.3f * a : Math.max(0.4f, 0.7f - 0.08f * (a - 1f));
    }

    private List<Integer> visible(int size) {
        List<Integer> l = new ArrayList<>();
        int c = Math.round(pos);
        for (int i = Math.max(0, c - 9); i <= Math.min(count - 1, c + 9); i++)
            if (Math.abs(offset(i - pos, size)) < w / 2f + size) l.add(i);
        l.sort(Comparator.comparingDouble((Integer i) -> Math.abs(i - pos)));   // nearest first
        return l;
    }

    /** the option under the mouse, -1 for none */
    int hit(double mx, double my) {
        if (count == 0 || mx < x || mx >= x + w || my < y || my >= y + h) return -1;
        if (grid) {
            int cols = gridCols(), c = (int) (mx - x) / (CELL_W + CELL_GAP), r = (int) (my - y + gridScroll) / (CELL_H + CELL_GAP);
            if (c >= cols || (mx - x) % (CELL_W + CELL_GAP) >= CELL_W || (my - y + gridScroll) % (CELL_H + CELL_GAP) >= CELL_H) return -1;
            int i = r * cols + c;
            return i < count ? i : -1;
        }
        if (my >= y + h - SCRUB) return -1;
        int size = size(), base = base(size), cx = x + w / 2;
        for (int i : visible(size)) {
            float d = i - pos;
            int half = (int) (size * scale(d) * 0.55f);
            float sx = cx + offset(d, size);
            if (mx >= sx - half && mx <= sx + half && my >= base - size * scale(d) - 14) return i;
        }
        return -1;
    }

    void paint(GuiGraphics g, Cell cell, int mx, int my, Theme t) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0f : Math.min(0.1f, (now - last) / 1e9f);
        last = now;
        pos += (index - pos) * (1f - (float) Math.exp(-dt * 12f));
        if (Math.abs(index - pos) < 0.002f) pos = index;
        if (count == 0) return;
        if (grid) { paintGrid(g, cell, mx, my, t); return; }

        Font f = Minecraft.getInstance().font;
        int size = size(), base = base(size), cx = x + w / 2, hover = hit(mx, my);
        double time = System.currentTimeMillis() / 1000.0;
        List<Integer> order = visible(size);
        g.enableScissor(x, y, x + w, y + h);
        for (int n = order.size() - 1; n >= 0; n--) {
            int i = order.get(n);
            float d = i - pos, a = Math.abs(d), k = scale(d), focus = Math.max(0f, 1f - a);
            int s = Math.max(12, Math.round(size * k)), px = cx + Math.round(offset(d, size)), rgb = cell.rgb(i) & 0xFFFFFF;
            int bottom = base + Math.round((1f - k) * -2f);
            g.nextStratum();                                  // nearer ones are drawn over farther ones

            // beam of light, stronger in the middle and on the one you point at
            float pulse = 0.85f + 0.15f * (float) Math.sin(time * 2.4 + i);
            float power = (0.28f + 0.72f * focus + (i == hover && focus < 1f ? 0.2f : 0f)) * pulse;
            int top = Math.max(y, bottom - s - s / 2 - 6);
            int[] widths = {Math.round(s * 0.72f), Math.round(s * 0.5f), Math.round(s * 0.28f)};
            float[] alphas = {0.22f, 0.3f, 0.45f};
            for (int b = 0; b < 3; b++) {
                int half = Math.max(1, widths[b] / 2);
                g.fillGradient(px - half, top, px + half, bottom, rgb, Ui.withAlpha(rgb, (int) (255 * alphas[b] * Math.min(1f, power))));
            }
            // sparks rising through the beam
            for (int sp = 0; sp < 3 + Math.round(focus * 3); sp++) {
                double phase = (time * (0.28 + sp * 0.05) + i * 0.37 + sp * 0.31) % 1.0;
                int sx = px + (int) (Math.sin(sp * 12.9898 + i) * s * 0.42);
                int sy = bottom - (int) (phase * (bottom - top));
                int dot = sp % 2 == 0 ? 2 : 1;
                g.fill(sx, sy, sx + dot, sy + dot, Ui.withAlpha(rgb, (int) (220 * (1 - phase) * (0.35f + 0.65f * focus))));
            }
            // the altar: coloured plate on a stone block
            int ph = Math.max(6, Math.round(pedestal(size) * k)), plateW = Math.round(s * 0.86f), stoneW = Math.round(s * 1.08f), plateH = Math.max(2, ph / 3);
            g.fill(px - plateW / 2, bottom, px + plateW / 2, bottom + plateH, 0xFF000000 | rgb);
            g.fill(px - stoneW / 2, bottom + plateH, px + stoneW / 2, bottom + ph, 0xFF3A3A4A);
            g.fill(px - stoneW / 2, bottom + ph - 1, px + stoneW / 2, bottom + ph, 0xFF22222E);

            // the picture, floating
            float bob = (float) Math.sin(time * 2.2 + i * 0.37) * s * 0.05f;
            g.pose().pushMatrix();
            g.pose().translate(0f, bob);
            cell.art(g, i, px - s / 2, bottom - s - Math.max(3, s / 10), s);
            g.pose().popMatrix();

            int textY = bottom + ph + 2;
            int room = focus > 0.5f ? w - 8 : Math.max(20, (int) (Math.max(size * 0.55f, w * 0.11f)) - 2);
            String name = f.plainSubstrByWidth(cell.name(i), room);
            if (textY + 8 <= y + h) g.drawString(f, name, px - f.width(name) / 2, textY, focus > 0.5f ? t.solid(t.text) : Ui.withAlpha(t.dim, 0xBB));
            if (focus > 0.5f) {
                String tag = cell.tag(i);
                if (!tag.isEmpty()) g.drawString(f, tag, px + s / 2 + 3, bottom - 10, 0xFF8FD6FF);
            }
            if (cell.inUse(i)) {
                String use = net.minecraft.network.chat.Component.translatable("gui.bleachskins.in_use").getString();
                if (focus > 0.5f || s > f.width(use)) g.drawString(f, use, px - f.width(use) / 2, Math.max(y + 1, top - 1), 0xFF7CFF9B);
            }
        }
        if (count > 1 && (dragging || onScrub(mx, my))) {       // the bar shows only under the mouse
            g.nextStratum();
            g.fill(x, y + h - 5, x + w, y + h - 1, t.a(t.card));
            int tw = thumb(), tx = x + Math.round(pos / (count - 1) * (w - tw));
            g.fill(tx, y + h - 6, tx + tw, y + h, 0xFFFFFFFF);
        }
        g.disableScissor();
    }

    private void paintGrid(GuiGraphics g, Cell cell, int mx, int my, Theme t) {
        Font f = Minecraft.getInstance().font;
        int cols = gridCols(), hover = hit(mx, my);
        gridScroll = Math.min(gridScroll, gridMax());
        g.nextStratum();
        g.enableScissor(x, y, x + w, y + h);
        for (int i = gridScroll / (CELL_H + CELL_GAP) * cols; i < count; i++) {
            int cx = x + (i % cols) * (CELL_W + CELL_GAP), cy = y + (i / cols) * (CELL_H + CELL_GAP) - gridScroll;
            if (cy >= y + h) break;
            Ui.rect(g, cx, cy, CELL_W, CELL_H, t.radius(), i == hover ? t.a(t.hot) : t.a(t.card));
            if (cell.inUse(i)) Ui.outline(g, cx, cy, CELL_W, CELL_H, t.radius(), 0xFF7CFF9B);
            else if (i == index) Ui.outline(g, cx, cy, CELL_W, CELL_H, t.radius(), 0xFFFFFFFF);
            cell.art(g, i, cx + (CELL_W - 42) / 2, cy + 4, 42);
            String n = f.plainSubstrByWidth(cell.name(i), CELL_W - 4);
            g.drawString(f, n, cx + (CELL_W - f.width(n)) / 2, cy + 50, t.solid(t.text));
        }
        int max = gridMax();
        if (max > 0) {
            int bar = Math.max(12, h * h / (h + max)), by = y + (h - bar) * gridScroll / max;
            g.fill(x + w - 3, by, x + w, by + bar, t.solid(t.dim));
        }
        g.disableScissor();
    }

    /** the colour a picture looks like: bright, saturated pixels count the most */
    static int dominant(BufferedImage im, int fallback) {
        if (im == null) return fallback;
        double r = 0, gr = 0, b = 0, sum = 0;
        int stepX = Math.max(1, im.getWidth() / 32), stepY = Math.max(1, im.getHeight() / 32);
        for (int y = 0; y < im.getHeight(); y += stepY) for (int x = 0; x < im.getWidth(); x += stepX) {
            int p = im.getRGB(x, y);
            if ((p >>> 24) < 128) continue;
            int cr = (p >> 16) & 255, cg = (p >> 8) & 255, cb = p & 255;
            int max = Math.max(cr, Math.max(cg, cb)), min = Math.min(cr, Math.min(cg, cb));
            double w = 0.08 + (max - min) / 255.0 + max / 1020.0;
            r += cr * w; gr += cg * w; b += cb * w; sum += w;
        }
        if (sum == 0) return fallback;
        return ((int) (r / sum) << 16) | ((int) (gr / sum) << 8) | (int) (b / sum);
    }
}
