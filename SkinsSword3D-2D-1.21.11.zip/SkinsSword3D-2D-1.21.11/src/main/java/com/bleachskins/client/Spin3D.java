package com.bleachskins.client;

import net.minecraft.client.gui.GuiGraphics;
import org.joml.Matrix3x2f;

import java.awt.image.BufferedImage;
import java.util.function.Supplier;

/** Turning pictures made from sharp textures alone: a block as a cube, an item as a thin plate. */
final class Spin3D {
    private Spin3D() {}

    private static final int UNIT = 256;
    private static final float TILT = (float) Math.toRadians(28), SIN = (float) Math.sin(TILT), COS = (float) Math.cos(TILT);

    private static float yaw(float phase) { return (float) ((System.currentTimeMillis() % 7000L) / 7000.0 * Math.PI * 2) + phase; }

    private static void face(GuiGraphics g, String key, Supplier<BufferedImage> src, int rgb, float ux, float uy, float vx, float vy, float ox, float oy) {
        face(g, key, src, rgb, false, ux, uy, vx, vy, ox, oy);
    }

    private static void face(GuiGraphics g, String key, Supplier<BufferedImage> src, int rgb, boolean mirror,
                             float ux, float uy, float vx, float vy, float ox, float oy) {
        g.pose().pushMatrix();
        g.pose().mul(new Matrix3x2f(ux / UNIT, uy / UNIT, vx / UNIT, vy / UNIT, ox, oy));
        Thumbs.fill(g, key, src, UNIT, 0xFF000000 | rgb, mirror);
        g.pose().popMatrix();
    }

    private static int shade(int rgb, float k) { return Ui.darken(rgb, k) & 0xFFFFFF; }

    /** @param topTint colour the top is multiplied with (grass is grey in its texture) */
    static void cube(GuiGraphics g, String key, Supplier<BufferedImage> side, Supplier<BufferedImage> top, int topTint, int x, int y, int size, float phase) {
        float a = yaw(phase), half = size * 0.34f, cx = x + size / 2f, cy = y + size / 2f;
        float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
        for (int k = 0; k < 4; k++) {
            double th = k * Math.PI / 2;
            float nx = (float) Math.sin(th), nz = (float) Math.cos(th), tx = nz, tz = -nx;
            float depth = nx * sa + nz * ca;
            if (depth <= 0.001f) continue;
            // the corner at the top left of the texture
            float wx = (nx - tx) * half, wz = (nz - tz) * half;
            float ox = cx + wx * ca - wz * sa, oy = cy + (wx * sa + wz * ca) * SIN - half * COS;
            float ux = 2 * half * (tx * ca - tz * sa), uy = 2 * half * (tx * sa + tz * ca) * SIN;
            face(g, key + ":side", side, shade(0xFFFFFF, 0.6f + 0.4f * depth), ux, uy, 0f, 2 * half * COS, ox, oy);
        }
        float wx = -half, wz = -half;
        float ox = cx + wx * ca - wz * sa, oy = cy + (wx * sa + wz * ca) * SIN - half * COS;
        face(g, key + ":top", top, topTint & 0xFFFFFF, 2 * half * ca, 2 * half * sa * SIN, -2 * half * sa, 2 * half * ca * SIN, ox, oy);
    }

    /** a plate with a little thickness, like an item lying in the world */
    static void item(GuiGraphics g, String key, Supplier<BufferedImage> img, int x, int y, int size, float phase) {
        float a = yaw(phase), ca = (float) Math.cos(a), sa = (float) Math.sin(a), s = size * 0.9f, cx = x + size / 2f, cy = y + size / 2f;
        // the game hides pictures seen from behind, so the back is drawn as a mirrored front
        float wide = Math.max(1f, s * Math.abs(ca));
        boolean back = ca < 0;
        for (int layer = 2; layer >= 0; layer--) {       // darker ones behind, the sharp picture last
            float off = -sa * layer * size * 0.012f * (back ? -1 : 1);
            int rgb = layer == 0 ? 0xFFFFFF : shade(0xFFFFFF, 0.55f + 0.1f * (2 - layer));
            face(g, key, img, rgb, back, wide, 0f, 0f, s, cx - wide / 2 + off, cy - s / 2);
        }
    }
}
