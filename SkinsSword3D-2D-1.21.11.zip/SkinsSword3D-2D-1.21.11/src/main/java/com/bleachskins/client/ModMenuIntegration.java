package com.bleachskins.client;

import com.terraformersmc.modmenu.ModMenu;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import com.terraformersmc.modmenu.util.mod.Mod;

/** Puts a "Configure" button and the "Client" badge on this mod's Mod Menu entry. */
public class ModMenuIntegration implements ModMenuApi {
    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return MainScreen::new;
    }

    /**
     * Mod Menu only gives this badge to mods marked client-only, but this mod also has a server part that relays
     * effects between players, so it has to stay "environment: *". The badge is added by hand instead.
     */
    static void addClientBadge() {
        try {
            Mod mod = ModMenu.MODS.get(BleachSkinsClient.MOD_ID);
            if (mod != null) mod.getBadges().add(Mod.Badge.CLIENT);
        } catch (Throwable t) {
            BleachSkinsClient.LOGGER.debug("Could not add the Mod Menu badge", t);
        }
    }
}
