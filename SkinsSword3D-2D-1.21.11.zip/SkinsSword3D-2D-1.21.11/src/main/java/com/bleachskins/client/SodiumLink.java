package com.bleachskins.client;

import com.bleachskins.core.Config;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;

import java.lang.reflect.Field;

/**
 * Settings that belong to Sodium and Sodium Extra, changed in place when those mods are installed. They are found by name
 * at runtime: the mod needs neither to run, and a version that renamed something only makes the button go away.
 */
final class SodiumLink {
    private SodiumLink() {}

    private static final FabricLoader FABRIC = FabricLoader.getInstance();
    static final boolean SODIUM = FABRIC.isModLoaded("sodium"), EXTRA = FABRIC.isModLoaded("sodium-extra");

    private static Object sodium() throws Exception {
        return Class.forName("net.caffeinemc.mods.sodium.client.SodiumClientMod").getMethod("options").invoke(null);
    }
    private static Object quality() throws Exception {
        Object o = sodium();
        return o.getClass().getField("quality").get(o);
    }
    private static void saveSodium() throws Exception {
        Object o = sodium();
        o.getClass().getMethod("writeToDisk", o.getClass()).invoke(null, o);
    }

    private static Object extra() throws Exception {
        return Class.forName("me.flashyreese.mods.sodiumextra.client.SodiumExtraClientMod").getMethod("options").invoke(null);
    }
    private static Object atmospheric() throws Exception {
        Object o = extra();
        Object render = o.getClass().getField("renderSettings").get(o);
        Object fog = render.getClass().getField("fogSettings").get(render);
        return fog.getClass().getField("atmospheric").get(fog);
    }
    private static void saveExtra() throws Exception {
        Object o = extra();
        o.getClass().getMethod("writeChanges").invoke(o);
    }

    // ---- on/off settings of Sodium
    static boolean hasFlag(String field) {
        if (!SODIUM) return false;
        try { quality().getClass().getField(field); return true; } catch (Throwable t) { return false; }
    }
    static boolean flag(String field) {
        try { Object q = quality(); return q.getClass().getField(field).getBoolean(q); } catch (Throwable t) { return false; }
    }
    static void toggle(String field) {
        try {
            Object q = quality();
            Field f = q.getClass().getField(field);
            f.setBoolean(q, !f.getBoolean(q));
            saveSodium();
            rebuild();
        } catch (Throwable t) { BleachSkinsClient.LOGGER.warn("Sodium setting failed", t); }
    }

    // ---- settings with several values
    private static String name(Object o, String field) throws Exception { return String.valueOf(o.getClass().getField(field).get(o)); }
    private static void next(Object o, String field) throws Exception {
        Field f = o.getClass().getField(field);
        Object[] all = f.getType().getEnumConstants();
        Object now = f.get(o);
        for (int i = 0; i < all.length; i++) if (all[i] == now) { f.set(o, all[(i + 1) % all.length]); return; }
    }

    static boolean hasFilter() { return hasFlag("pixelFilteringMode"); }
    static String filter() { try { return name(quality(), "pixelFilteringMode"); } catch (Throwable t) { return "?"; } }
    static void nextFilter() {
        try { next(quality(), "pixelFilteringMode"); saveSodium(); rebuild(); }
        catch (Throwable t) { BleachSkinsClient.LOGGER.warn("Sodium setting failed", t); }
    }

    static boolean hasFogShape() {
        if (!EXTRA) return false;
        try { atmospheric().getClass().getField("shapeMode"); return true; } catch (Throwable t) { return false; }
    }
    static String fogShape() { try { return name(atmospheric(), "shapeMode"); } catch (Throwable t) { return "?"; } }
    static void nextFogShape() {
        try { next(atmospheric(), "shapeMode"); saveExtra(); }
        catch (Throwable t) { BleachSkinsClient.LOGGER.warn("Sodium Extra setting failed", t); }
    }

    // ---- fog: with Sodium Extra installed, it is the one that handles fog, so the page changes its values
    private static final int EXTRA_OFF = 33;

    static void pushFog(Config c) {
        if (!EXTRA) return;
        try {
            Object a = atmospheric();
            a.getClass().getField("distanceChunks").setInt(a, c.fogOff ? EXTRA_OFF : Math.min(32, c.fogDistance));
            a.getClass().getField("startPercent").setInt(a, Math.round(c.fogStart * 100));
            a.getClass().getField("cloudFogPercent").setInt(a, Math.min(100, Math.round(c.cloudFog * 100)));
            saveExtra();
        } catch (Throwable t) { BleachSkinsClient.LOGGER.warn("Sodium Extra fog failed", t); }
    }

    static void pullFog(Config c) {
        if (!EXTRA) return;
        try {
            Object a = atmospheric();
            int d = a.getClass().getField("distanceChunks").getInt(a);
            c.fogOff = d >= EXTRA_OFF;
            c.fogDistance = d >= EXTRA_OFF ? 0 : d;
            c.fogStart = a.getClass().getField("startPercent").getInt(a) / 100f;
            c.cloudFog = a.getClass().getField("cloudFogPercent").getInt(a) / 100f;
        } catch (Throwable t) { BleachSkinsClient.LOGGER.warn("Sodium Extra fog failed", t); }
    }

    private static void rebuild() { Minecraft.getInstance().levelRenderer.allChanged(); }
}
