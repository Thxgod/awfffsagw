package com.bleachskins.client;

import net.minecraft.client.Minecraft;

import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.nio.file.FileSystemAlreadyExistsException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Stream;

/** Reads the game's own textures straight from its jar (works before the resource system is up). */
public final class VanillaAssets {
    private VanillaAssets() {}

    private static List<String> all;

    public static byte[] read(String path) {
        try (InputStream in = Minecraft.class.getClassLoader().getResourceAsStream(path)) {
            return in == null ? null : in.readAllBytes();
        } catch (Exception e) { return null; }
    }

    /** every texture as "item/diamond", sorted */
    public static List<String> textures() {
        if (all != null) return all;
        List<String> out = new ArrayList<>();
        try {
            URL u = Minecraft.class.getClassLoader().getResource("assets/.mcassetsroot");
            if (u != null) {
                URI uri = u.toURI();
                Path root;
                if ("jar".equals(uri.getScheme())) {
                    try { FileSystems.newFileSystem(uri, new HashMap<>()); } catch (FileSystemAlreadyExistsException ignored) {}
                }
                root = Path.of(uri).getParent().resolve("minecraft/textures");
                try (Stream<Path> s = Files.walk(root)) {
                    s.filter(Files::isRegularFile).forEach(p -> {
                        String r = root.relativize(p).toString().replace('\\', '/');
                        if (r.endsWith(".png")) out.add(r.substring(0, r.length() - 4));
                    });
                }
            }
        } catch (Exception e) {
            BleachSkinsClient.LOGGER.warn("Could not list the game's textures", e);
        }
        Collections.sort(out);
        return all = out;
    }
}
