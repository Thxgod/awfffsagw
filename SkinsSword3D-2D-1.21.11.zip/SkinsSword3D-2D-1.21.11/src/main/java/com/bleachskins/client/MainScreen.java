package com.bleachskins.client;

import com.bleachskins.core.Categories;
import com.bleachskins.core.FxIds;
import com.bleachskins.core.Loadout;
import com.bleachskins.core.Skin;
import com.bleachskins.core.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleFunction;
import java.util.function.Supplier;

/**
 * Main GUI. Everything is painted here with the active Theme (flat squares or "glass": rounded cards, pill tabs,
 * slanted action buttons, optional picture background). The real widgets are fully transparent (alpha 0) and only
 * provide clicks/dragging/typing, so the look is identical in every Minecraft version.
 */
public class MainScreen extends Screen {
    static final String PACKS = "@packs", THEME = "@theme", SKINS = "@skins", EASY = "@easy";
    private static final int[] SWATCHES = {
        0xFF3B3B, 0xFF8A1F, 0xFFD93B, 0x4CE05A, 0x2EE6D6, 0x3B8CFF, 0x9B5CFF, 0xFF5CD0, 0xFFFFFF, 0x202020
    };
    private static final int[] ACTIONS = {0x3FD16A, 0x2E9BD6, 0xE8822A, 0xB05CE0, 0xE0483E, 0xE8E8E8};
    private static final int[] GLOWS = {0x2ECC8F, 0xE8822A, 0x2E9BD6, 0xB05CE0, 0xE0483E};
    private static final String[] MODES = {"static", "rainbow", "pulse"};
    private static final String[] SIZES = {"compact", "normal", "large"};

    // ---- theme shortcuts
    private static Theme th() { return SkinManager.cfg.theme; }
    private static int R() { return th().radius(); }
    private static int BG() { return th().a(th().bg); }
    private static int PANEL() { return th().a(th().panel); }
    private static int CARD() { return th().a(th().card); }
    private static int HOT() { return th().a(th().hot); }
    private static int TEXT() { return th().solid(th().text); }
    private static int DIM() { return th().solid(th().dim); }
    private static boolean glass() { return th().style == 1; }

    private record Rect(int x, int y, int w, int h) {
        boolean in(int mx, int my) { return mx >= x && my >= y && mx < x + w && my < y + h; }
    }
    private record Entry(Loadout lo, Skin skin) {}

    /** painted button; the clickable widget behind it is invisible */
    private static final class PBtn {
        final Rect r; final Supplier<String> label; final int kind; final BooleanSupplier selected; final Button widget; boolean enabled = true;
        PBtn(Rect r, Supplier<String> label, int kind, BooleanSupplier selected, Button widget) { this.r = r; this.label = label; this.kind = kind; this.selected = selected; this.widget = widget; }
        void setEnabled(boolean on) { enabled = on; widget.active = on; }
    }
    // kinds
    private static final int NORMAL = 0, ACTION = 1, PILL = 2, TAB = 3;

    /** slider: logic from the game's slider, picture painted by us */
    private final class Param extends AbstractSliderButton implements Ui.SelfPainted {
        private final double min, max;
        private final Consumer<Double> set;
        private final DoubleFunction<String> fmt;
        private final String label;
        String text = "";

        Param(int x, int y, int w, int h, String label, double min, double max, double cur, DoubleFunction<String> fmt, Consumer<Double> set) {
            super(x, y, w, h, Component.empty(), (cur - min) / (max - min));
            this.min = min; this.max = max; this.set = set; this.fmt = fmt; this.label = label;
            updateMessage();
        }
        private double mapped() { return min + value * (max - min); }
        double frac() { return value; }
        @Override protected void updateMessage() { text = label + ": " + fmt.apply(mapped()); setMessage(Component.literal(text)); }
        @Override protected void applyValue() { set.accept(mapped()); }
    }

    // ---- state
    private final Screen parent;
    private String tab;
    private Loadout work;
    private int sub = 0, tsub = 0;
    private String status = "";
    private boolean leftHand = false;
    private long lastChange = 0;
    private boolean dirty = false;

    private final List<Entry> entries = new ArrayList<>();
    private final List<PBtn> pbtns = new ArrayList<>();
    private final List<Param> params = new ArrayList<>();
    private final List<Rect> swatchRects = new ArrayList<>();
    private final List<Rect> packRows = new ArrayList<>();
    private final List<Rect> presetRects = new ArrayList<>();
    private int panelX, panelW;
    private static final int OX = 8;
    private final TopMenu menu = new TopMenu();
    private final AltarCarousel altar = new AltarCarousel();
    private String altarList = null;
    private static String lastCategory = null;
    private int catScroll = 0;
    private String skinSearch = "";
    private boolean searchFocus = false;
    private Rect viewerRect = new Rect(0, 0, 0, 0);
    private String packFilter = null;    // resource pack shown in the list (slug), null = all
    private int packScroll = 0;          // first pill shown in the pack row
    private int kindFilter = 0;          // skin list: 0 all, 2 = 2D only, 3 = 3D only
    private boolean viewer = false;      // full-screen 3D viewer page
    private int colorTarget = 0;          // colour sub tab edits: 0 blade, 1 effect
    private EditBox nameBox;

    public MainScreen(Screen parent) {
        super(Component.translatable("gui.bleachskins.title"));
        this.parent = parent;
        List<String> cats = SkinManager.categories();
        this.tab = cats.isEmpty() ? PACKS : cats.get(0);
        if (lastTab != null && (cats.contains(lastTab) || lastTab.equals(PACKS) || lastTab.equals(THEME) || lastTab.equals(EASY))) this.tab = lastTab;
        loadWork();
    }

    // ---- the menu opens again on the page you left it on
    private static String lastTab = null, lastLook = null;

    static void rememberLook(String s) { lastLook = s; }

    /** what to show when the menu is opened */
    public Screen startScreen() { return lastLook != null ? new CustomizeScreen(this).at(lastLook) : this; }

    void closeAll() {
        SkinManager.cfg.save(SkinManager.cfgFile);
        net.minecraft.client.Minecraft.getInstance().setScreen(parent);
    }

    private static Component t(String key, Object... a) { return Component.translatable("gui.bleachskins." + key, a); }
    private static String ts(String key, Object... a) { return t(key, a).getString(); }

    // ------------------------------------------------------------ state helpers

    private boolean isSkinTab() { return !tab.equals(PACKS) && !tab.equals(THEME) && !tab.equals(EASY); }

    private String tabLabel(String k) {
        return k.equals(PACKS) ? ts("tab_packs") : k.equals(THEME) ? ts("tab_theme") : Categories.label(k);
    }

    private void loadWork() {
        if (!isSkinTab()) { work = null; return; }
        Loadout act = leftHand ? SkinManager.cfg.activeLeftFor(tab) : SkinManager.cfg.activeFor(tab);
        if (act != null) work = act.copy();
        else {
            work = new Loadout();
            work.category = tab;
            work.name = Categories.label(tab) + (leftHand ? " left" : " skin");
        }
    }

    private void touch() { dirty = true; lastChange = System.currentTimeMillis(); }

    /** Auto-apply: reload shortly after the last edit (a reload is needed to show new tint/length). */
    public void tick() {
        if (reloadTexturesAt != 0 && System.currentTimeMillis() - reloadTexturesAt > 800) {
            reloadTexturesAt = 0;
            SkinManager.quietTextureReload();
        }
        if (dirty && SkinManager.cfg.autoApply && isSkinTab() && work != null && work.skin != null
            && System.currentTimeMillis() - lastChange > 900) {
            dirty = false;
            apply();
        }
    }

    private void selectTab(String k) {
        SkinManager.cfg.save(SkinManager.cfgFile);
        tab = k; status = "";
        lastTab = k; lastLook = null;
        if (isSkinTab()) lastCategory = k;
        loadWork();
        rebuildWidgets();
    }

    private ItemStack preview(String category, String defId) {
        Item item = BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("minecraft", Categories.previewItem(category)));
        ItemStack st = new ItemStack(item);
        st.set(DataComponents.ITEM_MODEL, Identifier.fromNamespaceAndPath("bleachskins", defId));
        return st;
    }

    private String skinName(String key) {
        Skin s = SkinManager.skin(key);
        return s == null ? ts("none") : s.name;
    }

    private int glowOf(Skin s) { return GLOWS[Math.floorMod((s.packSlug + s.name).hashCode(), GLOWS.length)]; }

    // ------------------------------------------------------------ widget helpers

    private PBtn btn(Rect r, Supplier<String> label, int kind, BooleanSupplier sel, Runnable action) {
        Button b = Button.builder(Component.empty(), x -> action.run()).bounds(r.x, r.y, r.w, r.h).build();
        b.setAlpha(0f);
        addRenderableWidget(b);
        PBtn p = new PBtn(r, label, kind, sel, b);
        pbtns.add(p);
        return p;
    }

    private Button area(Rect r, Runnable action) {
        Button b = Button.builder(Component.empty(), x -> action.run()).bounds(r.x, r.y, r.w, r.h).build();
        b.setAlpha(0f);
        return addRenderableWidget(b);
    }

    private Param slider(int x, int y, int w, int h, String label, double min, double max, double cur,
                         DoubleFunction<String> fmt, Consumer<Double> set) {
        Param p = new Param(x, y, w, h, label, min, max, cur, fmt, set);
        p.setAlpha(0f);
        addRenderableWidget(p);
        params.add(p);
        return p;
    }

    private static String pct(double v) { return Math.round(v * 100) + "%"; }

    @Override
    protected void init() {
        entries.clear(); pbtns.clear(); params.clear();
        swatchRects.clear(); packRows.clear(); presetRects.clear();
        panelW = 172;
        panelX = width - panelW - 8;
        if (viewer) { initViewer(); return; }

        int clearW = 84, autoX = width - 26 - 4 - 104, clearX = autoX - 4 - clearW;
        menu.build(this, isSkinTab() ? SKINS : tab, s -> minecraft.setScreen(new CustomizeScreen(this).at(s)), 6, 8, clearX - 10);
        slider(clearX, 8, clearW, 18, ts("ui_clear"), 0, 0.95, 1 - th().opacity, MainScreen::pct, v -> th().opacity = 1f - (float) (Math.round(v * 20) / 20.0));

        if (tab.equals(PACKS)) initPacks(); else if (tab.equals(THEME)) initTheme(); else if (tab.equals(EASY)) initEasy(); else initSkins();

        // auto-apply + close
        btn(new Rect(width - 26 - 4 - 104, 8, 104, 18), () -> ts("auto") + ": " + (SkinManager.cfg.autoApply ? ts("on") : ts("off")),
            PILL, () -> SkinManager.cfg.autoApply, () -> {
                SkinManager.cfg.autoApply = !SkinManager.cfg.autoApply;
                SkinManager.cfg.save(SkinManager.cfgFile);
            });
        btn(new Rect(width - 26, 8, 18, 18), () -> "X", NORMAL, () -> false, this::onClose);
    }

    /** back to the weapons, on the last one you looked at */
    void openSkins() {
        List<String> cats = SkinManager.categories();
        if (cats.isEmpty()) { openTab(PACKS); return; }
        openTab(lastCategory != null && cats.contains(lastCategory) ? lastCategory : cats.get(0));
    }

    /** the top menu opens a page of this screen; it can be pressed from the other screen too */
    void openTab(String k) {
        var mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.screen != this) mc.setScreen(this);
        selectTab(k);
    }

    private static ItemStack iconOf(String item) {
        return new ItemStack(BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("minecraft", item)));
    }

    // ============================================================ skins tab

    private void initSkins() {
        int gx = OX, gy = 92, gw = panelX - 8 - gx, gh = height - gy - 30;
        String[] kinds = {ts("kind_all"), "2D", "3D"};
        int[] kv = {0, 2, 3};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            btn(new Rect(gx + i * 46, 72, 42, 14), () -> kinds[k], PILL, () -> kindFilter == kv[k], () -> { kindFilter = kv[k]; rebuildWidgets(); });
        }

        int sx = gx + 3 * 46 + 4;
        EditBox find = new EditBox(font, sx, 72, Math.max(40, Math.min(160, gx + gw - sx)), 14, Component.empty());
        find.setHint(Component.translatable("gui.bleachskins.custom_search"));
        find.setValue(skinSearch);
        find.setResponder(v -> { skinSearch = v; searchFocus = true; rebuildWidgets(); });
        addRenderableWidget(find);
        if (searchFocus) { setFocused(find); searchFocus = false; }

        // ---- pick a resource pack, then only the weapons that pack has
        initPackRow(gx, 36, gw);
        initCategoryRow(gx, 54, gw);

        List<Skin> shown = new ArrayList<>();
        for (Skin s : SkinManager.skinsOf(tab)) if ((kindFilter == 0 || s.kind == kindFilter) && inPack(s)) shown.add(s);
        shown.sort(java.util.Comparator.comparing((Skin s) -> s.packSlug).thenComparingInt(s -> s.kind).thenComparing(s -> s.name));
        for (Skin s : shown) entries.add(new Entry(null, s));
        if (kindFilter == 0 && skinSearch.isBlank()) entries.add(0, new Entry(null, null));   // "no skin"

        altar.bounds(gx, gy, gw, gh);
        altar.sizeScale = new float[] {0.8f, 1f, 1.2f}[th().cardSize];
        altar.count(entries.size());
        String list = tab + "|" + kindFilter + "|" + packFilter + "|" + skinSearch + "|" + leftHand;
        if (!list.equals(altarList)) {                 // a new list opens on the skin you are working on
            int at = 0;
            for (int i = 0; i < entries.size(); i++) if (isWork(entries.get(i))) { at = i; break; }
            altar.snap(at);
            altarList = list;
        }

        int by = height - 24;
        btn(new Rect(gx, by, 22, 16), () -> "<", NORMAL, () -> false, () -> moveTo(altar.index - 1));
        btn(new Rect(gx + 26, by, 22, 16), () -> ">", NORMAL, () -> false, () -> moveTo(altar.index + 1));
        btn(new Rect(gx + 52, by, 44, 16), () -> ts(altar.grid ? "altar_view" : "grid_view"), NORMAL, () -> altar.grid, altar::toggleGrid);

        // ---- right panel: sub tabs, preview well, name, page content, buttons
        int x = panelX + 6, w = panelW - 12;
        String[] subs = {ts("sub_look"), ts("sub_color"), ts("sub_fx"), ts("sub_sound")};
        int sw = (w - 9) / 4;
        for (int i = 0; i < 4; i++) {
            final int k = i;
            btn(new Rect(x + i * (sw + 3), 38, sw, 14), () -> subs[k], PILL, () -> sub == k, () -> { sub = k; rebuildWidgets(); });
        }
        btn(new Rect(x + 4, 58, 28, 12), () -> leftHand ? "L" : "R", PILL, () -> leftHand, () -> { leftHand = !leftHand; loadWork(); rebuildWidgets(); });
        area(new Rect(x + w - 34, 56, 34, 14), () -> { viewer = true; Viewer3D.BIG.resetView(); rebuildWidgets(); }); // click the preview = big 3D viewer

        nameBox = new EditBox(font, x, 84, w, 14, Component.empty());
        nameBox.setMaxLength(24);
        nameBox.setValue(work.name);
        nameBox.setResponder(v -> work.name = v);
        addRenderableWidget(nameBox);

        int y = 104;
        if (sub == 0) {
            btn(new Rect(x, y, w, 16), () -> ts("overlay") + ": " + skinName(work.overlay), NORMAL, () -> false, () -> { cycleOverlay(); touch(); });
            y += 20;
            slider(x, y, w, 14, ts("length"), 0.5, 2.0, work.length, MainScreen::pct, v -> { work.length = (float) (Math.round(v * 20) / 20.0); touch(); });
            y += 18;
            slider(x, y, w, 14, ts("width"), 0.5, 2.0, work.width, MainScreen::pct, v -> { work.width = (float) (Math.round(v * 20) / 20.0); touch(); });
            y += 18;
            slider(x, y, w, 14, ts("depth3d"), 0, 6, work.depth, v -> v < 0.25 ? ts("off") : String.format(Locale.ROOT, "%.1f", v),
                v -> { work.depth = (float) (Math.round(v * 2) / 2.0); touch(); });
        } else if (sub == 1) {
            btn(new Rect(x, y, w, 16), () -> ts("color_for") + ": " + (colorTarget == 0 ? ts("blade") : ts("effect")), NORMAL, () -> false,
                () -> { colorTarget = 1 - colorTarget; rebuildWidgets(); });
            y += 20;
            int sws = (w - 2) / (SWATCHES.length + 1);
            for (int i = 0; i < SWATCHES.length; i++) {
                Rect r = new Rect(x + i * sws, y, sws - 2, 12);
                swatchRects.add(r);
                int c = SWATCHES[i];
                area(r, () -> { setTargetColor(c); touch(); rebuildWidgets(); });
            }
            Rect none = new Rect(x + SWATCHES.length * sws, y, sws - 2, 12);
            swatchRects.add(none);
            area(none, () -> { setTargetColor(-1); touch(); rebuildWidgets(); });
            y += 18;
            int c0 = targetColor();
            int cur = c0 >= 0 ? c0 : 0xFFFFFF;
            int[] shift = {16, 8, 0};
            String[] nm = {"R", "G", "B"};
            for (int i = 0; i < 3; i++) {
                final int sh = shift[i];
                slider(x, y, w, 14, nm[i], 0, 255, (cur >> sh) & 0xFF, v -> String.valueOf(Math.round(v)), v -> {
                    int c = targetColor() >= 0 ? targetColor() : 0xFFFFFF;
                    setTargetColor((c & ~(0xFF << sh)) | ((int) Math.round(v) << sh));
                    touch();
                });
                y += 17;
            }
        } else if (sub == 2) {
            btn(new Rect(x, y, w, 16), () -> ts("effect") + ": " + ts("fx_" + work.particle), NORMAL, () -> false, () -> { cycleFx(); touch(); });
            y += 20;
            slider(x, y, w, 14, ts("density"), 1, 8, work.rate, v -> String.valueOf(Math.round(v)), v -> { work.rate = (int) Math.round(v); touch(); });
            y += 18;
            slider(x, y, w, 14, ts("fx_size"), 0.5, 3.0, work.fxSize, MainScreen::pct, v -> { work.fxSize = (float) (Math.round(v * 10) / 10.0); touch(); });
            y += 18;
            btn(new Rect(x, y, w, 16), () -> ts("swing") + ": " + ts("swing_" + work.swing), NORMAL, () -> false, () -> { cycleSwing(); touch(); });
            y += 20;
            btn(new Rect(x, y, w, 16), () -> ts("fx_color_hint"), NORMAL, () -> false, () -> { sub = 1; colorTarget = 1; rebuildWidgets(); });
        } else {
            btn(new Rect(x, y, w, 16), () -> ts("sound") + ": " + ts("snd_" + work.sound), NORMAL, () -> false, () -> { cycleSound(); touch(); });
            y += 20;
            slider(x, y, w, 14, ts("volume"), 0, 1, work.volume, MainScreen::pct, v -> { work.volume = (float) (Math.round(v * 20) / 20.0); touch(); });
            y += 18;
            slider(x, y, w, 14, ts("pitch"), 0.5, 2.0, work.pitch, MainScreen::pct, v -> { work.pitch = (float) (Math.round(v * 20) / 20.0); touch(); });
            y += 18;
            btn(new Rect(x, y, w, 16), () -> ts("test_sound"), ACTION, () -> false,
                () -> Fx.playSound(minecraft, minecraft.player, Fx.specOf(work), 1f));
        }

        int bottom = height - 46;
        btn(new Rect(x, bottom, w, 20), () -> ts("equip"), ACTION, () -> false, this::apply);
        btn(new Rect(x, bottom + 23, w, 16), () -> ts("default"), NORMAL, () -> false, () -> { clearActive(); loadWork(); rebuildWidgets(); });
    }

    private boolean isWork(Entry e) {
        return e.skin != null && e.skin.key().equals(work.skin);
    }

    /** bring an option to the middle and show it in the side panel; nothing changes in the game yet */
    private void moveTo(int i) {
        altar.select(i);
        if (altar.index >= entries.size()) return;
        Entry e = entries.get(altar.index);
        if (e.lo != null) work = e.lo.copy();
        else if (e.skin != null) work.skin = e.skin.key();
        rebuildWidgets();
    }

    /** pressing the option in the middle puts it to use */
    private void useCentre() {
        if (altar.index >= entries.size()) return;
        Entry e = entries.get(altar.index);
        if (e.lo == null && e.skin == null) { clearActive(); loadWork(); status = ts("no_skin_set"); rebuildWidgets(); return; }
        apply();
    }

    private ItemStack entryStack(Entry e) {
        if (e.lo != null) return SkinManager.loaded(e.lo) ? preview(e.lo.category, SkinManager.defId(e.lo)) : preview(e.lo.category, SkinManager.skin(e.lo.skin).previewId());
        if (e.skin != null) return preview(e.skin.category, e.skin.previewId());
        return iconOf(Categories.previewItem(tab));
    }

    private AltarCarousel.Cell altarCell(int acc) {
        Loadout act = SkinManager.cfg.activeFor(tab), actL = SkinManager.cfg.activeLeftFor(tab);
        return new AltarCarousel.Cell() {
            @Override public void art(GuiGraphics g, int i, int x, int y, int size) {
                Entry e = entries.get(i);
                Skin shown = e.lo != null ? SkinManager.skin(e.lo.skin) : e.skin;
                if (altar.centred(i) && shown != null && shown.key().equals(work.skin)) {     // the one in the middle turns around in 3D
                    Viewer3D.SMALL.sync(work);
                    int big = Math.round(size * 1.25f), off = (big - size) / 2;
                    if (Viewer3D.SMALL.draw(g, x - off, y - off, big, false, 0, 0)) return;
                } else if (shown != null) {                                                    // and so do all the others
                    Loadout l = e.lo;
                    if (l == null) { l = new Loadout(); l.skin = shown.key(); }
                    int big = Math.round(size * 1.25f), off = (big - size) / 2;
                    if (Viewer3D.drawPooled(g, e.lo != null ? "l:" + e.lo.id : "s:" + shown.key(), l, x - off, y - off, big)) return;
                }
                float k = size / 16f;
                g.pose().pushMatrix();
                g.pose().translate(x + size / 2f, y + size / 2f);
                g.pose().scale(k, k);
                g.renderItem(entryStack(entries.get(i)), -8, -8);
                g.pose().popMatrix();
            }
            @Override public String name(int i) {
                Entry e = entries.get(i);
                return e.lo != null ? "★ " + e.lo.name : e.skin != null ? e.skin.name : ts("no_skin");
            }
            @Override public int rgb(int i) {
                Entry e = entries.get(i);
                return e.skin != null ? glowOf(e.skin) : acc;
            }
            @Override public boolean inUse(int i) {
                Entry e = entries.get(i);
                Loadout using = leftHand ? actL : act;                  // only the skin in this hand, on its own card
                if (e.skin == null) return using == null;
                return using != null && e.skin.key().equals(using.skin);
            }
            @Override public String tag(int i) {
                Entry e = entries.get(i);
                Skin k = e.skin != null ? e.skin : e.lo != null ? SkinManager.skin(e.lo.skin) : null;
                return k == null ? "" : k.kind == 2 ? "2D" : "3D";
            }
        };
    }

    @Override
    public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent e, boolean dbl) {
        if (!viewer) {
            if (menu.clicked(e.x(), e.y())) return true;
            if (isSkinTab()) {
                if (altar.press(e.x(), e.y())) return true;
                int i = altar.hit(e.x(), e.y());
                if (i >= 0) {
                    if (altar.grid) { altar.toggleGrid(); altar.snap(i); moveTo(i); }   // from the table, straight onto the altar
                    else if (i == altar.index) useCentre();
                    else moveTo(i);
                    return true;
                }
            }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent e, double dx, double dy) {
        if (altar.drag(e.x())) return true;
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent e) {
        if (altar.release()) { moveTo(altar.index); return true; }   // the side panel follows when you let go
        return super.mouseReleased(e);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyEvent e) {
        if (!viewer && isSkinTab() && !altar.grid && !(getFocused() instanceof EditBox)) {
            if (e.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT) { moveTo(altar.index - 1); return true; }
            if (e.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT) { moveTo(altar.index + 1); return true; }
        }
        return super.keyPressed(e);
    }

    private boolean inPack(Skin s) {
        return (packFilter == null || packFilter.equals(s.packSlug))
            && (skinSearch.isBlank() || s.name.toLowerCase(Locale.ROOT).contains(skinSearch.trim().toLowerCase(Locale.ROOT)));
    }

    private boolean packHas(String slug, String category) {
        for (Skin s : SkinManager.skinsOf(category)) if (s.packSlug.equals(slug)) return true;
        return false;
    }

    /** One row of pills, one per resource pack. "<" and ">" appear when the packs don't fit on one row. */
    private void initPackRow(int x, int y, int w) {
        List<String> keys = new ArrayList<>();
        List<String> names = new ArrayList<>();
        java.util.LinkedHashMap<String, String> packNames = new java.util.LinkedHashMap<>();
        java.util.Map<String, Integer> counts = new java.util.HashMap<>();
        for (String c : SkinManager.categories()) for (Skin s : SkinManager.skinsOf(c)) { packNames.putIfAbsent(s.packSlug, s.packName); counts.merge(s.packSlug, 1, Integer::sum); }
        for (var pe : packNames.entrySet()) {
            keys.add(pe.getKey());
            names.add(font.plainSubstrByWidth(pe.getValue(), 96) + " (" + counts.get(pe.getKey()) + ")");
        }
        if (keys.isEmpty()) return;
        if (!keys.contains(packFilter) || !packHas(packFilter, tab)) {       // stay on a pack that has this weapon
            packFilter = keys.get(0);
            for (String k : keys) if (packHas(k, tab)) { packFilter = k; break; }
        }

        int total = -3;
        for (String n : names) total += font.width(n) + 14 + 3;
        boolean scroll = total > w;
        int left = scroll ? x + 18 : x, right = scroll ? x + w - 18 : x + w;
        int selected = keys.indexOf(packFilter);
        packScroll = Mth.clamp(packScroll, 0, keys.size() - 1);
        if (selected < packScroll) packScroll = selected;
        while (scroll && selected > lastFitting(names, packScroll, right - left)) packScroll++;
        int last = scroll ? lastFitting(names, packScroll, right - left) : keys.size() - 1;

        int px = left;
        for (int i = packScroll; i <= last; i++) {
            final String key = keys.get(i), name = names.get(i);
            int pw = font.width(name) + 14;
            btn(new Rect(px, y, pw, 14), () -> name, PILL, () -> java.util.Objects.equals(key, packFilter), () -> {
                packFilter = key;
                if (packHas(key, tab)) { rebuildWidgets(); return; }
                for (String c : SkinManager.categories()) if (packHas(key, c)) { selectTab(c); return; }
            });
            px += pw + 3;
        }
        if (scroll) {
            btn(new Rect(x, y, 16, 14), () -> "<", PILL, () -> false, () -> { packScroll--; rebuildWidgets(); }).setEnabled(packScroll > 0);
            btn(new Rect(x + w - 16, y, 16, 14), () -> ">", PILL, () -> false, () -> { packScroll++; rebuildWidgets(); }).setEnabled(last < keys.size() - 1);
        }
    }

    /** the weapons of the chosen pack */
    private void initCategoryRow(int x, int y, int w) {
        List<String> keys = new ArrayList<>(), names = new ArrayList<>();
        for (String c : SkinManager.categories()) if (packHas(packFilter, c)) { keys.add(c); names.add(Categories.label(c)); }
        if (keys.isEmpty()) return;
        int total = -3;
        for (String n : names) total += font.width(n) + 14 + 3;
        boolean scroll = total > w;
        int left = scroll ? x + 18 : x, right = scroll ? x + w - 18 : x + w, selected = Math.max(0, keys.indexOf(tab));
        catScroll = Mth.clamp(catScroll, 0, keys.size() - 1);
        if (selected < catScroll) catScroll = selected;
        while (scroll && selected > lastFitting(names, catScroll, right - left)) catScroll++;
        int last = scroll ? lastFitting(names, catScroll, right - left) : keys.size() - 1, px = left;
        for (int i = catScroll; i <= last; i++) {
            final String key = keys.get(i), name = names.get(i);
            int pw = font.width(name) + 14;
            btn(new Rect(px, y, pw, 14), () -> name, PILL, () -> key.equals(tab), () -> selectTab(key));
            px += pw + 3;
        }
        if (scroll) {
            btn(new Rect(x, y, 16, 14), () -> "<", PILL, () -> false, () -> { catScroll--; rebuildWidgets(); }).setEnabled(catScroll > 0);
            btn(new Rect(x + w - 16, y, 16, 14), () -> ">", PILL, () -> false, () -> { catScroll++; rebuildWidgets(); }).setEnabled(last < keys.size() - 1);
        }
    }

    /** index of the last pill that fits in `room` pixels when the row starts at `from` (always at least `from`) */
    private int lastFitting(List<String> names, int from, int room) {
        int used = 0, last = from;
        for (int i = from; i < names.size(); i++) {
            used += font.width(names.get(i)) + 14;
            if (used > room && i > from) break;
            last = i;
            used += 3;
        }
        return last;
    }

    /** skins that may be combined with the current base: same pack, or the same dimension (2D with 2D, 3D with 3D) */
    private void cycleOverlay() {
        Skin base = SkinManager.skin(work.skin);
        List<Skin> l = new ArrayList<>();
        for (Skin s : SkinManager.skinsOf(tab)) if (!s.key().equals(work.skin) && (base == null || base.canCombine(s))) l.add(s);
        int idx = -1;
        for (int i = 0; i < l.size(); i++) if (l.get(i).key().equals(work.overlay)) idx = i;
        idx++;
        work.overlay = idx >= l.size() ? null : l.get(idx).key();
    }

    private int targetColor() { return colorTarget == 0 ? work.color : work.fxColor; }
    private void setTargetColor(int c) { if (colorTarget == 0) work.color = c; else work.fxColor = c; }

    private void cycleSwing() {
        int i = 0;
        for (int k = 0; k < FxIds.SWING_IDS.length; k++) if (FxIds.SWING_IDS[k].equals(work.swing)) i = k;
        work.swing = FxIds.SWING_IDS[(i + 1) % FxIds.SWING_IDS.length];
    }

    private void cycleSound() {
        int i = 0;
        for (int k = 0; k < FxIds.SOUND_KEYS.length; k++) if (FxIds.SOUND_KEYS[k].equals(work.sound)) i = k;
        work.sound = FxIds.SOUND_KEYS[(i + 1) % FxIds.SOUND_KEYS.length];
        Fx.playSound(minecraft, minecraft.player, Fx.specOf(work), 1f);   // hear it right away
    }

    private void cycleFx() {
        int i = 0;
        for (int k = 0; k < FxIds.IDS.length; k++) if (FxIds.IDS[k].equals(work.particle)) i = k;
        work.particle = FxIds.IDS[(i + 1) % FxIds.IDS.length];
    }

    private void apply() {
        if (work.skin == null) { status = ts("pick_first"); return; }
        if (work.id == null) work.id = UUID.randomUUID().toString().substring(0, 8);
        upsert(work.copy());
        (leftHand ? SkinManager.cfg.activeLeft : SkinManager.cfg.active).put(tab, work.id);
        boolean instant = SkinManager.loaded(work);
        SkinManager.equipChanged();            // reloads only when this look is brand new
        status = instant ? ts("applied") : ts("applied_reload");
    }

    private void saveNew() {
        if (work.skin == null) { status = ts("pick_first"); return; }
        Loadout n = work.copy();
        n.id = UUID.randomUUID().toString().substring(0, 8);
        upsert(n);
        work = n.copy();
        SkinManager.cfg.save(SkinManager.cfgFile);
        if (!SkinManager.loaded(n)) SkinManager.applyAndReload();   // card preview of a new look needs the pack rebuilt
        status = ts("saved");
        rebuildWidgets();
    }

    private void deleteWork() {
        if (work.id == null) return;
        String id = work.id;
        SkinManager.cfg.loadouts.removeIf(l -> id.equals(l.id));
        SkinManager.cfg.active.values().removeIf(id::equals);
        SkinManager.cfg.activeLeft.values().removeIf(id::equals);
        loadWork();
        SkinManager.cfg.save(SkinManager.cfgFile);
        RemoteFx.sendLocal();
        rebuildWidgets();
    }

    private void clearActive() {
        (leftHand ? SkinManager.cfg.activeLeft : SkinManager.cfg.active).remove(tab);
        SkinManager.cfg.save(SkinManager.cfgFile);
        RemoteFx.sendLocal();
        status = ts("cleared");
    }

    private void upsert(Loadout l) {
        List<Loadout> all = SkinManager.cfg.loadouts;
        for (int i = 0; i < all.size(); i++) if (l.id.equals(all.get(i).id)) { all.set(i, l); return; }
        all.add(l);
    }

    // ============================================================ 3D viewer page

    private void initViewer() {
        int vs = Math.max(96, Math.min(256, Math.min(height - 70, width / 2 - 20)));
        viewerRect = new Rect(24, 44, vs, vs);
        int rx = 24 + vs + 20, rw = Math.max(150, Math.min(250, width - rx - 12));
        int cw = (rw - 4) / 2, c2 = rx + cw + 4;
        int y = 70;
        // column 1: look
        slider(rx, y, cw, 14, ts("length"), 0.5, 2.0, work.length, MainScreen::pct, v -> { work.length = (float) (Math.round(v * 20) / 20.0); touch(); });
        slider(rx, y + 18, cw, 14, ts("width"), 0.5, 2.0, work.width, MainScreen::pct, v -> { work.width = (float) (Math.round(v * 20) / 20.0); touch(); });
        slider(rx, y + 36, cw, 14, ts("depth3d"), 0, 6, work.depth, v -> v < 0.25 ? ts("off") : String.format(Locale.ROOT, "%.1f", v),
            v -> { work.depth = (float) (Math.round(v * 2) / 2.0); touch(); });
        slider(rx, y + 54, cw, 14, ts("fx_size"), 0.5, 3.0, work.fxSize, MainScreen::pct, v -> { work.fxSize = (float) (Math.round(v * 10) / 10.0); touch(); });
        // column 2: effects (all shown live in the preview)
        btn(new Rect(c2, y, cw, 14), () -> ts("effect") + ": " + ts("fx_" + work.particle), NORMAL, () -> false, () -> { cycleFx(); touch(); });
        btn(new Rect(c2, y + 18, cw, 14), () -> ts("swing") + ": " + ts("swing_" + work.swing), NORMAL, () -> false, () -> { cycleSwing(); touch(); });
        btn(new Rect(c2, y + 36, cw, 14), () -> ts("sound") + ": " + ts("snd_" + work.sound), NORMAL, () -> false, () -> { cycleSound(); touch(); });
        btn(new Rect(c2, y + 54, cw, 14), () -> ts("swing_preview") + ": " + (Viewer3D.BIG.anim ? ts("on") : ts("off")), PILL, () -> Viewer3D.BIG.anim,
            () -> Viewer3D.BIG.anim = !Viewer3D.BIG.anim);
        y += 74;
        btn(new Rect(rx, y, cw, 14), () -> ts("spin") + ": " + (Viewer3D.BIG.spin ? ts("on") : ts("off")), NORMAL, () -> false, () -> Viewer3D.BIG.spin = !Viewer3D.BIG.spin);
        btn(new Rect(c2, y, cw, 14), () -> ts("reset_view"), NORMAL, () -> false, () -> Viewer3D.BIG.resetView());
        y += 22;
        slider(rx, y, cw, 14, ts("volume"), 0, 1, work.volume, MainScreen::pct, v -> { work.volume = (float) (Math.round(v * 20) / 20.0); touch(); });
        slider(c2, y, cw, 14, ts("density"), 1, 8, work.rate, v -> String.valueOf(Math.round(v)), v -> { work.rate = (int) Math.round(v); touch(); });
        y += 24;
        btn(new Rect(rx, y, rw, 20), () -> ts("equip"), ACTION, () -> false, this::apply);
        btn(new Rect(width - 26, 8, 18, 18), () -> "X", NORMAL, () -> false, () -> { viewer = false; rebuildWidgets(); });
    }

    /** colour of a particle / slash id for the preview (custom colour for the colourable ones) */
    private int fxRgb(String id) {
        int custom = work.fxColor >= 0 ? work.fxColor : (work.color >= 0 ? work.color : 0xFFFFFF);
        return switch (id) {
            case "flame" -> 0xFF8A2A;
            case "soul_flame" -> 0x4FE3FF;
            case "end_rod", "sweep" -> 0xFFFFFF;
            case "electric_spark" -> 0xB9E6FF;
            case "snowflake" -> 0xDDF6FF;
            case "crit" -> 0xE8D2A0;
            case "enchant" -> 0xB98CFF;
            case "glow" -> 0xFFE98A;
            case "witch" -> 0xC060FF;
            case "totem" -> 0x7BE06A;
            case "portal" -> 0xA040FF;
            case "cloud" -> 0xE0E0E0;
            default -> custom & 0xFFFFFF;       // dust / colored
        };
    }

    private void dot(GuiGraphics g, double x, double y, int size, int rgb, int alpha) {
        if (alpha <= 0) return;
        int px = (int) Math.round(x), py = (int) Math.round(y);
        g.fill(px, py, px + size, py + size, (Math.min(255, alpha) << 24) | (rgb & 0xFFFFFF));
    }

    /** The animation preview: the aura around the blade and the slash trail, painted over the 3D picture. */
    private void paintSwingFx(GuiGraphics g, Rect v) {
        double gx = v.x + v.w * 0.27, gy = v.y + v.h * 0.74;      // grip (pivot of the swing)
        double R = v.w * 0.62;
        long now = System.currentTimeMillis();
        int dsz = Math.max(1, Math.round(v.w / 90f * work.fxSize));
        // aura: sparks rising along the blade while an effect is chosen
        if (!"none".equals(work.particle)) {
            int rgb = fxRgb(work.particle);
            double a0 = Math.toRadians(50 - (Viewer3D.BIG.anim ? Viewer3D.BIG.roll : 0));
            int n = work.rate * 4;
            for (int i = 0; i < n; i++) {
                double ph = ((now * 0.0007) + i * 0.6180339) % 1.0;
                double sPos = ((i * 0.37) % 1.0);
                double jit = Math.sin(i * 12.9898) * 6;
                double bx = gx + Math.cos(a0) * R * sPos + Math.cos(a0 + Math.PI / 2) * jit;
                double by = gy - Math.sin(a0) * R * sPos - Math.sin(a0 + Math.PI / 2) * jit - ph * 14;
                dot(g, bx, by, dsz, rgb, (int) (200 * (1 - ph)));
            }
        }
        // slash trail: arc along the blade tip path, fading from old to new
        if (!"none".equals(work.swing) && Viewer3D.BIG.anim && Viewer3D.BIG.fade > 0f) {
            int rgb = fxRgb(work.swing);
            float p = Math.max(0.01f, Viewer3D.BIG.swingP);
            int segs = 26;
            for (int i = 0; i <= segs; i++) {
                float pp = p * i / segs;
                double ang = Math.toRadians(50 - Viewer3D.strokeRoll(pp));
                float age = (float) i / segs;                     // 1 = newest
                int al = (int) (230 * age * age * Viewer3D.BIG.fade);
                for (int ring = 0; ring < 3; ring++) {
                    double r = R * (0.78 + 0.12 * ring);
                    dot(g, gx + Math.cos(ang) * r, gy - Math.sin(ang) * r, dsz + 1, rgb, al);
                }
            }
        }
    }

    private void paintViewer(GuiGraphics g, int mx, int my, int acc) {
        Rect v = viewerRect;
        Ui.rect(g, v.x - 6, v.y - 6, v.w + 12, v.h + 12, glass() ? 10 : 0, PANEL());
        Ui.rect(g, v.x, v.y, v.w, v.h, R(), CARD());
        Skin base = SkinManager.skin(work.skin);
        Ui.glow(g, v.x, v.y, v.w, v.h, R(), base != null ? glowOf(base) : acc, 0.6f);
        if (th().border) Ui.outline(g, v.x - 6, v.y - 6, v.w + 12, v.h + 12, glass() ? 10 : 0, Ui.withAlpha(acc, 0x66));
        Viewer3D.BIG.sync(work);
        if (!Viewer3D.BIG.draw(g, v.x, v.y, v.w, true, mx, my) && base != null) {
            float sc = v.w / 20f;
            g.pose().pushMatrix();
            g.pose().translate(v.x + v.w / 2f, v.y + v.h / 2f);
            g.pose().scale(sc, sc);
            g.renderItem(preview(base.category, base.previewId()), -8, -8);
            g.pose().popMatrix();
        }
        if (Viewer3D.BIG.ready()) paintSwingFx(g, v);
        if (Viewer3D.BIG.takeSwingEvent() && !"none".equals(work.sound)) Fx.playSound(minecraft, minecraft.player, Fx.specOf(work), 1f);
        int rx = v.x + v.w + 20;
        g.drawString(font, skinName(work.skin), rx, 46, TEXT());
        g.drawString(font, ts("drag_hint"), rx, 58, DIM());
    }

    // ============================================================ packs tab

    private void initPacks() {
        int x = OX, y = 38, w = width - OX - 8;
        btn(new Rect(x, y, 118, 18), () -> ts("open_folder"), NORMAL, () -> false, () -> openDir(SkinManager.libDir));
        btn(new Rect(x + 122, y, 80, 18), () -> ts("rescan"), NORMAL, () -> false, () -> { SkinManager.rescan(); rebuildWidgets(); });
        btn(new Rect(x + 206, y, 130, 18), () -> ts("apply_packs"), ACTION, () -> false, () -> { SkinManager.applyAndReload(); status = ts("applied"); });
        y += 22;
        int hw = (w - 4) / 2;
        btn(new Rect(x, y, hw, 16), () -> ts("mp_share") + ": " + (SkinManager.cfg.shareMine ? ts("on") : ts("off")), NORMAL, () -> false,
            () -> { SkinManager.cfg.shareMine = !SkinManager.cfg.shareMine; SkinManager.cfg.save(SkinManager.cfgFile); RemoteFx.sendLocal(); });
        btn(new Rect(x + hw + 4, y, hw, 16), () -> ts("mp_skins") + ": " + (SkinManager.cfg.showOthersSkins ? ts("on") : ts("off")), NORMAL, () -> false,
            () -> { SkinManager.cfg.showOthersSkins = !SkinManager.cfg.showOthersSkins; SkinManager.cfg.save(SkinManager.cfgFile); });
        y += 20;
        btn(new Rect(x, y, hw, 16), () -> ts("mp_fx") + ": " + (SkinManager.cfg.showOthersFx ? ts("on") : ts("off")), NORMAL, () -> false,
            () -> { SkinManager.cfg.showOthersFx = !SkinManager.cfg.showOthersFx; SkinManager.cfg.save(SkinManager.cfgFile); });
        slider(x + hw + 4, y + 1, hw, 14, ts("mp_volume"), 0, 1, SkinManager.cfg.othersVolume, MainScreen::pct,
            v -> SkinManager.cfg.othersVolume = (float) (Math.round(v * 20) / 20.0));
        y += 62;
        for (SkinManager.PackInfo p : SkinManager.packs) {
            Rect r = new Rect(x, y, w, 22);
            packRows.add(r);
            area(r, () -> {
                SkinManager.cfg.packs.put(p.slug(), !p.enabled());
                SkinManager.cfg.save(SkinManager.cfgFile);
                SkinManager.rescan();
                rebuildWidgets();
            });
            y += 25;
            if (y > height - 30) break;
        }
    }

    private void openDir(Path dir) {
        try {
            Files.createDirectories(dir);
            String p = dir.toAbsolutePath().toString();
            String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
            new ProcessBuilder(os.contains("win") ? new String[] {"explorer", p}
                : os.contains("mac") ? new String[] {"open", p} : new String[] {"xdg-open", p}).start();
        } catch (Exception e) {
            minecraft.keyboardHandler.setClipboard(dir.toAbsolutePath().toString());
            status = ts("path_copied");
        }
    }

    // ============================================================ theme tab

    private void initTheme() {
        String[] subs = {ts("sub_presets"), ts("sub_colors"), ts("sub_background")};
        for (int i = 0; i < 3; i++) {
            final int k = i;
            btn(new Rect(OX + i * 96, 36, 92, 16), () -> subs[k], PILL, () -> tsub == k, () -> { tsub = k; rebuildWidgets(); });
        }
        int y0 = 60;
        Theme t = th();
        if (tsub == 0) {
            int x = OX, cw = 104, ch = 40, gap = 6;
            int per = Math.max(1, (width - OX - 8 + gap) / (cw + gap));
            for (int i = 0; i < Theme.IDS.length; i++) {
                Rect r = new Rect(x + (i % per) * (cw + gap), y0 + (i / per) * (ch + gap), cw, ch);
                presetRects.add(r);
                String id = Theme.IDS[i];
                area(r, () -> {
                    Theme n = Theme.preset(id);
                    n.bgImage = th().bgImage; n.bgColor = th().bgColor; n.bgOpacity = th().bgOpacity; n.opacity = th().opacity; // keep the picture and the see-through level
                    SkinManager.cfg.theme = n;
                    rebuildWidgets();
                });
            }
            int rows = (Theme.IDS.length + per - 1) / per;
            int sy = y0 + rows * (ch + gap) + 4;
            btn(new Rect(OX, sy, 200, 18), () -> ts("style") + ": " + (glass() ? ts("style_glass") : ts("style_flat")), NORMAL, () -> false, () -> {
                th().style = glass() ? 0 : 1; rebuildWidgets(); });
        } else if (tsub == 1) {
            int cwid = Math.min(220, (width - OX - 16) / 2);
            int[] sh = {16, 8, 0};
            String[] nm = {"R", "G", "B"};
            for (int i = 0; i < 3; i++) {
                final int s2 = sh[i];
                slider(OX, y0 + i * 17, cwid, 14, ts("accent") + " " + nm[i], 0, 255, (t.accent >> s2) & 0xFF,
                    v -> String.valueOf(Math.round(v)), v -> th().accent = (th().accent & ~(0xFF << s2)) | ((int) Math.round(v) << s2));
            }
            slider(OX, y0 + 54, cwid, 14, ts("opacity"), 0.05, 1.0, t.opacity, MainScreen::pct, v -> th().opacity = (float) (Math.round(v * 20) / 20.0));
            btn(new Rect(OX, y0 + 74, cwid, 16), () -> ts("action_color"), ACTION, () -> false, () -> {
                int i = 0;
                for (int k = 0; k < ACTIONS.length; k++) if (ACTIONS[k] == th().action) i = k;
                th().action = ACTIONS[(i + 1) % ACTIONS.length];
            });
            int bx = OX + cwid + 10, bw = Math.min(200, width - bx - 8);
            btn(new Rect(bx, y0, bw, 16), () -> ts("mode") + ": " + ts("mode_" + MODES[th().mode]), NORMAL, () -> false, () -> th().mode = (th().mode + 1) % 3);
            btn(new Rect(bx, y0 + 18, bw, 16), () -> ts("card_size") + ": " + ts("size_" + SIZES[th().cardSize]), NORMAL, () -> false, () -> th().cardSize = (th().cardSize + 1) % 3);
            btn(new Rect(bx, y0 + 36, bw, 16), () -> ts("gradient") + ": " + (th().gradientBar ? ts("on") : ts("off")), NORMAL, () -> false, () -> th().gradientBar = !th().gradientBar);
            btn(new Rect(bx, y0 + 54, bw, 16), () -> ts("border") + ": " + (th().border ? ts("on") : ts("off")), NORMAL, () -> false, () -> th().border = !th().border);
            btn(new Rect(bx, y0 + 72, bw, 16), () -> ts("reset_theme"), NORMAL, () -> false, () -> {
                Theme n = Theme.preset(th().preset);
                n.bgImage = th().bgImage; n.bgColor = th().bgColor; n.bgOpacity = th().bgOpacity;
                SkinManager.cfg.theme = n; rebuildWidgets(); });
        } else {
            int cwid = Math.min(220, (width - OX - 16) / 2);
            btn(new Rect(OX, y0, cwid, 16), () -> ts("bg_image") + ": " + (th().bgImage.isEmpty() ? ts("none") : th().bgImage), NORMAL, () -> false, () -> {
                List<String> l = BgImage.list();
                int idx = l.indexOf(th().bgImage) + 1;           // 0 = none
                th().bgImage = idx >= l.size() ? "" : l.get(idx);
                BgImage.reset();
            });
            slider(OX, y0 + 20, cwid, 14, ts("bg_opacity"), 0.0, 1.0, t.bgOpacity, MainScreen::pct, v -> th().bgOpacity = (float) (Math.round(v * 20) / 20.0));
            int[] sh = {16, 8, 0};
            String[] nm = {"R", "G", "B"};
            for (int i = 0; i < 3; i++) {
                final int s2 = sh[i];
                slider(OX, y0 + 40 + i * 17, cwid, 14, ts("bg_tint") + " " + nm[i], 0, 255, (t.bgColor >> s2) & 0xFF,
                    v -> String.valueOf(Math.round(v)), v -> th().bgColor = (th().bgColor & ~(0xFF << s2)) | ((int) Math.round(v) << s2));
            }
            int bx = OX + cwid + 10, bw = Math.min(200, width - bx - 8);
            btn(new Rect(bx, y0, bw, 16), () -> ts("bg_open_folder"), NORMAL, () -> false, () -> openDir(BgImage.dir()));
            btn(new Rect(bx, y0 + 20, bw, 16), () -> ts("rescan"), NORMAL, () -> false, () -> { BgImage.reset(); rebuildWidgets(); });
            btn(new Rect(bx, y0 + 40, bw, 16), () -> ts("bg_none"), NORMAL, () -> false, () -> { th().bgImage = ""; BgImage.reset(); });
        }
    }

    // ============================================================ easy mode

    private long reloadTexturesAt = 0;

    private <T> net.minecraft.client.gui.components.AbstractWidget addEasy(net.minecraft.client.OptionInstance<T> o, int x, int y, int w) {
        var options = minecraft.options;
        boolean textures = o == options.mipmapLevels() || o == options.textureFiltering() || o == options.maxAnisotropyBit();
        return o.createButton(options, x, y, w, v -> {
            EasyMode.changedByHand();
            if (textures) reloadTexturesAt = System.currentTimeMillis();
        });
    }

    private void initEasy() {
        String[] names = {ts("easy_off"), ts("easy_medium"), ts("easy_default"), ts("easy_custom")};
        int x = OX;
        for (int i = 0; i < 4; i++) {
            final int set = i;
            int w = font.width(names[i]) + 20;
            btn(new Rect(x, 36, w, 18), () -> names[set], PILL, () -> EasyMode.chosen() == set, () -> {
                if (set != EasyMode.CUSTOM) {
                    EasyMode.apply(set);
                    status = ts("applied");
                    rebuildWidgets();
                }
            });
            x += w + 4;
        }
        // the game's own buttons and sliders: they behave exactly as in its settings
        int cw = 150, gap = 4, cols = Math.max(1, (width - 2 * OX + gap) / (cw + gap)), n = 0;
        var cfg = SkinManager.cfg;
        SodiumLink.pullFog(cfg);
        Runnable fogChanged = () -> { EasyMode.changedByHand(); SodiumLink.pushFog(cfg); cfg.save(SkinManager.cfgFile); };
        btn(new Rect(OX, 74, cw, 20), () -> ts("easy_fog") + ": " + (cfg.fogOff ? ts("off") : ts("on")), NORMAL, () -> false, () -> { cfg.fogOff = !cfg.fogOff; fogChanged.run(); });
        slider(OX + cw + gap, 75, cw, 18, ts("easy_fog_distance"), 0, SodiumLink.EXTRA ? 32 : 64, cfg.fogDistance, v -> v < 1 ? ts("easy_fog_game") : Math.round(v) + "", v -> { cfg.fogDistance = (int) Math.round(v); fogChanged.run(); });
        slider(OX + 2 * (cw + gap), 75, cw, 18, ts("easy_fog_start"), 0, 1, cfg.fogStart, MainScreen::pct, v -> { cfg.fogStart = (float) (Math.round(v * 20) / 20.0); fogChanged.run(); });
        slider(OX + 3 * (cw + gap), 75, cw, 18, ts("easy_cloud_fog"), 0, SodiumLink.EXTRA ? 1 : 2, cfg.cloudFog, MainScreen::pct, v -> { cfg.cloudFog = (float) (Math.round(v * 20) / 20.0); fogChanged.run(); });
        int gammaBtnX = OX + (4 % cols) * (cw + gap), gammaBtnY = 74 + (4 / cols) * 24;
        btn(new Rect(gammaBtnX, gammaBtnY, cw, 20), () -> ts("easy_gamma") + ": " + (cfg.gammaOn ? ts("on") : ts("off")), NORMAL, () -> false, () -> { cfg.gammaOn = !cfg.gammaOn; cfg.save(SkinManager.cfgFile); });
        slider(OX + (5 % cols) * (cw + gap), 75 + (5 / cols) * 24, cw, 18, ts("easy_gamma_level"), 0, 15, cfg.gamma, MainScreen::pct, v -> { cfg.gamma = (float) (Math.round(v * 20) / 20.0); cfg.save(SkinManager.cfgFile); });
        int top = 74 + (6 / cols + (6 % cols > 0 ? 1 : 0)) * 24;
        for (var o : EasyMode.options()) {
            int cx = OX + (n % cols) * (cw + gap), cy = top + (n / cols) * 24;
            if (cy + 20 <= height - 26) addRenderableWidget(addEasy(o, cx, cy, cw));
            n++;
        }
        btn(new Rect(OX + (n % cols) * (cw + gap), top + (n / cols) * 24, cw, 20), () -> ts("easy_rain") + ": " + (cfg.noRain ? ts("off") : ts("on")), NORMAL, () -> false,
            () -> { cfg.noRain = !cfg.noRain; EasyMode.changedByHand(); cfg.save(SkinManager.cfgFile); });
        n++;
        // these exist only inside Sodium / Sodium Extra, so they show only when those are installed
        String[][] flags = {{"hiddenFluidCulling", "easy_fluid_culling"}, {"improvedFluidShaping", "easy_fluid_shaping"}, {"useClosestPointEntitySort", "easy_entity_sort"}};
        for (String[] f : flags) {
            if (!SodiumLink.hasFlag(f[0])) continue;
            btn(new Rect(OX + (n % cols) * (cw + gap), top + (n / cols) * 24, cw, 20), () -> ts(f[1]) + ": " + (SodiumLink.flag(f[0]) ? ts("on") : ts("off")), NORMAL, () -> false,
                () -> { SodiumLink.toggle(f[0]); EasyMode.changedByHand(); });
            n++;
        }
        if (SodiumLink.hasFilter()) {
            btn(new Rect(OX + (n % cols) * (cw + gap), top + (n / cols) * 24, cw, 20), () -> ts("easy_texel") + ": " + SodiumLink.filter(), NORMAL, () -> false,
                () -> { SodiumLink.nextFilter(); EasyMode.changedByHand(); });
            n++;
        }
        if (SodiumLink.hasFogShape()) {
            btn(new Rect(OX + (n % cols) * (cw + gap), top + (n / cols) * 24, cw, 20), () -> ts("easy_fog_shape") + ": " + SodiumLink.fogShape(), NORMAL, () -> false,
                () -> { SodiumLink.nextFogShape(); EasyMode.changedByHand(); });
            n++;
        }
    }

    // ============================================================ input

    /** Dropping files: pictures become the background, anything else is imported as a resource pack. */
    public void onFilesDrop(List<Path> paths) {
        int packs = 0;
        for (Path p : paths) {
            String n = p.getFileName().toString();
            String l = n.toLowerCase(Locale.ROOT);
            try {
                if (l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".gif") || l.endsWith(".bmp")) {
                    Files.createDirectories(BgImage.dir());
                    Files.copy(p, BgImage.dir().resolve(n), StandardCopyOption.REPLACE_EXISTING);
                    th().bgImage = n;
                    BgImage.reset();
                    Viewer3D.BIG.endDrag();
                    viewer = false;
                    tab = THEME; tsub = 2;
                    loadWork();
                    status = ts("bg_set", n);
                } else {
                    SkinManager.importPack(p);
                    packs++;
                }
            } catch (Exception ignored) {}
        }
        if (packs > 0) { SkinManager.rescan(); status = ts("imported", packs); }
        rebuildWidgets();
    }

    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (!viewer && isSkinTab() && altar.grid) { altar.gridWheel(sy); return true; }
        if (!viewer && isSkinTab() && sy != 0) { moveTo(altar.index + (sy < 0 ? 1 : -1)); return true; }
        return false;
    }

    public void renderBackground(GuiGraphics g, int mx, int my, float delta) { /* drawn in render() */ }

    @Override
    public void removed() {
        minecraft.options.save();
        if (reloadTexturesAt != 0) { reloadTexturesAt = 0; SkinManager.quietTextureReload(); }
        Viewer3D.BIG.endDrag();   // never leave the cursor locked
        Viewer3D.SMALL.endDrag();
    }

    @Override
    public void onClose() {
        if (viewer) { viewer = false; rebuildWidgets(); return; }   // Esc leaves the 3D viewer first
        SkinManager.cfg.save(SkinManager.cfgFile);
        minecraft.setScreen(parent);
    }

    // ============================================================ painting

    private int accent() { return th().accentAt(System.currentTimeMillis()); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        int acc = accent();
        Theme th = th();

        // ---- background: base, optional picture, translucent wash
        boolean img = th.bgImage != null && !th.bgImage.isEmpty();
        if (img) g.fill(0, 0, width, height, 0xFF000000);
        if (!BgImage.draw(g, width, height, th) && img) { /* failed to load: fall through to plain colours */ }
        // with a picture: only a light wash so the picture stays visible; panels and cards keep their own opacity
        if (img) g.fillGradient(0, 0, width, height, Ui.withAlpha(th.panel, 0x30), Ui.withAlpha(th.bg, 0x60));
        else g.fillGradient(0, 0, width, height, PANEL(), BG());

        if (viewer) {
            paintViewer(g, mx, my, acc);
            super.render(g, mx, my, delta);
            for (PBtn b : pbtns) paintBtn(g, b, mx, my, acc);
            for (Param p : params) paintSlider(g, p, acc);
            if (th.gradientBar) g.fillGradient(0, 30, width, 32, acc, 0x00000000);
            return;
        }

        // ---- top bar
        g.fill(0, 0, width, 30, BG());
        if (th.gradientBar) g.fillGradient(0, 30, width, 32, acc, 0x00000000);

        // ---- panels that sit under the real widgets
        if (isSkinTab()) paintSkinPanelBack(g, acc);

        super.render(g, mx, my, delta); // transparent widgets + the name box

        if (tab.equals(EASY)) g.drawString(font, t("easy_hint"), OX, 60, DIM());
        else if (tab.equals(PACKS)) paintPacks(g, mx, my, acc);
        else if (tab.equals(THEME)) paintTheme(g, mx, my, acc);
        else paintSkins(g, mx, my, acc);

        for (PBtn b : pbtns) paintBtn(g, b, mx, my, acc);
        for (Param p : params) paintSlider(g, p, acc);
        menu.paint(g, mx, my, acc, th);

        if (!status.isEmpty()) g.drawString(font, status, OX + 102, height - 20, 0xFF7CFF9B);
        else if (isSkinTab()) g.drawString(font, (altar.index + 1) + " / " + entries.size(), OX + 102, height - 20, DIM());
    }

    private void label(GuiGraphics g, String s, Rect r, int color) {
        g.drawString(font, s, r.x + (r.w - font.width(s)) / 2, r.y + (r.h - 8) / 2 + 1, color);
    }

    private void paintBtn(GuiGraphics g, PBtn b, int mx, int my, int acc) {
        Rect r = b.r;
        boolean hot = b.enabled && r.in(mx, my), sel = b.selected.getAsBoolean();
        String lab = b.label.get();
        int dis = b.enabled ? 1 : 0;
        switch (b.kind) {
            case ACTION -> {
                if (glass()) Ui.slant(g, r.x, r.y, r.w, r.h, th().action, hot);
                else Ui.rect(g, r.x, r.y, r.w, r.h, 0, 0xFF000000 | (hot ? Ui.lighten(th().action, 1.15f) : th().action));
                g.drawCenteredString(font, Component.literal(lab), r.x + r.w / 2 + (glass() ? 2 : 0), r.y + (r.h - 8) / 2 + 1, 0xFFFFFFFF);
            }
            case TAB, PILL -> {
                int rad = glass() ? r.h / 2 : 0;
                if (sel) {
                    Ui.rect(g, r.x, r.y, r.w, r.h, rad, acc);
                    label(g, lab, r, glass() && (th().accent == 0xFFFFFF) ? 0xFF101010 : 0xFFFFFFFF);
                } else {
                    if (b.kind == PILL || !glass()) Ui.rect(g, r.x, r.y, r.w, r.h, rad, hot ? HOT() : CARD());
                    else if (hot) Ui.rect(g, r.x, r.y, r.w, r.h, rad, HOT());
                    label(g, lab, r, hot ? TEXT() : DIM());
                }
            }
            default -> {
                Ui.rect(g, r.x, r.y, r.w, r.h, R(), hot ? HOT() : CARD());
                if (th().border) Ui.outline(g, r.x, r.y, r.w, r.h, R(), Ui.withAlpha(acc, hot ? 0xAA : 0x44));
                label(g, lab, r, dis == 1 ? TEXT() : DIM());
            }
        }
    }

    private void paintSlider(GuiGraphics g, Param p, int acc) {
        int x = p.getX(), y = p.getY(), w = p.getWidth(), h = p.getHeight();
        Ui.rail(g, x, y, w, h, (float) p.frac(), p.text, p.isHoveredOrFocused());
    }

    // ---- skins

    private void paintSkinPanelBack(GuiGraphics g, int acc) {
        Ui.rect(g, panelX, 34, panelW, height - 38, glass() ? 8 : 0, PANEL());
        if (glass()) Ui.outline(g, panelX, 34, panelW, height - 38, 8, Ui.withAlpha(acc, 0x66));
        else g.fill(panelX, 34, panelX + 2, height - 4, acc);
    }

    private void paintSkins(GuiGraphics g, int mx, int my, int acc) {
        Loadout act = SkinManager.cfg.activeFor(tab), actL = SkinManager.cfg.activeLeftFor(tab);
        if (SkinManager.skinsOf(tab).isEmpty()) g.drawString(font, t("empty"), OX + 4, 80, DIM());

        Viewer3D.frame();
        altar.paint(g, altarCell(acc), mx, my, th());
        g.nextStratum();

        // base name + hand label + the button for the big viewer
        int x = panelX + 6, w = panelW - 12;
        Skin base = SkinManager.skin(work.skin);
        g.drawString(font, font.plainSubstrByWidth(ts("base") + ": " + skinName(work.skin), w - 8), x + 4, 73, TEXT());
        g.drawString(font, leftHand ? ts("left") : ts("right"), x + 36, 60, DIM());
        if (base != null) g.drawString(font, "3D ⤢", x + w - 30, 60, Ui.withAlpha(acc, 0xDD));

        // colour swatches (sub tab 1)
        for (int i = 0; i < swatchRects.size(); i++) {
            Rect r = swatchRects.get(i);
            boolean none = i == SWATCHES.length;
            Ui.rect(g, r.x, r.y, r.w, r.h, Math.min(R(), 3), none ? 0xFF3A3F55 : 0xFF000000 | SWATCHES[i]);
            boolean on = none ? targetColor() < 0 : targetColor() == SWATCHES[i];
            if (on) Ui.outline(g, r.x - 1, r.y - 1, r.w + 2, r.h + 2, Math.min(R(), 3), 0xFFFFFFFF);
            if (none) g.drawCenteredString(font, Component.literal("∅"), r.x + r.w / 2, r.y + 2, TEXT());
        }
    }

    // ---- packs

    private void paintPacks(GuiGraphics g, int mx, int my, int acc) {
        g.drawString(font, t("mp_hint"), OX, 102, 0xFF9FB4FF);
        g.drawString(font, t("drop_hint"), OX, 116, 0xFFFFE08A);
        g.drawString(font, SkinManager.libDir.toAbsolutePath().toString(), OX, 128, DIM());
        int i = 0;
        for (SkinManager.PackInfo p : SkinManager.packs) {
            if (i >= packRows.size()) break;
            Rect r = packRows.get(i++);
            Ui.rect(g, r.x, r.y, r.w, r.h, R(), r.in(mx, my) ? HOT() : CARD());
            Ui.rect(g, r.x, r.y, 3, r.h, Math.min(R(), 1), p.enabled() ? 0xFF55FF77 : 0xFF666B80);
            g.drawString(font, p.name(), r.x + 10, r.y + 7, p.enabled() ? TEXT() : DIM());
            String right = ts("skins_count", p.skins()) + "   " + (p.enabled() ? ts("on") : ts("off"));
            g.drawString(font, right, r.x + r.w - font.width(right) - 8, r.y + 7, p.enabled() ? 0xFF7CFF9B : DIM());
        }
        if (SkinManager.packs.isEmpty()) g.drawString(font, t("no_packs"), OX, 150, DIM());
    }

    // ---- theme

    private void paintTheme(GuiGraphics g, int mx, int my, int acc) {
        if (tsub == 0) {
            g.drawString(font, t("theme_hint"), OX, 54 - 1, DIM());
            for (int i = 0; i < presetRects.size(); i++) {
                Rect r = presetRects.get(i);
                Theme p = Theme.preset(Theme.IDS[i]);
                boolean sel = Theme.IDS[i].equals(th().preset);
                int rad = p.radius();
                Ui.rect(g, r.x, r.y, r.w, r.h, rad, p.solid(p.bg));
                Ui.rect(g, r.x + 4, r.y + 4, 30, r.h - 8, Math.min(rad, 4), p.solid(p.card));
                Ui.rect(g, r.x + 4, r.y + r.h - 9, 30, 5, 0, p.solid(p.accent));
                Ui.rect(g, r.x + 38, r.y + 4, r.w - 42, 8, Math.min(rad, 3), p.solid(p.panel));
                g.drawString(font, t("theme_" + Theme.IDS[i]), r.x + 38, r.y + 20, p.solid(p.text));
                if (r.in(mx, my)) Ui.outline(g, r.x, r.y, r.w, r.h, rad, 0xFFFFFFFF);
                else if (sel) Ui.outline(g, r.x, r.y, r.w, r.h, rad, acc);
            }
        } else if (tsub == 1) {
            int cwid = Math.min(220, (width - OX - 16) / 2);
            g.fill(OX + cwid - 14, 57, OX + cwid, 59, th().solid(th().accent));
        } else {
            g.drawString(font, t("bg_hint"), OX, 54 - 1, DIM());
            int cwid = Math.min(220, (width - OX - 16) / 2);
            Ui.rect(g, OX, 60 + 40 + 3 * 17 + 4, cwid, 12, R(), 0xFF000000 | th().bgColor);
        }
    }
}
