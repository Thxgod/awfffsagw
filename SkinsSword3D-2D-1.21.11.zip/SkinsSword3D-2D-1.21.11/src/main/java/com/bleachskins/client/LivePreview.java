package com.bleachskins.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/** Draws the real thing from the game (item, block or mob), so it always shows the textures in use right now. */
final class LivePreview {
    private LivePreview() {}

    private static final Map<String, Optional<Entity>> ENTITIES = new HashMap<>();
    private static net.minecraft.world.level.Level entitiesLevel;

    private static ItemStack item(String name) {
        Identifier id = Identifier.tryParse("minecraft:" + name);
        if (id == null) return null;
        Optional<Item> i = BuiltInRegistries.ITEM.getOptional(id);
        return i.isPresent() && i.get() != Items.AIR ? new ItemStack(i.get()) : null;
    }

    private static Entity entity(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        if (entitiesLevel != mc.level) { ENTITIES.clear(); entitiesLevel = mc.level; }
        return ENTITIES.computeIfAbsent(name, n -> {
            try {
                Optional<EntityType<?>> type = EntityType.byString("minecraft:" + n);
                if (type.isEmpty()) return Optional.empty();
                Entity e = type.get().create(mc.level, EntitySpawnReason.LOAD);
                return e instanceof LivingEntity || e instanceof EndCrystal ? Optional.of(e) : Optional.empty();
            } catch (Throwable t) {
                return Optional.empty();
            }
        }).orElse(null);
    }

    /** @return an ItemStack or Entity showing this vanilla texture, or null when the game has nothing to show for it */
    static Object forTexture(String file) {
        int slash = file.indexOf('/');
        if (slash < 0) return null;
        String kind = file.substring(0, slash), rest = file.substring(slash + 1), last = rest.substring(rest.lastIndexOf('/') + 1);
        switch (kind) {
            case "item":
                return item(rest);
            case "block": {
                ItemStack s = item(rest);
                if (s == null) s = item(rest.replaceAll("_(top|side|bottom|front|back|end|on|off|inner|outer|\\d+)$", ""));
                return s;
            }
            case "entity": {
                String folder = rest.contains("/") ? rest.substring(0, rest.indexOf('/')) : last;
                switch (folder) {
                    case "bed": return item(last + "_bed");
                    case "banner": return item("white_banner");
                    case "chest": return item("chest");
                    case "shulker": return item("shulker_box");
                    case "shield_base", "shield_base_nopattern", "shield": return item("shield");
                    case "end_crystal": return entity("end_crystal");
                    default:
                }
                Entity e = entity(folder);
                return e != null ? e : item(folder + "_spawn_egg");
            }
            default:
                return null;
        }
    }

    static void draw(GuiGraphics g, Object thing, int x, int y, int size) {
        if (thing instanceof ItemStack st) {
            float k = size / 16f;
            g.pose().pushMatrix();
            g.pose().translate(x + size / 2f, y + size / 2f);
            g.pose().scale(k, k);
            g.renderItem(st, -8, -8);
            g.pose().popMatrix();
        } else if (thing instanceof Entity e) {
            try {
                Minecraft mc = Minecraft.getInstance();
                if (e instanceof EndCrystal c) c.time = (int) (System.currentTimeMillis() / 50 % 100000);
                EntityRenderState state = mc.getEntityRenderDispatcher().extractEntity(e, 1f);
                state.lightCoords = 15728880;
                state.outlineColor = 0;
                float h = Math.max(0.5f, e.getBbHeight()), box = Math.max(h, e.getBbWidth());
                float yaw = (float) ((System.currentTimeMillis() % 9000L) / 9000.0 * Math.PI * 2);
                Quaternionf rotation = new Quaternionf().rotateZ((float) Math.PI).rotateX((float) Math.toRadians(-12)).rotateY(yaw);
                g.submitEntityRenderState(state, size * 0.72f / box, new Vector3f(0f, h / 2f, 0f), rotation, null, x, y, x + size, y + size);
            } catch (Throwable ignored) {
            }
        }
    }
}
