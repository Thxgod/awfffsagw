package com.bleachskins.client;

import com.bleachskins.core.Categories;
import com.bleachskins.core.FxIds;
import com.bleachskins.core.Loadout;
import com.bleachskins.net.EffectsPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Effects around held weapons: particles while held, a sound on every swing.
 * Yours come from your config; other mod users' come from the server relay.
 */
public final class Fx {
    private Fx() {}

    public record Spec(String particle, int color, int rate, float length, float size, String sound, float volume, float pitch, String swing) {}

    private static final class Swing { boolean was; int time; }
    private static final Map<UUID, Swing> SWINGS = new ConcurrentHashMap<>();

    /** forget everything tied to the world we just left */
    public static void clear() { SWINGS.clear(); SLASHES.clear(); }

    private static ParticleOptions option(Spec s) {
        int rgb = s.color() >= 0 ? s.color() & 0xFFFFFF : 0xFFFFFF;
        return switch (s.particle()) {
            case "flame" -> ParticleTypes.FLAME;
            case "soul_flame" -> ParticleTypes.SOUL_FIRE_FLAME;
            case "end_rod" -> ParticleTypes.END_ROD;
            case "enchant" -> ParticleTypes.ENCHANT;
            case "crit" -> ParticleTypes.CRIT;
            case "electric_spark" -> ParticleTypes.ELECTRIC_SPARK;
            case "snowflake" -> ParticleTypes.SNOWFLAKE;
            case "glow" -> ParticleTypes.GLOW;
            case "witch" -> ParticleTypes.WITCH;
            case "totem" -> ParticleTypes.TOTEM_OF_UNDYING;
            case "sweep" -> ParticleTypes.SWEEP_ATTACK;
            case "portal" -> ParticleTypes.PORTAL;
            case "cloud" -> ParticleTypes.CLOUD;
            case "dust" -> new DustParticleOptions(rgb, Math.max(0.3f, Math.min(3f, s.size())));
            case "colored" -> ColorParticleOption.create(ParticleTypes.ENTITY_EFFECT, 0xFF000000 | rgb);
            default -> null;
        };
    }

    public static void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.isPaused()) return;
        if (mc.level.getGameTime() % 200 == 0) {                 // players who left or moved out of range
            var level = mc.level;
            SWINGS.keySet().removeIf(id -> level.getPlayerByUUID(id) == null);
        }

        // yourself
        Player me = mc.player;
        for (int hand = 0; hand < 2; hand++) { // 0 = main hand, 1 = off hand
            int side = sideOf(me, hand);
            ItemStack st = hand == 0 ? me.getMainHandItem() : me.getOffhandItem();
            if (st.isEmpty()) continue;
            String cat = Categories.of(BuiltInRegistries.ITEM.getKey(st.getItem()).getPath());
            Loadout lo = side == 1 && SkinManager.cfg.activeLeftFor(cat) != null ? SkinManager.cfg.activeLeftFor(cat) : SkinManager.cfg.activeFor(cat);
            if (lo == null) continue;
            Spec sp = specOf(lo);
            if (!"none".equals(sp.particle())) spawn(mc, me, side, sp);
        }
        Loadout swingLo = null;
        if (swung(me)) {
            int hand = me.swingingArm == InteractionHand.OFF_HAND ? 1 : 0;
            ItemStack st = hand == 0 ? me.getMainHandItem() : me.getOffhandItem();
            if (!st.isEmpty()) {
                String cat = Categories.of(BuiltInRegistries.ITEM.getKey(st.getItem()).getPath());
                int side = sideOf(me, hand);
                swingLo = side == 1 && SkinManager.cfg.activeLeftFor(cat) != null ? SkinManager.cfg.activeLeftFor(cat) : SkinManager.cfg.activeFor(cat);
            }
        }
        if (swingLo != null) { playSound(mc, me, specOf(swingLo), 1f); startSlash(me, specOf(swingLo), sideOf(me, me.swingingArm == InteractionHand.OFF_HAND ? 1 : 0)); }
        runSlashes(mc);

        // other players who run the mod
        if (!SkinManager.cfg.showOthersFx) return;
        for (AbstractClientPlayer other : mc.level.players()) {
            if (other == mc.player || other.distanceToSqr(mc.player) > 48 * 48) continue;
            var list = RemoteFx.get(other.getUUID());
            boolean sw = swung(other);
            if (list == null) continue;
            for (int hand = 0; hand < 2; hand++) {
                ItemStack st = hand == 0 ? other.getMainHandItem() : other.getOffhandItem();
                if (st.isEmpty()) continue;
                String cat = Categories.of(BuiltInRegistries.ITEM.getKey(st.getItem()).getPath());
                int side = sideOf(other, hand);
                int swingHand = other.swingingArm == InteractionHand.OFF_HAND ? 1 : 0;
                for (EffectsPayload.Entry e : list) {
                    if (e.hand() != side || !e.category().equals(cat)) continue;
                    Spec sp = new Spec(e.particle(), e.color(), e.rate(), e.length(), e.size(), e.sound(), e.volume(), e.pitch(), e.swing());
                    if (!"none".equals(sp.particle())) spawn(mc, other, side, sp);
                    if (sw && swingHand == hand) { playSound(mc, other, sp, SkinManager.cfg.othersVolume); startSlash(other, sp, side); }
                }
            }
        }
    }

    // ---- slash drawn in the air for a few ticks after each swing (fire slash, ice slash, ...)
    private static final class Slash { Player p; Spec s; int side; int age; }
    private static final java.util.List<Slash> SLASHES = new java.util.ArrayList<>();
    private static final int SLASH_TICKS = 6;

    private static void startSlash(Player p, Spec s, int side) {
        if (s.swing() == null || "none".equals(s.swing())) return;
        Slash sl = new Slash(); sl.p = p; sl.s = s; sl.side = side;
        SLASHES.add(sl);
    }

    private static void runSlashes(Minecraft mc) {
        for (java.util.Iterator<Slash> it = SLASHES.iterator(); it.hasNext();) {
            Slash sl = it.next();
            if (sl.p.isRemoved() || sl.age >= SLASH_TICKS) { it.remove(); continue; }
            Spec as = new Spec(sl.s.swing(), sl.s.color(), 1, sl.s.length(), sl.s.size(), "none", 0, 1, "none");
            ParticleOptions opt = option(as);
            if (opt != null) {
                float t0 = sl.age / (float) SLASH_TICKS, t1 = (sl.age + 1) / (float) SLASH_TICKS;
                float yaw = (float) Math.toRadians(sl.p.getYRot());
                double fx = -Math.sin(yaw), fz = Math.cos(yaw);          // forward (horizontal)
                double rx = -fz, rz = fx;                                  // right
                double dirSign = sl.side == 0 ? 1 : -1;                    // right hand: sweeps right -> left, left hand: mirrored
                double reach = 1.7 * Math.max(0.6f, sl.s.length());
                Vec3 eye = sl.p.getEyePosition().add(0, -0.25, 0);
                int steps = "sweep".equals(sl.s.swing()) ? 1 : 5;
                for (int i = 0; i < steps; i++) {
                    float t = t0 + (t1 - t0) * (i + 0.5f) / steps;
                    double ang = Math.toRadians(70 - 140 * t) * dirSign;  // +70..-70 degrees
                    double up = (0.55 - 1.1 * t) * dirSign * 0.8;          // diagonal slash: high -> low
                    for (int k = 0; k < 2; k++) {                          // two rings give the arc some thickness
                        double r = reach * (0.8 + 0.25 * k);
                        double dx = fx * Math.cos(ang) + rx * Math.sin(ang), dz = fz * Math.cos(ang) + rz * Math.sin(ang);
                        Vec3 pos = eye.add(dx * r, up, dz * r);
                        // drift along the sweep direction so it streaks
                        double vx = (-fx * Math.sin(ang) + rx * Math.cos(ang)) * -0.12 * dirSign, vz = (-fz * Math.sin(ang) + rz * Math.cos(ang)) * -0.12 * dirSign;
                        mc.level.addParticle(opt, pos.x, pos.y, pos.z, vx, 0, vz);
                    }
                }
            }
            sl.age++;
        }
    }

    public static Spec specOf(Loadout lo) {
        return new Spec(lo.particle, lo.fxColor >= 0 ? lo.fxColor : lo.color, lo.rate, lo.length, lo.fxSize, lo.sound, lo.volume, lo.pitch, lo.swing);
    }

    /** true on the tick a swing starts (or restarts) */
    private static boolean swung(Player p) {
        Swing s = SWINGS.computeIfAbsent(p.getUUID(), k -> new Swing());
        boolean sw = p.swinging;
        boolean fire = sw && (!s.was || p.swingTime < s.time);
        s.was = sw;
        s.time = p.swingTime;
        return fire;
    }

    /** used by the GUI "test" button too */
    public static void playSound(Minecraft mc, Player p, Spec s, float master) {
        if (mc.level == null || s.sound() == null || "none".equals(s.sound())) return;
        String id = FxIds.SOUNDS.get(s.sound());
        if (id == null || id.isEmpty()) return;
        Identifier key = Identifier.tryParse(id);
        if (key == null) return;
        SoundEvent ev = BuiltInRegistries.SOUND_EVENT.getValue(key);
        if (ev == null) return;
        mc.level.playLocalSound(p.getX(), p.getY() + 1, p.getZ(), ev, SoundSource.PLAYERS,
            Math.max(0f, Math.min(1f, s.volume())) * master, Math.max(0.5f, Math.min(2f, s.pitch())), false);
    }

    /** display side of the item in `hand` (0 main / 1 off): 0 = right, 1 = left */
    static int sideOf(Player p, int hand) {
        boolean rightHanded = p.getMainArm() == HumanoidArm.RIGHT;
        return (hand == 0) == rightHanded ? 0 : 1;
    }

    private static void spawn(Minecraft mc, Player p, int side, Spec s) {
        ParticleOptions opt = option(s);
        if (opt == null) return;
        RandomSource r = p.getRandom();
        Vec3 look = p.getLookAngle();
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        double sign = side == 0 ? 1 : -1;
        double spread = 0.15 * Math.max(0.3f, Math.min(3f, s.size()));
        Vec3 base = p.getEyePosition().add(look.scale(0.7)).add(right.scale(0.35 * sign)).add(0, -0.45, 0);
        for (int i = 0; i < Math.max(1, s.rate()); i++) {
            double t = r.nextDouble() * 1.2 * s.length();
            Vec3 pos = base.add(look.scale(0.5 * t)).add(0, 0.8 * t, 0)
                .add((r.nextDouble() - 0.5) * spread, (r.nextDouble() - 0.5) * spread, (r.nextDouble() - 0.5) * spread);
            mc.level.addParticle(opt, pos.x, pos.y, pos.z, 0, 0.01, 0);
        }
    }
}
