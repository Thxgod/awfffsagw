package com.bleachskins.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.resources.ReloadInstance;

import java.util.Optional;
import java.util.function.Consumer;

/**
 * A resource reload without the logo: the open screen stays visible with a small note until the reload is done.
 * Extends LoadingOverlay because the game checks for that type to avoid running two reloads at once.
 */
public final class QuietOverlay extends LoadingOverlay {
    private final Minecraft mc;
    private final ReloadInstance reload;
    private final Consumer<Optional<Throwable>> onFinish;
    private boolean finished = false;

    public QuietOverlay(Minecraft mc, ReloadInstance reload, Consumer<Optional<Throwable>> onFinish) {
        super(mc, reload, onFinish, false);
        this.mc = mc;
        this.reload = reload;
        this.onFinish = onFinish;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        if (mc.screen != null) mc.screen.renderWithTooltipAndSubtitles(g, mx, my, delta);
        Component note = Component.translatable("gui.bleachskins.reloading");
        g.drawCenteredString(mc.font, note, g.guiWidth() / 2, g.guiHeight() - 12, 0xFFFFFFFF);
        if (finished || !reload.isDone()) return;
        finished = true;
        try {
            reload.checkExceptions();
            onFinish.accept(Optional.empty());
        } catch (Throwable t) {
            onFinish.accept(Optional.of(t));
        }
        mc.setOverlay(null);
        if (mc.screen != null) mc.screen.init(mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
    }
}
