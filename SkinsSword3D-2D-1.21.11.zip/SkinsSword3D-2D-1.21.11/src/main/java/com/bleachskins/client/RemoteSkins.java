package com.bleachskins.client;

import com.bleachskins.core.Categories;
import com.bleachskins.core.Loadout;
import com.bleachskins.net.EffectsPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Picks the model of held weapons while they are drawn (see ItemModelResolverMixin). The item itself is never changed,
 * so nothing can reach the server, stick to the item after you switch slots, or fight with the server's inventory:
 *  - your own hands: from your equipped "my skins" (hotbar and inventory slots included)
 *  - other mod users: the skin they sent, if you own the same pack
 * Every look is already in the loaded resource pack as an item definition (bleachskins:lo_...), so no reload is needed.
 */
public final class RemoteSkins {
    private RemoteSkins() {}

    private static final Map<String, Identifier> IDS = new HashMap<>();

    private static final Identifier COBWEB = Identifier.withDefaultNamespace("cobweb");
    private static final Identifier COBWEB_FRAMED = Identifier.fromNamespaceAndPath("bleachskins", "cobweb_framed");

    /** a cobweb item looks like the framed block while the frame is on (everywhere, not only in hands) */
    public static Identifier cobweb(Identifier id) {
        return SkinManager.cfg.cobwebFrame && COBWEB.equals(id) ? COBWEB_FRAMED : id;
    }

    /** @return the model to draw for this stack; `current` when it isn't a held weapon of a player */
    public static Identifier modelFor(Identifier current, ItemStack st, ItemDisplayContext ctx, ItemOwner owner) {
        if (owner == null || st.isEmpty() || !(owner.asLivingEntity() instanceof Player p)) return current;
        if ((ctx == ItemDisplayContext.FIRST_PERSON_RIGHT_HAND || ctx == ItemDisplayContext.FIRST_PERSON_LEFT_HAND) && SkinManager.bitesReady) {
            Identifier bite = HeldSize.biteModel(p, st);
            if (bite != null) return bite;
        }
        int side = sideOf(p, st, ctx);
        if (side < 0) return current;
        String def = p == Minecraft.getInstance().player ? mine(st, side) : theirs(p, st, side);
        if (def != null) return IDS.computeIfAbsent(def, d -> Identifier.fromNamespaceAndPath("bleachskins", d));
        // an item saved with one of our models by an older version of the mod: show it as normal
        if (current != null && "bleachskins".equals(current.getNamespace())) {
            Identifier own = st.getItem().components().get(DataComponents.ITEM_MODEL);
            if (own != null) return own;
        }
        return current;
    }

    /** display side: 0 = right, 1 = left, -1 = this stack isn't held */
    private static int sideOf(Player p, ItemStack st, ItemDisplayContext ctx) {
        switch (ctx) {
            case FIRST_PERSON_RIGHT_HAND, THIRD_PERSON_RIGHT_HAND: return 0;
            case FIRST_PERSON_LEFT_HAND, THIRD_PERSON_LEFT_HAND: return 1;
            case GUI:                                   // hotbar / inventory: only the very stacks in your hands
                if (st == p.getMainHandItem()) return Fx.sideOf(p, 0);
                if (st == p.getOffhandItem()) return Fx.sideOf(p, 1);
                return -1;
            default: return -1;
        }
    }

    private static String category(ItemStack st) {
        return Categories.of(BuiltInRegistries.ITEM.getKey(st.getItem()).getPath());
    }

    private static String mine(ItemStack st, int side) {
        String cat = category(st);
        Loadout left = side == 1 ? SkinManager.cfg.activeLeftFor(cat) : null;
        Loadout lo = left != null ? left : SkinManager.cfg.activeFor(cat);
        return lo != null && SkinManager.loaded(lo) ? SkinManager.defId(lo) : null;
    }

    private static String theirs(Player p, ItemStack st, int side) {
        if (!SkinManager.cfg.showOthersSkins) return null;
        List<EffectsPayload.Entry> list = RemoteFx.get(p.getUUID());
        if (list == null) return null;
        String cat = category(st), def = null;
        for (EffectsPayload.Entry e : list)
            if (e.hand() == side && e.category().equals(cat) && !e.skin().isEmpty()) {
                String d = SkinManager.defOfPreview(e.skin());
                if (d != null) def = d;
            }
        return def;
    }
}
