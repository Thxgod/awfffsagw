package com.bleachskins.client;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.server.level.ParticleStatus;

import java.util.ArrayList;
import java.util.List;

/** The game's own display settings gathered in one page, with ready-made sets. Everything stays the game's real option. */
final class EasyMode {
    private EasyMode() {}

    static final int OFF = 0, MEDIUM = 1, DEFAULT = 2, CUSTOM = 3;

    private record Row<T>(OptionInstance<T> option, T off, T medium, T normal) {
        T value(int set) { return set == OFF ? off : set == MEDIUM ? medium : normal; }
        void apply(int set) { option.set(value(set)); }
        boolean is(int set) { return value(set).equals(option.get()); }
    }

    private static List<Row<?>> rows() {
        Options o = Minecraft.getInstance().options;
        List<Row<?>> l = new ArrayList<>();
        l.add(new Row<>(o.fovEffectScale(), 0.0, 0.0, 1.0));
        l.add(new Row<>(o.damageTiltStrength(), 0.0, 0.5, 1.0));
        l.add(new Row<>(o.screenEffectScale(), 0.0, 0.5, 1.0));
        l.add(new Row<>(o.darknessEffectScale(), 0.0, 0.5, 1.0));
        l.add(new Row<>(o.bobView(), false, false, true));
        l.add(new Row<>(o.hideLightningFlash(), true, true, false));
        l.add(new Row<>(o.particles(), ParticleStatus.MINIMAL, ParticleStatus.DECREASED, ParticleStatus.ALL));
        l.add(new Row<>(o.cloudStatus(), CloudStatus.OFF, CloudStatus.FAST, CloudStatus.FANCY));
        l.add(new Row<>(o.cloudRange(), 2, 8, 128));
        l.add(new Row<>(o.weatherRadius(), 3, 5, 10));
        l.add(new Row<>(o.cutoutLeaves(), false, true, true));
        l.add(new Row<>(o.improvedTransparency(), false, false, false));
        l.add(new Row<>(o.ambientOcclusion(), false, true, true));
        l.add(new Row<>(o.biomeBlendRadius(), 0, 2, 2));
        l.add(new Row<>(o.entityDistanceScaling(), 0.5, 0.75, 1.0));
        l.add(new Row<>(o.entityShadows(), false, false, true));
        l.add(new Row<>(o.vignette(), false, true, true));
        l.add(new Row<>(o.chunkSectionFadeInTime(), 0.0, 0.25, 0.75));
        return l;
    }

    /** every option you can set by hand on the page */
    static List<OptionInstance<?>> options() {
        List<OptionInstance<?>> l = new ArrayList<>();
        for (Row<?> r : rows()) l.add(r.option);
        l.add(Minecraft.getInstance().options.mipmapLevels());
        l.add(Minecraft.getInstance().options.textureFiltering());
        l.add(Minecraft.getInstance().options.maxAnisotropyBit());
        l.add(Minecraft.getInstance().options.gamma());
        return l;
    }

    /** the sets leave mipmap and filtering alone: changing those means loading all textures again, the world goes dark for a moment */
    static void apply(int set) {
        Options o = Minecraft.getInstance().options;
        for (Row<?> r : rows()) r.apply(set);
        var cfg = SkinManager.cfg;
        cfg.fogOff = set == OFF;
        cfg.noRain = set == OFF;
        cfg.fogDistance = 0; cfg.fogStart = 1f; cfg.cloudFog = 1f;
        cfg.easySet = set;
        SodiumLink.pushFog(cfg);
        cfg.save(SkinManager.cfgFile);
        o.save();
    }

    /** the set you pressed last, until you change something by hand */
    static int chosen() {
        var cfg = SkinManager.cfg;
        if (cfg.easySet < 0) cfg.easySet = current();
        return cfg.easySet;
    }

    static void changedByHand() { SkinManager.cfg.easySet = CUSTOM; }

    /** the ready-made set the options match now, CUSTOM when they match none */
    static int current() {
        List<Row<?>> rows = rows();
        var cfg = SkinManager.cfg;
        if (cfg.fogDistance != 0 || cfg.fogStart != 1f || cfg.cloudFog != 1f) return CUSTOM;
        for (int set : new int[] {OFF, MEDIUM, DEFAULT}) {
            boolean all = cfg.fogOff == (set == OFF) && cfg.noRain == (set == OFF);
            for (Row<?> r : rows) if (!r.is(set)) { all = false; break; }
            if (all) return set;
        }
        return CUSTOM;
    }
}
