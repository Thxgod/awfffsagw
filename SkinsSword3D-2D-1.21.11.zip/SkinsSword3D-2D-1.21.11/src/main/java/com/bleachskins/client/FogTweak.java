package com.bleachskins.client;

import com.bleachskins.core.Config;

/** Your fog settings; they change only the normal fog in the air, never water, lava, blindness or the like. */
public final class FogTweak {
    private FogTweak() {}

    private static final float FAR = 1_000_000f;
    public static boolean air = false;

    private static Config c() { return SkinManager.cfg; }
    private static boolean on() { return air && !SodiumLink.EXTRA && c() != null; }   // Sodium Extra does fog itself; the page sets its values

    public static float environment(float v) { return on() && c().fogOff ? FAR : v; }
    public static float end(float v) {
        if (!on()) return v;
        return c().fogOff ? FAR : c().fogDistance > 0 ? c().fogDistance * 16f : v;
    }
    public static float start(float v) {
        if (!on()) return v;
        if (c().fogOff) return FAR;
        float base = c().fogDistance > 0 ? c().fogDistance * 16f : v;
        return base * c().fogStart;
    }
    public static float sky(float v) { return on() && c().fogOff ? FAR : v; }
    public static float cloud(float v) { return !on() ? v : c().fogOff ? FAR : v * c().cloudFog; }
}
