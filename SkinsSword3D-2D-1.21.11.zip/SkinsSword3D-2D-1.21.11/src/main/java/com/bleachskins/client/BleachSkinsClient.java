package com.bleachskins.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import com.bleachskins.net.EffectsPayload;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BleachSkinsClient implements ClientModInitializer {
    public static final String MOD_ID = "bleachskins";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyMapping openKey;

    @Override
    public void onInitializeClient() {
        SkinManager.init(); // scan library + build the pack before the first resource load

        // rebindable in Options > Controls (default K)
        openKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key." + MOD_ID + ".open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, KeyMapping.Category.MISC));

        ClientPlayNetworking.registerGlobalReceiver(EffectsPayload.TYPE, (payload, context) -> RemoteFx.receive(payload));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> RemoteFx.sendLocal());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> { RemoteFx.clear(); Fx.clear(); });

        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            SkinManager.ensureSelected();
            if (net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("modmenu")) ModMenuIntegration.addClientBadge();
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.consumeClick()) {
                if (client.screen == null) client.setScreen(new MainScreen(null).startScreen());
            }
            Fx.tick(client);
        });
    }
}
