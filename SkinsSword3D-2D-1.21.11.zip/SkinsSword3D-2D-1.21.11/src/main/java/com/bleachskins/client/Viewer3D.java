package com.bleachskins.client;

import com.bleachskins.core.Loadout;
import com.bleachskins.core.ModelRaster;
import com.bleachskins.core.Skin;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * A weapon you can turn around 360 degrees. The picture comes from core's software renderer (it reads the same
 * generated models the game loads), so it needs no special render state and also reacts instantly to
 * length / thickness / tint / 3D-depth changes without a resource reload.
 */
public final class Viewer3D {
    public static final Viewer3D SMALL = new Viewer3D("viewer_small", 160);
    public static final Viewer3D BIG = new Viewer3D("viewer_big", 256);

    private final String name;
    private final Identifier id;
    private final int size;
    private DynamicTexture tex;
    private NativeImage img;
    private ModelRaster.Scene scene;
    private String key = "";
    private boolean dirty = true;

    public float yaw = 28f, pitch = 14f;
    public boolean spin = true;
    /** swing animation preview: the weapon swings around its grip; swingP = 0..1 during the stroke, fade = trail opacity */
    public boolean anim = false;
    public float roll = 0f, swingP = -1f, fade = 0f;
    private boolean wasAnim = false, prevStroke = false, swingEvent = false;
    private long last = System.nanoTime();
    private boolean dragging = false;
    private double startX, startY, prevX, prevY;

    // ---- one small viewer for each option on the altars; loading a new model is limited so moving stays smooth
    private static final java.util.LinkedHashMap<String, Viewer3D> POOL = new java.util.LinkedHashMap<>(16, 0.75f, true);
    private static int poolMade = 0, loads = 0, frameNo = 0;
    private int slot = 0;
    private boolean pooled = false;

    // the turning models are drawn once for each angle into one sheet and only shown from then on, so spinning costs nothing
    private static final int FRAMES = 96, SHEET_COLS = 12, SHEET_ROWS = 8;
    private static final long TURN_MS = 9500L;
    private static int rasters = 0;
    private final boolean[] filled = new boolean[FRAMES];

    public static void frame() { loads = 1; rasters = 3; frameNo++; }

    private boolean cached() { return pooled || this == SMALL; }

    private boolean drawCached(GuiGraphics g, int x, int y, int px) {
        ensure();
        double turn = (System.currentTimeMillis() + slot * 700L) % TURN_MS * (double) FRAMES / TURN_MS;
        int f = (int) turn, next = (f + 1) % FRAMES;
        fill(f);
        fill(next);
        int show = -1;
        for (int d = 0; d < FRAMES && show < 0; d++) if (filled[Math.floorMod(f - d, FRAMES)]) show = Math.floorMod(f - d, FRAMES);
        if (show < 0) return false;
        blitFrame(g, show, x, y, px, 0xFFFFFFFF);
        if (show == f && filled[next]) {                  // fade into the next angle, so it turns smoothly between the drawn ones
            int alpha = (int) ((turn - f) * 255);
            if (alpha > 0) blitFrame(g, next, x, y, px, (alpha << 24) | 0xFFFFFF);
        }
        return true;
    }

    private void fill(int f) {
        if (filled[f] || (this != SMALL && rasters <= 0)) return;
        if (this != SMALL) rasters--;
        int[] p = ModelRaster.render(scene, f * 360f / FRAMES, pitch, 0f, size);
        int ox = f % SHEET_COLS * size, oy = f / SHEET_COLS * size;
        for (int j = 0; j < size; j++) for (int i = 0; i < size; i++) img.setPixel(ox + i, oy + j, p[j * size + i]);
        com.mojang.blaze3d.systems.RenderSystem.getDevice().createCommandEncoder().writeToTexture(tex.getTexture(), img, 0, 0, ox, oy, size, size, ox, oy);
        filled[f] = true;
    }

    private void blitFrame(GuiGraphics g, int f, int x, int y, int px, int argb) {
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, f % SHEET_COLS * size, f / SHEET_COLS * size, px, px, size, size, size * SHEET_COLS, size * SHEET_ROWS, argb);
    }

    private static Viewer3D pooled(String k) {
        Viewer3D v = POOL.get(k);
        if (v != null) return v;
        if (POOL.size() >= 12) {
            var eldest = POOL.entrySet().iterator().next();
            v = eldest.getValue();
            POOL.remove(eldest.getKey());
        } else {
            v = new Viewer3D("viewer_pool_" + poolMade, 96);
            v.slot = poolMade++;
            v.pooled = true;
        }
        POOL.put(k, v);
        return v;
    }

    /** @return false while the model isn't loaded, or when it has nothing to show */
    public static boolean drawPooled(GuiGraphics g, String poolKey, Loadout w, int x, int y, int px) {
        Viewer3D v = pooled(poolKey);
        Skin a = SkinManager.skin(w.skin);
        if (a == null) return false;
        Skin b = w.overlay == null ? null : SkinManager.skin(w.overlay);
        String k = a.key() + "|" + (b == null ? "" : b.key()) + "|" + w.color + "|" + w.length + "|" + w.width + "|" + w.depth;
        if (!k.equals(v.key)) {
            if (loads <= 0) return false;
            loads--;
            v.sync(w);
        }
        return v.draw(g, x, y, px, false, 0, 0);
    }

    private Viewer3D(String name, int size) {
        this.name = name;
        this.size = size;
        this.id = Identifier.fromNamespaceAndPath("bleachskins", name);
    }

    /** give the cursor back (put it where the drag started). Safe to call any time. */
    public void endDrag() {
        if (!dragging) return;
        dragging = false;
        long win = GLFW.glfwGetCurrentContext();
        GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
        GLFW.glfwSetCursorPos(win, startX, startY);
    }

    /** true once at the start of every animated swing (for the sound preview) */
    public boolean takeSwingEvent() { boolean e = swingEvent; swingEvent = false; return e; }

    public static float strokeRoll(float p) {
        float e = 1f - (1f - p) * (1f - p) * (1f - p);
        return 55f - 120f * e;
    }

    public void resetView() { yaw = 28f; pitch = 14f; dirty = true; }

    /** Load / refresh the model for this "my skin" (cheap when nothing changed). */
    public void sync(Loadout w) {
        Skin a = w == null ? null : SkinManager.skin(w.skin);
        if (a == null) { scene = null; key = ""; return; }
        Skin b = w.overlay == null ? null : SkinManager.skin(w.overlay);
        String k = a.key() + "|" + (b == null ? "" : b.key()) + "|" + w.color + "|" + w.length + "|" + w.width + "|" + w.depth;
        if (k.equals(key) && scene != null) return;
        key = k;
        java.util.Arrays.fill(filled, false);
        try {
            JsonObject tree = a.tree;
            if (b != null) {
                JsonObject comp = new JsonObject();
                comp.addProperty("type", "minecraft:composite");
                JsonArray arr = new JsonArray();
                arr.add(a.tree); arr.add(b.tree);
                comp.add("models", arr);
                tree = comp;
            }
            ModelRaster.Params p = ModelRaster.Params.of(w);
            scene = ModelRaster.load(SkinManager.genDir, tree, p);
        } catch (Throwable t) {
            BleachSkinsClient.LOGGER.warn("3D preview failed", t);
            scene = null;
        }
        dirty = true;
    }

    public boolean ready() { return scene != null && !scene.isEmpty(); }

    private void ensure() {
        if (tex != null) return;
        boolean sheet = cached();
        img = new NativeImage(sheet ? size * SHEET_COLS : size, sheet ? size * SHEET_ROWS : size, true);
        tex = new DynamicTexture(() -> name, img);
        Minecraft.getInstance().getTextureManager().register(id, tex);
        if (sheet) tex.upload();
    }

    /**
     * Draws the model at (x,y) scaled to `px` pixels. If `drag` is true, holding the left mouse button inside the
     * square turns the model.
     * @return false when there is nothing to show
     */
    public boolean draw(GuiGraphics g, int x, int y, int px, boolean drag, int mx, int my) {
        if (!ready()) return false;
        if (cached()) return drawCached(g, x, y, px);
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1.0e9f);
        last = now;

        boolean inside = mx >= x && my >= y && mx < x + px && my < y + px;
        boolean down = Minecraft.getInstance().mouseHandler.isLeftPressed();
        if (drag) {
            long win = GLFW.glfwGetCurrentContext();
            double[] cx = new double[1], cy = new double[1];
            if (down && !dragging && inside) {
                // grab: hide + lock the cursor to the viewer while turning, so it can't slip off the model
                GLFW.glfwGetCursorPos(win, cx, cy);
                startX = prevX = cx[0]; startY = prevY = cy[0];
                GLFW.glfwSetInputMode(win, GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_DISABLED);
                dragging = true;
            } else if (dragging && down) {
                GLFW.glfwGetCursorPos(win, cx, cy);
                yaw += (float) (cx[0] - prevX) * 0.5f;
                pitch = Math.max(-80f, Math.min(80f, pitch + (float) (cy[0] - prevY) * 0.4f));
                prevX = cx[0]; prevY = cy[0];
                dirty = true;
            } else if (dragging) {
                endDrag();
            }
        }
        if (anim && !dragging) {
            if (!wasAnim) { yaw = 18f; pitch = 8f; }
            double t = ((now / 1.0e9) % 1.8) / 1.8, sw = 0.28;
            boolean stroke = t < sw;
            if (stroke) {
                swingP = (float) (t / sw); fade = 1f; roll = strokeRoll(swingP);
                if (!prevStroke) swingEvent = true;
            } else {
                double u = (t - sw) / (1 - sw);
                roll = -65f + 120f * (float) (u * u * (3 - 2 * u));          // smooth return to the ready pose
                swingP = 1f; fade = (float) Math.max(0, 1 - (t - sw) / 0.14);   // trail lingers a moment, then fades
            }
            prevStroke = stroke;
            dirty = true;
        } else {
            roll = 0f; swingP = -1f; fade = 0f; prevStroke = false;
            if (spin && !dragging) { yaw += 38f * dt; dirty = true; }
        }
        if (wasAnim != anim) dirty = true;
        wasAnim = anim;
        if (yaw > 360f) yaw -= 360f;

        ensure();
        if (dirty) {
            int[] p = ModelRaster.render(scene, yaw, pitch, roll, size);
            for (int j = 0; j < size; j++) for (int i = 0; i < size; i++) img.setPixel(i, j, p[j * size + i]);
            tex.upload();
            dirty = false;
        }
        g.blit(RenderPipelines.GUI_TEXTURED, id, x, y, 0f, 0f, px, px, size, size, size, size, 0xFFFFFFFF);
        return true;
    }
}
