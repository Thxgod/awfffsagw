package com.bleachskins.client;

import com.bleachskins.core.Categories;
import com.bleachskins.core.Config;
import com.bleachskins.core.Generator;
import com.bleachskins.core.Library;
import com.bleachskins.core.Loadout;
import com.bleachskins.core.PackSource;
import com.bleachskins.core.Scanner;
import com.bleachskins.core.Skin;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.repository.PackRepository;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** Owns the library folder, the saved config, the scanned skins and the generated resource pack. */
public final class SkinManager {
    private SkinManager() {}

    public static final String PACK_DIR_NAME = "SkinsSword3D2D_Generated";
    public static final String PACK_ID = "file/" + PACK_DIR_NAME;

    public record PackInfo(String slug, String name, int skins, boolean enabled) {}

    public static Path libDir, cfgFile, genDir;
    public static Config cfg = new Config();
    public static List<Skin> skins = new ArrayList<>();
    public static List<PackInfo> packs = new ArrayList<>();
    /** ids ("lo_<sig>") of the looks the loaded resource pack knows */
    public static java.util.Set<String> defs = new java.util.HashSet<>();

    /** Called once from the mod initializer, before the game loads its first resources. */
    public static void init() {
        Path game = FabricLoader.getInstance().getGameDir();
        libDir = game.resolve("bleachskins").resolve("packs");
        genDir = game.resolve("resourcepacks").resolve(PACK_DIR_NAME);
        // the old build (v1) overrode vanilla items for EVERYONE on this client - remove its pack so other players look normal again
        try { Generator.deleteTree(game.resolve("resourcepacks").resolve("BleachSkins_Generated")); } catch (IOException ignored) {}
        cfgFile = FabricLoader.getInstance().getConfigDir().resolve("bleachskins.json");
        cfg = Config.load(cfgFile);
        try { Files.createDirectories(libDir); } catch (IOException ignored) {}

        if (!cfg.introCopied) { // give new users the Bleach pack as a first example
            try (InputStream in = SkinManager.class.getResourceAsStream("/default_packs/Bleach_v3.5.1.zip")) {
                Path dst = libDir.resolve("Bleach_v3.5.1.zip");
                if (in != null && !Files.exists(dst)) Files.copy(in, dst);
            } catch (IOException ignored) {}
            cfg.introCopied = true;
            cfg.save(cfgFile);
        }
        rescan();
        regenerate();
        bitesReady = true;
        loadedDefs = new java.util.HashSet<>(defs);   // the pack is loaded right after this, together with the game's resources
    }

    public static void rescan() {
        List<PackSource> all = Library.open(libDir);
        List<Skin> found = new ArrayList<>();
        List<PackInfo> infos = new ArrayList<>();
        for (PackSource p : all) {
            Map<String, Skin> m = Scanner.scan(p);
            boolean on = cfg.enabled(p.slug());
            infos.add(new PackInfo(p.slug(), p.name(), m.size(), on));
            if (on) found.addAll(m.values());
        }
        Library.closeAll(all);
        skins = found;
        packs = infos;
        previewDefs.clear();
    }

    public static void regenerate() {
        List<PackSource> all = Library.open(libDir);
        List<PackSource> enabled = new ArrayList<>();
        for (PackSource p : all) if (cfg.enabled(p.slug())) enabled.add(p);
        try {
            defs = new java.util.HashSet<>(Generator.generate(genDir, enabled, skins, cfg));
            com.bleachskins.core.Retexture.write(genDir, enabled, cfg, CustomizeScreen.drawings(), VanillaAssets::read);
        } catch (IOException | RuntimeException e) {
            BleachSkinsClient.LOGGER.error("Could not build the skin pack", e);
        } finally {
            Library.closeAll(all);
        }
    }

    /** false only on the first run after updating until the bite models are in the loaded pack */
    public static boolean bitesReady = false;

    /** read by MinecraftMixin while a reload starts */
    public static boolean quietReload = false;

    /** Rebuild the pack and make the game load it. */
    public static void applyAndReload() {
        cfg.save(cfgFile);
        regenerate();
        Minecraft mc = Minecraft.getInstance();
        PackRepository repo = mc.getResourcePackRepository();
        repo.reload();
        List<String> sel = new ArrayList<>(repo.getSelectedIds());
        boolean had = sel.contains(PACK_ID);
        if (!had) {
            sel.add(PACK_ID); // last = highest priority
            repo.setSelected(sel);
        }
        quietReload = mc.screen != null;     // from the GUI: keep the screen up instead of the full-screen loading logo
        try {
            mc.options.updateResourcePacks(repo);
            loadedDefs = new java.util.HashSet<>(defs);
            previewDefs.clear();
            if (had) mc.reloadResourcePacks();
        } finally {
            quietReload = false;
        }
        RemoteFx.sendLocal();
    }

    /** load the textures again with the screen still up (mipmap and filtering changes) */
    public static void quietTextureReload() {
        Minecraft mc = Minecraft.getInstance();
        quietReload = mc.screen != null;
        try { mc.reloadResourcePacks(); } finally { quietReload = false; }
    }

    public static String defId(Loadout l) { return "lo_" + l.sig(); }

    /** is this look already part of the loaded resource pack? (then equipping it needs no reload) */
    public static boolean loaded(Loadout l) { return l != null && loadedDefs.contains(defId(l)); }

    /** the definitions the game actually has loaded right now (updated after each reload) */
    public static java.util.Set<String> loadedDefs = new java.util.HashSet<>();

    private static final Map<String, java.util.Optional<String>> previewDefs = new java.util.HashMap<>();

    /** The look other mod users see for a skin preview id (default tweaks), or null if we don't own that skin. */
    public static String defOfPreview(String pv) {
        // called while rendering, so remember the answer (null is remembered too)
        return previewDefs.computeIfAbsent(pv, k -> {
            for (Skin s : skins) if (s.previewId().equals(k)) {
                String id = defId(Loadout.plain(s.category, s.key()));
                return java.util.Optional.ofNullable(loadedDefs.contains(id) ? id : null);
            }
            return java.util.Optional.empty();
        }).orElse(null);
    }

    /** One look of the whole game changed: update the pack on disk and the loaded textures, without a reload when possible. */
    public static boolean applyLook(String group) {
        cfg.save(cfgFile);
        List<PackSource> all = Library.open(libDir);
        List<PackSource> enabled = new ArrayList<>();
        for (PackSource p : all) if (cfg.enabled(p.slug())) enabled.add(p);
        try {
            com.bleachskins.core.Retexture.writeGroup(genDir, enabled, cfg, CustomizeScreen.drawings(), VanillaAssets::read, group);
        } catch (IOException | RuntimeException e) {
            BleachSkinsClient.LOGGER.warn("Could not write look {}", group, e);
        } finally {
            Library.closeAll(all);
        }
        if (LiveTextures.apply(group)) return true;
        return false;                        // shows after the next reload; the screen is never refreshed for it
    }

    /** Save and publish; reloads the resources only when some active look is not in the loaded pack yet. */
    public static void equipChanged() {
        boolean missing = false;
        for (String id : cfg.active.values()) { Loadout l = cfg.loadout(id); if (l != null && skin(l.skin) != null && !loaded(l)) missing = true; }
        for (String id : cfg.activeLeft.values()) { Loadout l = cfg.loadout(id); if (l != null && skin(l.skin) != null && !loaded(l)) missing = true; }
        if (missing) { applyAndReload(); return; }
        cfg.save(cfgFile);
        RemoteFx.sendLocal();
    }

    /** Make sure the generated pack is enabled (first launch). */
    public static void ensureSelected() {
        Minecraft mc = Minecraft.getInstance();
        boolean legacy = mc.options.resourcePacks.removeIf(id -> id.equals("file/BleachSkins_Generated"));
        if (legacy || !mc.options.resourcePacks.contains(PACK_ID)) applyAndReload();
    }

    public static void importPack(Path src) throws IOException {
        Files.createDirectories(libDir);
        String n = src.getFileName().toString();
        if (Files.isRegularFile(src) && n.toLowerCase().endsWith(".zip")) {
            Files.copy(src, libDir.resolve(n), StandardCopyOption.REPLACE_EXISTING);
        } else if (Files.isDirectory(src)) {
            Path dst = libDir.resolve(n);
            try (var walk = Files.walk(src)) {
                for (Path p : (Iterable<Path>) walk::iterator) {
                    Path t = dst.resolve(src.relativize(p).toString());
                    if (Files.isDirectory(p)) Files.createDirectories(t); else Files.copy(p, t, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    public static Skin skin(String key) {
        if (key == null) return null;
        for (Skin s : skins) if (s.key().equals(key)) return s;
        return null;
    }

    /** do we own the skin behind this preview id (sent by another mod user)? */
    public static boolean hasPreview(String pv) {
        for (Skin s : skins) if (s.previewId().equals(pv)) return true;
        return false;
    }

    public static List<Skin> skinsOf(String cat) {
        List<Skin> l = new ArrayList<>();
        for (Skin s : skins) if (s.category.equals(cat)) l.add(s);
        return l;
    }

    /** sword and bow first, then the rest alphabetically */
    public static List<String> categories() {
        TreeSet<String> rest = new TreeSet<>();
        Map<String, Boolean> seen = new LinkedHashMap<>();
        for (Skin s : skins) seen.put(s.category, true);
        List<String> r = new ArrayList<>();
        for (String c : new String[] {"sword", "bow"}) if (seen.containsKey(c)) r.add(c);
        for (String c : seen.keySet()) if (!c.equals("sword") && !c.equals("bow")) rest.add(c);
        r.addAll(rest);
        return r;
    }

    public static String label(String cat) { return Categories.label(cat); }
}
