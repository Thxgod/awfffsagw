package com.bleachskins.client;

import com.bleachskins.core.Looks;
import com.bleachskins.core.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Every page has its own tab on one row, with its name when there is room; nothing has to be scrolled. */
final class TopMenu {
    record Item(String label, ItemStack icon, boolean selected, Runnable action, List<Item> children, boolean minor) {
        Item(String label, ItemStack icon, boolean selected, Runnable action, List<Item> children) { this(label, icon, selected, action, children, false); }
        /** the mod's own picture for this tab */
        Identifier picture() { return tabIcon(label); }
    }

    /** what the Game tab holds; every other look is under Textures */
    private static final String[] GAME = {"combat", "plants", "crystal", "anchor", "totem", "pearl", "gapple", "shield", "glowstone", "obsidian", "fire", "cobweb", "grass", "hearts", "food", "crosshair"};
    private static final Identifier FIRE = Identifier.withDefaultNamespace("textures/block/fire_0.png");
    private static final Identifier HEART = Identifier.withDefaultNamespace("hud/heart/full");
    private static final int ROW = 18, CELL_W = 120, CELL_H = 19;

    private final List<Item> items = new ArrayList<>();
    private int x, y, w;
    private Item open = null;
    private String fireLabel = "", heartLabel = "", plantsLabel = "", combatLabel = "";
    private static ItemStack zombie;

    /** from the game's own files, so it stays even while grass is erased in the world */
    private static java.awt.image.BufferedImage grassPicture() {
        var im = com.bleachskins.core.Retexture.image(VanillaAssets.read("assets/minecraft/textures/block/short_grass.png"));
        return im == null ? null : com.bleachskins.core.Retexture.tint(im, 0x5FA83E);
    }
    private int labels = 2;      // 2 every tab shows its name, 1 only the main ones, 0 only the selected one (others on hover)

    private static final java.util.Map<String, Identifier> PICTURES = new java.util.HashMap<>();
    private static void picture(String label, String file) {
        PICTURES.put(label, Identifier.fromNamespaceAndPath("bleachskins", "textures/gui/icons/" + file + ".png"));
    }
    private static Identifier tabIcon(String label) { return PICTURES.get(label); }

    private static String ts(String k) { return Component.translatable("gui.bleachskins." + k).getString(); }
    private static ItemStack icon(String item) { return new ItemStack(BuiltInRegistries.ITEM.getValue(Identifier.fromNamespaceAndPath("minecraft", item))); }

    /** @param selected a page of the game, a browse: list, or one of MainScreen's tab keys ("@skins" for the weapons) */
    void build(MainScreen main, String selected, Consumer<String> openLook, int x, int y, int w) {
        items.clear();
        open = null;
        PICTURES.clear();
        fireLabel = ts("look_fire");
        heartLabel = ts("look_hearts");
        plantsLabel = ts("look_plants");
        combatLabel = ts("look_combat");
        this.x = x; this.y = y; this.w = w;
        List<Item> textures = new ArrayList<>();
        java.util.Set<String> pvp = java.util.Set.of(GAME);
        for (String s : Looks.FEATURED.keySet()) if (!pvp.contains(s))
            textures.add(new Item(ts("look_" + s), icon(Looks.ICONS.getOrDefault(s, "painting")), s.equals(selected), () -> openLook.accept(s), null));
        String[] icons = {"apple", "grass_block", "armor_stand", "painting"}, lists = {"browse:item/", "browse:block/", "browse:entity/", "browse:"};
        for (int i = 0; i < lists.length; i++) {
            String s = lists[i];
            textures.add(new Item(ts("look_" + s.replace("browse:", "browse_").replace("/", "")), icon(icons[i]), s.equals(selected), () -> openLook.accept(s), null));
        }
        items.add(new Item(ts("menu_skins"), icon("diamond_sword"), MainScreen.SKINS.equals(selected), main::openSkins, null));
        for (String s : GAME) items.add(new Item(ts("look_" + s), icon(Looks.ICONS.getOrDefault(s, "painting")), s.equals(selected), () -> openLook.accept(s), null, true));
        items.add(new Item(ts("menu_textures") + " ▾", icon("painting"), selected != null && (selected.startsWith("browse:") || (Looks.FEATURED.containsKey(selected) && !pvp.contains(selected))), null, textures));
        items.add(new Item(ts("tab_packs"), icon("chest"), MainScreen.PACKS.equals(selected), () -> main.openTab(MainScreen.PACKS), null));
        items.add(new Item(ts("tab_theme"), icon("brush"), MainScreen.THEME.equals(selected), () -> main.openTab(MainScreen.THEME), null));
        items.add(new Item(ts("tab_easy"), icon("redstone"), MainScreen.EASY.equals(selected), () -> main.openTab(MainScreen.EASY), null));

        Font f = Minecraft.getInstance().font;
        for (labels = 2; labels > 0; labels--) {
            int total = -2;
            for (Item i : items) total += width(f, i) + 2;
            if (total <= w) break;
        }
    }

    private boolean named(Item i) { return i.selected || i == open || labels == 2 || (labels == 1 && !i.minor); }
    private int width(Font f, Item i) { return named(i) ? 19 + f.width(i.label) + 6 : 19; }
    private int perRow() { return Math.max(1, (w - 4) / CELL_W); }
    private int panelH() { return (open.children.size() + perRow() - 1) / perRow() * CELL_H + 4; }

    private int childAt(double mx, double my) {
        int top = y + ROW + 2;
        if (mx < x + 2 || my < top + 2) return -1;
        int c = (int) (mx - x - 2) / CELL_W, r = (int) (my - top - 2) / CELL_H, i = r * perRow() + c;
        return c < perRow() && i < open.children.size() ? i : -1;
    }

    /** takes the click when it is on the tabs, or anywhere while a panel is open */
    boolean clicked(double mx, double my) {
        if (open != null) {
            int i = childAt(mx, my);
            Item was = open;
            open = null;
            if (i >= 0) { was.children.get(i).action.run(); return true; }
            if (my >= y && my < y + ROW && tabAt(mx) == was) return true;      // pressing its tab again closes it
        }
        if (my < y || my >= y + ROW) return false;
        Item t = tabAt(mx);
        if (t == null) return false;
        if (t.children != null) open = t; else t.action.run();
        return true;
    }

    private Item tabAt(double mx) {
        Font f = Minecraft.getInstance().font;
        int ix = x;
        for (Item i : items) {
            int iw = width(f, i);
            if (mx >= ix && mx < ix + iw) return i;
            ix += iw + 2;
        }
        return null;
    }

    void paint(GuiGraphics g, int mx, int my, int acc, Theme t) {
        Font f = Minecraft.getInstance().font;
        Thumbs.frame();
        int ix = x, hintX = x;
        String hint = "";
        for (Item i : items) {
            int iw = width(f, i);
            boolean hot = my >= y && my < y + ROW && mx >= ix && mx < ix + iw, on = i.selected || i == open;
            Ui.rect(g, ix, y, iw, ROW, t.radius(), on ? acc : hot ? t.a(t.hot) : t.a(t.card));
            Identifier pic = i.picture();
            var gui = net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED;
            if (pic != null) g.blit(gui, pic, ix + 1, y + 1, 0f, 0f, 16, 16, 32, 32, 32, 32, on || hot ? 0xFFFFFFFF : t.solid(t.dim));
            else if (i.label.equals(fireLabel)) g.blit(gui, FIRE, ix + 1, y + 1, 0f, 0f, 16, 16, 16, 512);      // one frame of the real fire
            else if (i.label.equals(heartLabel)) g.blitSprite(gui, HEART, ix + 2, y + 2, 14, 14);
            else if (i.label.equals(plantsLabel)) Thumbs.draw(g, "tab:plants", TopMenu::grassPicture, ix + 1, y + 1, 16);
            else if (i.label.equals(combatLabel)) {             // a mob in its hitbox, in the colour you chose
                g.pose().pushMatrix();
                g.pose().translate(ix + 9f, y + 9f);
                g.pose().scale(0.75f, 0.75f);
                if (zombie == null) zombie = new ItemStack(net.minecraft.world.item.Items.ZOMBIE_HEAD);
                g.renderItem(zombie, -8, -8);
                g.pose().popMatrix();
                g.renderOutline(ix + 2, y + 2, 14, 14, 0xFF000000 | CombatBox.shaded(SkinManager.cfg.combatReady));
            }
            else g.renderItem(i.icon, ix + 1, y + 1);
            if (named(i)) g.drawString(f, i.label, ix + 19, y + 5, on ? 0xFFFFFFFF : t.solid(hot ? t.text : t.dim));
            else if (hot) hint = i.label;
            if (hot) hintX = ix;
            ix += iw + 2;
        }
        if (!hint.isEmpty() && open == null) {
            g.nextStratum();
            Ui.rect(g, hintX, y + ROW + 2, f.width(hint) + 8, 14, t.radius(), t.solid(t.panel));
            g.drawString(f, hint, hintX + 4, y + ROW + 5, t.solid(t.text));
        }
        if (open == null) return;
        g.nextStratum();
        int top = y + ROW + 2;
        Ui.rect(g, x, top, w, panelH(), t.radius(), t.solid(t.panel));
        Ui.outline(g, x, top, w, panelH(), t.radius(), acc);
        int hover = childAt(mx, my);
        for (int n = 0; n < open.children.size(); n++) {
            Item c = open.children.get(n);
            int cx = x + 2 + n % perRow() * CELL_W, cy = top + 2 + n / perRow() * CELL_H;
            if (c.selected || n == hover) Ui.rect(g, cx, cy, CELL_W - 2, CELL_H - 1, t.radius(), c.selected ? acc : t.solid(t.hot));
            g.renderItem(c.icon, cx + 1, cy + 1);
            g.drawString(f, f.plainSubstrByWidth(c.label, CELL_W - 22), cx + 19, cy + 5, c.selected || n == hover ? 0xFFFFFFFF : t.solid(t.text));
        }
    }
}
