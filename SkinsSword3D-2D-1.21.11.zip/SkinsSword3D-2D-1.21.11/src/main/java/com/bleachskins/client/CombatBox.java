package com.bleachskins.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.gui.components.debug.DebugScreenEntryStatus;
import net.minecraft.world.entity.Entity;

/** Combat hitboxes: the entity under your crosshair (in reach) takes the aim colour, and the hit colour while you are hitting. */
public final class CombatBox {
    private CombatBox() {}

    /** turns the game's own hitbox view (F3+B) on or off */
    public static void setShown(boolean on) {
        Minecraft mc = Minecraft.getInstance();
        mc.debugEntries.setStatus(DebugScreenEntries.ENTITY_HITBOXES, on ? DebugScreenEntryStatus.ALWAYS_ON : DebugScreenEntryStatus.NEVER);
    }

    public static boolean hide(Entity entity) {
        var cfg = SkinManager.cfg;
        return cfg.combatBox && !cfg.combatBoxAll && Minecraft.getInstance().crosshairPickEntity != entity;
    }

    public static boolean aimed(Entity entity) {
        Minecraft mc = Minecraft.getInstance();
        return SkinManager.cfg.combatBox && mc.player != null && mc.crosshairPickEntity == entity;
    }

    public static float lineWidth() { return 2.5f * SkinManager.cfg.combatWidth; }

    /** the chosen colour at the chosen strength */
    public static int shaded(int rgb) { return Ui.darken(rgb, 1f - SkinManager.cfg.combatDarker) & 0xFFFFFF; }

    public static int colour(Entity entity, int normal) {
        var cfg = SkinManager.cfg;
        Minecraft mc = Minecraft.getInstance();
        if (!cfg.combatBox || mc.player == null || mc.crosshairPickEntity != entity) return normal;
        boolean hitting = mc.options.keyAttack.isDown() || mc.player.swinging;
        return 0xFF000000 | shaded(hitting ? cfg.combatHitColour() : cfg.combatReady);
    }
}
