package com.bleachskins.client;

import com.bleachskins.core.Theme;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

/** Colour square + hue bar. Both are small textures, so drawing them costs two quads a frame. */
final class ColorPicker {
    private static final int SIZE = 64;
    private static final Identifier SQUARE = Identifier.fromNamespaceAndPath("bleachskins", "picker_square");
    private static final Identifier HUE = Identifier.fromNamespaceAndPath("bleachskins", "picker_hue");
    private static DynamicTexture squareTex;
    private static NativeImage squareImg;
    private static float drawnHue = -1f;
    private static boolean hueReady = false;

    final int x, y, w, h;
    float hue = 0f, sat = 0f, val = 1f;

    ColorPicker(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }

    int rgb() { return Theme.hsv(hue, sat, val); }

    void set(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        val = max;
        sat = max == 0 ? 0 : d / max;
        if (d > 0) {
            float hh = max == r ? (g - b) / d : max == g ? 2 + (b - r) / d : 4 + (r - g) / d;
            hue = ((hh / 6f) % 1f + 1f) % 1f;
        }
    }

    private void prepare() {
        var textures = Minecraft.getInstance().getTextureManager();
        if (!hueReady) {
            NativeImage bar = new NativeImage(256, 1, false);
            for (int i = 0; i < 256; i++) bar.setPixel(i, 0, 0xFF000000 | Theme.hsv(i / 256f, 1f, 1f));
            DynamicTexture t = new DynamicTexture(() -> "bleachskins_picker_hue", bar);
            textures.register(HUE, t);
            t.upload();
            hueReady = true;
        }
        if (squareTex == null) {
            squareImg = new NativeImage(SIZE, SIZE, false);
            squareTex = new DynamicTexture(() -> "bleachskins_picker_square", squareImg);
            textures.register(SQUARE, squareTex);
        }
        if (hue != drawnHue) {
            for (int j = 0; j < SIZE; j++) for (int i = 0; i < SIZE; i++)
                squareImg.setPixel(i, j, 0xFF000000 | Theme.hsv(hue, i / (float) (SIZE - 1), 1f - j / (float) (SIZE - 1)));
            squareTex.upload();
            drawnHue = hue;
        }
    }

    void render(GuiGraphics g) {
        prepare();
        int sq = h - 12;
        g.blit(RenderPipelines.GUI_TEXTURED, SQUARE, x, y, 0f, 0f, w, sq, SIZE, SIZE, SIZE, SIZE, 0xFFFFFFFF);
        g.blit(RenderPipelines.GUI_TEXTURED, HUE, x, y + sq + 3, 0f, 0f, w, h - sq - 3, 256, 1, 256, 1, 0xFFFFFFFF);
        int mx = x + (int) (sat * (w - 1)), my = y + (int) ((1 - val) * (sq - 1)), hx = x + (int) (hue * (w - 1));
        g.renderOutline(mx - 1, my - 1, 3, 3, 0xFFFFFFFF);
        g.fill(hx, y + sq + 2, hx + 1, y + h + 1, 0xFFFFFFFF);
    }

    /** @return true if the point was on the picker */
    boolean pick(double mx, double my) {
        int sq = h - 12;
        if (mx < x || mx >= x + w) return false;
        if (my >= y && my < y + sq) { sat = (float) ((mx - x) / (w - 1)); val = 1f - (float) ((my - y) / (sq - 1)); return true; }
        if (my >= y + sq + 2 && my < y + h) { hue = (float) ((mx - x) / w); return true; }
        return false;
    }
}
