package com.bleachskins.client;

import com.bleachskins.core.Loadout;
import com.bleachskins.net.EffectsPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Effects of other players, received from the server (only mod users send/receive these). */
public final class RemoteFx {
    private RemoteFx() {}

    private static final Map<UUID, List<EffectsPayload.Entry>> OTHERS = new ConcurrentHashMap<>();

    public static List<EffectsPayload.Entry> get(UUID id) { return OTHERS.get(id); }
    public static void clear() { OTHERS.clear(); }

    public static void receive(EffectsPayload p) {
        if (p.entries().isEmpty()) OTHERS.remove(p.player()); else OTHERS.put(p.player(), p.entries());
    }

    /** Tell the server (which forwards to other mod users) what effects we currently have. */
    public static void sendLocal() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !ClientPlayNetworking.canSend(EffectsPayload.TYPE)) return;
        if (!SkinManager.cfg.shareMine) { ClientPlayNetworking.send(new EffectsPayload(mc.player.getUUID(), List.of())); return; }
        List<EffectsPayload.Entry> list = new ArrayList<>();
        java.util.Set<String> cats = new java.util.LinkedHashSet<>(SkinManager.cfg.active.keySet());
        cats.addAll(SkinManager.cfg.activeLeft.keySet());
        for (String cat : cats) {
            Loadout right = SkinManager.cfg.activeFor(cat);
            Loadout left = SkinManager.cfg.activeLeftFor(cat) != null ? SkinManager.cfg.activeLeftFor(cat) : right;
            add(list, cat, 0, right);
            add(list, cat, 1, left);
        }
        ClientPlayNetworking.send(new EffectsPayload(mc.player.getUUID(), list));
    }

    private static void add(List<EffectsPayload.Entry> list, String cat, int hand, Loadout l) {
        if (l == null) return;
        var sk = SkinManager.skin(l.skin);
        String pv = sk == null ? "" : sk.previewId();
        if (pv.isEmpty() && "none".equals(l.particle) && "none".equals(l.sound) && "none".equals(l.swing)) return;
        int color = l.fxColor >= 0 ? l.fxColor : l.color;
        list.add(new EffectsPayload.Entry(cat, hand, pv, l.particle, color, l.rate, l.length, l.fxSize, l.sound, l.volume, l.pitch, l.swing));
    }
}
