package com.bleachskins.client;

import com.bleachskins.core.Looks;
import com.bleachskins.mixin.GuiRendererInvoker;
import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.SpriteContents;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.Identifier;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.List;

/**
 * Changes textures the game has already loaded, so a new look shows at once with no resource reload.
 * A picture of another size is fitted to the loaded one, so choosing a look never needs a reload.
 * Private fields are found by type, because their names differ between dev and release builds.
 */
final class LiveTextures {
    private LiveTextures() {}

    private record Hit(TextureAtlas atlas, TextureAtlasSprite sprite) {}

    static boolean apply(String group) {
        Minecraft mc = Minecraft.getInstance();
        try {
            List<String> files = Looks.files(group);
            for (String f : files) if (!one(mc, "minecraft", f)) return false;
            if (files.contains("block/cobweb") && !one(mc, "bleachskins", "block/cobweb_frame")) return false;
            for (var food : Looks.FOODS.entrySet()) if (files.contains(food.getValue()))
                for (int n = 1; n <= Looks.BITE_STAGES; n++)
                    if (!one(mc, "bleachskins", "item/bite/" + food.getKey() + "_" + n)) return false;
            GuiRenderer gui = find(mc.gameRenderer, GameRenderer.class, GuiRenderer.class);
            if (gui != null) ((GuiRendererInvoker) gui).bleachskins$invalidate();
            return true;
        } catch (Throwable t) {
            BleachSkinsClient.LOGGER.warn("Live texture update failed, reloading instead", t);
            return false;
        }
    }

    private static boolean one(Minecraft mc, String ns, String file) throws Exception {
        Identifier path = Identifier.fromNamespaceAndPath(ns, "textures/" + file + ".png");
        Identifier name = Identifier.fromNamespaceAndPath(ns, file.startsWith("gui/sprites/") ? file.substring("gui/sprites/".length()) : file);
        Hit[] hit = new Hit[1];
        mc.getAtlasManager().forEach((id, atlas) -> {
            TextureAtlasSprite s = atlas.getSprite(name);
            if (hit[0] == null && s != atlas.missingSprite()) hit[0] = new Hit(atlas, s);
        });
        if (hit[0] == null) {                                // its own texture file: the game loads it again when next needed
            mc.getTextureManager().release(path);
            return true;
        }
        SpriteContents c = hit[0].sprite.contents();
        try (InputStream in = mc.getResourceManager().getResource(path).orElseThrow().open();
             NativeImage image = NativeImage.read(in)) {
            // the atlas keeps its size without a reload, so a picture of another size is fitted to it;
            // the full size shows after the next resource reload or game start
            int w = c.width(), h = c.height(), iw = image.getWidth(), fh = image.getHeight() % iw == 0 ? iw : image.getHeight();
            int count = Math.max(1, image.getHeight() / fh);
            CommandEncoder enc = RenderSystem.getDevice().createCommandEncoder();
            if (!c.isAnimated()) {
                GpuTexture tex = hit[0].atlas.getTexture();
                int x = Math.round(hit[0].sprite.getU0() * tex.getWidth(0)), y = Math.round(hit[0].sprite.getV0() * tex.getHeight(0));
                try (NativeImage fit = frame(image, 0, iw, fh, w, h)) { upload(enc, tex, fit, 0, w, h, x, y); }
                return true;
            }
            Int2ObjectMap<GpuTextureView> frames = framesOf(hit[0].atlas, c);
            if (frames == null) return false;
            for (Int2ObjectMap.Entry<GpuTextureView> e : frames.int2ObjectEntrySet())
                try (NativeImage fit = frame(image, e.getIntKey() % count, iw, fh, w, h)) { upload(enc, e.getValue().texture(), fit, 0, w, h, 0, 0); }
            return true;
        }
    }

    /** one frame of a picture, resized to the sprite */
    private static NativeImage frame(NativeImage src, int index, int sw, int sh, int w, int h) {
        NativeImage out = new NativeImage(w, h, false);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) out.setPixel(x, y, src.getPixel(x * sw / w, index * sh + y * sh / h));
        return out;
    }

    /** writes one frame and its smaller mip levels */
    private static void upload(CommandEncoder enc, GpuTexture tex, NativeImage src, int srcY, int w, int h, int x, int y) {
        NativeImage level = new NativeImage(w, h, false);
        for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) level.setPixel(i, j, src.getPixel(i, srcY + j));
        for (int m = 0; m < tex.getMipLevels() && (w >> m) > 0 && (h >> m) > 0; m++) {
            enc.writeToTexture(tex, level, m, 0, x >> m, y >> m, w >> m, h >> m, 0, 0);
            NativeImage smaller = half(level);
            level.close();
            level = smaller;
        }
        level.close();
    }

    private static NativeImage half(NativeImage s) {
        int w = Math.max(1, s.getWidth() / 2), h = Math.max(1, s.getHeight() / 2);
        NativeImage d = new NativeImage(w, h, false);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int a = 0, r = 0, g = 0, b = 0;
            for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
                int c = s.getPixel(Math.min(s.getWidth() - 1, x * 2 + i), Math.min(s.getHeight() - 1, y * 2 + j)), ca = c >>> 24;
                a += ca; r += ((c >> 16) & 255) * ca; g += ((c >> 8) & 255) * ca; b += (c & 255) * ca;
            }
            d.setPixel(x, y, a == 0 ? 0 : ((a / 4) << 24) | ((r / a) << 16) | ((g / a) << 8) | (b / a));
        }
        return d;
    }

    @SuppressWarnings("unchecked")
    private static Int2ObjectMap<GpuTextureView> framesOf(TextureAtlas atlas, SpriteContents contents) throws Exception {
        for (Field lf : TextureAtlas.class.getDeclaredFields()) {
            if (!List.class.isAssignableFrom(lf.getType())) continue;
            lf.setAccessible(true);
            Object list = lf.get(atlas);
            if (list == null) continue;
            for (Object state : (List<?>) list) {
                if (!(state instanceof SpriteContents.AnimationState)) break;
                if (ownerOf(state) == contents) return find(state, state.getClass(), Int2ObjectMap.class);
            }
        }
        return null;
    }

    /** AnimationState -> its animation info -> the SpriteContents that owns it */
    private static SpriteContents ownerOf(Object state) throws Exception {
        for (Field f : state.getClass().getDeclaredFields()) {
            if (f.getType().isPrimitive() || f.getType().isArray() || f.getType().getEnclosingClass() != SpriteContents.class) continue;
            f.setAccessible(true);
            Object info = f.get(state);
            if (info == null) continue;
            SpriteContents c = find(info, info.getClass(), SpriteContents.class);
            if (c != null) return c;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static <T> T find(Object owner, Class<?> in, Class<T> type) throws Exception {
        for (Field f : in.getDeclaredFields())
            if (type.isAssignableFrom(f.getType()) && !java.lang.reflect.Modifier.isStatic(f.getModifiers())) {
                f.setAccessible(true);
                return (T) f.get(owner);
            }
        return null;
    }
}
