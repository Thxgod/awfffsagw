package com.bleachskins.client;

import com.bleachskins.core.Theme;
import com.mojang.blaze3d.platform.NativeImage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Optional picture behind the GUI. Any png/jpg/gif/bmp in bleachskins/backgrounds works; it is converted
 * to PNG in memory, shrunk to at most 1920 px wide, and drawn "cover" style with the theme's colour + opacity.
 */
public final class BgImage {
    private BgImage() {}

    private static final Identifier ID = Identifier.fromNamespaceAndPath("bleachskins", "gui_background");
    private static String loaded = null;
    private static DynamicTexture tex;
    private static int tw, th;

    public static Path dir() {
        return FabricLoader.getInstance().getGameDir().resolve("bleachskins").resolve("backgrounds");
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try {
            Files.createDirectories(dir());
            try (Stream<Path> s = Files.list(dir())) {
                s.filter(Files::isRegularFile).map(p -> p.getFileName().toString()).sorted().forEach(n -> {
                    String l = n.toLowerCase(Locale.ROOT);
                    if (l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".gif") || l.endsWith(".bmp")) out.add(n);
                });
            }
        } catch (Exception ignored) {}
        return out;
    }

    /** forget the cached texture (after the file changed) */
    public static void reset() { release(); loaded = null; }

    private static void release() {
        if (tex != null) {
            try { Minecraft.getInstance().getTextureManager().release(ID); } catch (Exception ignored) {}
            tex = null;
        }
    }

    private static void load(String name) {
        loaded = name;
        release();
        if (name == null || name.isEmpty()) return;
        try {
            BufferedImage src = ImageIO.read(dir().resolve(name).toFile());
            if (src == null) return;
            int w = src.getWidth(), h = src.getHeight();
            if (w > 1920) { h = Math.round(h * 1920f / w); w = 1920; }
            BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2 = img.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(src, 0, 0, w, h, null);
            g2.dispose();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            ImageIO.write(img, "png", bo);
            NativeImage ni = NativeImage.read(new ByteArrayInputStream(bo.toByteArray()));
            tw = ni.getWidth(); th = ni.getHeight();
            tex = new DynamicTexture(() -> "bleachskins_background", ni);
            Minecraft.getInstance().getTextureManager().register(ID, tex);
        } catch (Throwable e) {
            BleachSkinsClient.LOGGER.warn("Could not load background image {}", name, e);
            tex = null;
        }
    }

    /** @return true if an image was drawn */
    public static boolean draw(GuiGraphics g, int w, int h, Theme t) {
        if (t.bgImage == null || t.bgImage.isEmpty()) return false;
        if (!t.bgImage.equals(loaded)) load(t.bgImage);
        if (tex == null) return false;
        float sr = (float) tw / th, dr = (float) w / h;
        int uw, vh, u, v;
        if (sr > dr) { vh = th; uw = Math.round(th * dr); u = (tw - uw) / 2; v = 0; }
        else { uw = tw; vh = Math.round(tw / dr); u = 0; v = (th - vh) / 2; }
        int color = ((int) (Math.max(0f, Math.min(1f, t.bgOpacity)) * 255) << 24) | (t.bgColor & 0xFFFFFF);
        g.blit(RenderPipelines.GUI_TEXTURED, ID, 0, 0, (float) u, (float) v, w, h, uw, vh, tw, th, color);
        return true;
    }
}
