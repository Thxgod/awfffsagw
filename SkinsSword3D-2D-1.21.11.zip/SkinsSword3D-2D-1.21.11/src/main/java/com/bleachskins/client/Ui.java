package com.bleachskins.client;

import net.minecraft.client.gui.GuiGraphics;

/** Small 2D drawing helpers: rounded rectangles, bottom glow, slanted buttons. Radius 0 = plain squares. */
public final class Ui {
    private Ui() {}

    /** how far row i (0 = outermost) of a corner of radius r is pulled in */
    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    public static void rect(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, argb); return; }
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            g.fill(x + in, y + i, x + w - in, y + i + 1, argb);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, argb);
        }
        g.fill(x, y + r, x + w, y + h - r, argb);
    }

    /** 1px outline that follows the rounded corners */
    public static void outline(GuiGraphics g, int x, int y, int w, int h, int r, int argb) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.renderOutline(x, y, w, h, argb); return; }
        int prev = r;
        for (int i = 0; i < r; i++) {
            int in = inset(r, i);
            int step = i == 0 ? w - 2 * in : Math.max(1, prev - in);
            if (i == 0) {
                g.fill(x + in, y, x + w - in, y + 1, argb);
                g.fill(x + in, y + h - 1, x + w - in, y + h, argb);
            } else {
                g.fill(x + in, y + i, x + in + step, y + i + 1, argb);
                g.fill(x + w - in - step, y + i, x + w - in, y + i + 1, argb);
                g.fill(x + in, y + h - 1 - i, x + in + step, y + h - i, argb);
                g.fill(x + w - in - step, y + h - 1 - i, x + w - in, y + h - i, argb);
            }
            prev = in;
        }
        g.fill(x, y + r, x + 1, y + h - r, argb);
        g.fill(x + w - 1, y + r, x + w, y + h - r, argb);
    }

    /** soft coloured glow rising from the bottom edge of a rounded card (like rarity tiles) */
    public static void glow(GuiGraphics g, int x, int y, int w, int h, int r, int rgb, float strength) {
        int rows = Math.max(4, (int) (h * 0.55f));
        r = Math.min(r, Math.min(w, h) / 2);
        for (int j = 0; j < rows; j++) {
            int row = h - 1 - j;                       // from bottom up
            float k = 1f - (float) j / rows;           // 1 at the bottom, 0 at the top of the glow
            int a = (int) (255 * strength * k * k);
            if (a <= 0) continue;
            int in = row >= h - r ? inset(r, h - 1 - row) : 0;
            g.fill(x + in, y + row, x + w - in, y + row + 1, (a << 24) | (rgb & 0xFFFFFF));
        }
    }

    /** parallelogram (leaning right) with a darker striped left edge, like the green "Equip" buttons */
    public static void slant(GuiGraphics g, int x, int y, int w, int h, int rgb, boolean hot) {
        float k = 0.28f;
        int off = Math.round((h - 1) * k);
        int body = 0xFF000000 | (hot ? lighten(rgb, 1.15f) : rgb);
        int dark = 0xFF000000 | darken(rgb, 0.62f);
        for (int i = 0; i < h; i++) {
            int lx = x + Math.round((h - 1 - i) * k);
            int rx = lx + w - off;
            g.fill(lx, y + i, rx, y + i + 1, body);
            // diagonal stripe pattern on the left 10px
            for (int sx = lx; sx < lx + 10 && sx < rx; sx += 4)
                g.fill(sx + (i % 4), y + i, Math.min(sx + (i % 4) + 2, rx), y + i + 1, dark);
        }
        g.fill(x + off, y + h - 1, x + w, y + h, 0xFF000000 | darken(rgb, 0.45f)); // bottom edge
    }

    /** glowing rail with a bright knob; the name stands left above it and the value right */
    public static void rail(GuiGraphics g, int x, int y, int w, int h, float frac, String text, boolean hot) {
        var font = net.minecraft.client.Minecraft.getInstance().font;
        int colon = text.lastIndexOf(": ");
        String name = colon >= 0 ? text.substring(0, colon) : text, val = colon >= 0 ? text.substring(colon + 2) : "";
        int textY = y + Math.max(0, (h - 14) / 2);
        int vw = font.width(val);
        g.drawString(font, font.plainSubstrByWidth(name, Math.max(10, w - vw - 4)), x, textY, 0xFFFFFFFF);
        if (vw > 0) g.drawString(font, val, x + w - vw, textY, RAIL | 0xFF000000);

        int ry = y + h - 3, kx = x + 1 + Math.round(Math.max(0f, Math.min(1f, frac)) * (w - 3));
        g.fill(x, ry, x + w, ry + 2, 0x44FFFFFF);
        g.fill(x, ry - 1, kx, ry + 3, withAlpha(RAIL, hot ? 0x66 : 0x40));   // the glow
        g.fill(x, ry, kx, ry + 2, RAIL | 0xFF000000);
        g.fill(kx - 3, ry - 3, kx + 4, ry + 5, withAlpha(RAIL, hot ? 0x70 : 0x45));
        g.fill(kx - 1, ry - 3, kx + 2, ry + 5, 0xFFFFFFFF);
    }
    private static final int RAIL = 0x5CE1FF;

    /** a slider that paints itself */
    public interface SelfPainted {}

    public static int darken(int rgb, float f) {
        int r = (int) (((rgb >> 16) & 255) * f), gg = (int) (((rgb >> 8) & 255) * f), b = (int) ((rgb & 255) * f);
        return (r << 16) | (gg << 8) | b;
    }

    public static int lighten(int rgb, float f) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f)), gg = Math.min(255, (int) (((rgb >> 8) & 255) * f)), b = Math.min(255, (int) ((rgb & 255) * f));
        return (r << 16) | (gg << 8) | b;
    }

    public static int withAlpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }
}
