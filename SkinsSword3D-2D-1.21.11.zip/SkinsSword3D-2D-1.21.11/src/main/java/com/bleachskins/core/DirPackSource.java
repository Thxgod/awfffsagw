package com.bleachskins.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public final class DirPackSource implements PackSource {
    private Path root;
    private final String name, slug;

    public DirPackSource(Path dir) {
        this.root = dir;
        this.name = dir.getFileName().toString();
        this.slug = Util.slug(name);
        if (!Files.exists(dir.resolve("pack.mcmeta"))) {
            try (Stream<Path> s = Files.list(dir)) {
                s.filter(p -> Files.isDirectory(p) && Files.exists(p.resolve("pack.mcmeta"))).findFirst().ifPresent(p -> root = p);
            } catch (IOException ignored) {}
        }
    }

    @Override public String name() { return name; }
    @Override public String slug() { return slug; }
    @Override public boolean exists(String path) { return Files.isRegularFile(root.resolve(path)); }
    @Override public byte[] read(String path) throws IOException { return Files.readAllBytes(root.resolve(path)); }
    @Override public List<String> list(String prefix) {
        List<String> r = new ArrayList<>();
        Path base = root.resolve(prefix);
        Path scan = Files.isDirectory(base) ? base : base.getParent();
        if (scan == null || !Files.isDirectory(scan)) return r;
        try (Stream<Path> s = Files.walk(scan)) {
            s.filter(Files::isRegularFile).forEach(p -> {
                String rel = root.relativize(p).toString().replace('\\', '/');
                if (rel.startsWith(prefix)) r.add(rel);
            });
        } catch (IOException ignored) {}
        return r;
    }
    @Override public void close() {}
}
