package com.bleachskins.core;

/**
 * Rounded boxes, glow gradients and slanted buttons built only from 1-pixel-high fills, so they work with
 * GuiGraphics.fill (no textures). Kept free of Minecraft classes so it can be unit-tested.
 */
public final class Shapes {
    private Shapes() {}

    public interface Painter { void fill(int x1, int y1, int x2, int y2, int argb); }

    /** How many pixels the left/right edge is pulled in on this row to make a rounded corner. */
    static int inset(int row, int h, int r) {
        int k = Math.min(row, h - 1 - row);
        if (r <= 0 || k >= r) return 0;
        double dy = r - k - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - dy * dy)));
    }

    private static int clampR(int r, int w, int h) { return Math.max(0, Math.min(r, Math.min(w, h) / 2)); }

    public static void rrect(Painter p, int x, int y, int w, int h, int r, int argb) {
        r = clampR(r, w, h);
        int row = 0;
        while (row < h) {                       // merge runs of identical inset into one fill
            int ins = inset(row, h, r), end = row + 1;
            while (end < h && inset(end, h, r) == ins) end++;
            p.fill(x + ins, y + row, x + w - ins, y + end, argb);
            row = end;
        }
    }

    public static void rrectOutline(Painter p, int x, int y, int w, int h, int r, int argb, int t) {
        r = clampR(r, w, h);
        for (int row = 0; row < h; row++) {
            int ins = inset(row, h, r);
            if (row < t || row >= h - t) p.fill(x + ins, y + row, x + w - ins, y + row + 1, argb);
            else {
                p.fill(x + ins, y + row, x + ins + t, y + row + 1, argb);
                p.fill(x + w - ins - t, y + row, x + w - ins, y + row + 1, argb);
            }
        }
    }

    /** Coloured glow rising from the bottom edge of a rounded tile (like the reference screenshot). */
    public static void rrectGlow(Painter p, int x, int y, int w, int h, int r, int rgb, float startFrac, int maxAlpha) {
        r = clampR(r, w, h);
        int start = (int) (h * startFrac);
        for (int row = start; row < h; row++) {
            float k = (row - start) / (float) Math.max(1, h - 1 - start);
            int a = (int) (maxAlpha * k * k);
            if (a <= 0) continue;
            int ins = inset(row, h, r);
            p.fill(x + ins, y + row, x + w - ins, y + row + 1, (a << 24) | (rgb & 0xFFFFFF));
        }
    }

    public static void rrectGradient(Painter p, int x, int y, int w, int h, int r, int topArgb, int bottomArgb) {
        r = clampR(r, w, h);
        for (int row = 0; row < h; row++) {
            float k = h <= 1 ? 0 : row / (float) (h - 1);
            int ins = inset(row, h, r);
            p.fill(x + ins, y + row, x + w - ins, y + row + 1, lerp(topArgb, bottomArgb, k));
        }
    }

    /** Parallelogram button leaning right (the green "Equip" style). */
    public static void slanted(Painter p, int x, int y, int w, int h, float skew, int fill, int border) {
        int shift = Math.round((h - 1) * skew), bw = w - shift;
        for (int j = 0; j < h; j++) {
            int off = Math.round((h - 1 - j) * skew);
            p.fill(x + off, y + j, x + off + bw, y + j + 1, border);
            if (j > 0 && j < h - 1) p.fill(x + off + 1, y + j, x + off + bw - 1, y + j + 1, fill);
        }
    }

    public static int lerp(int a, int b, float k) {
        int out = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = (a >>> s) & 255, cb = (b >>> s) & 255;
            out |= ((int) (ca + (cb - ca) * k) & 255) << s;
        }
        return out;
    }
}
