package com.bleachskins.core;

import com.google.gson.JsonObject;

/** One selectable look found in a library pack. */
public final class Skin {
    public final String packSlug, packName, category, name;
    /** vanilla item the skin was authored for (its fallback model is swapped per target item); null for stand-alone defs */
    public final String baseItem;
    /** namespace to copy wholesale from the pack (stand-alone defs), or null */
    public final String externalNs;
    /** item-model tree ("model" node of an item definition), model ids already rewritten into the generated pack */
    public final JsonObject tree;

    public Skin(String packSlug, String packName, String category, String name, String baseItem, String externalNs, JsonObject tree) {
        this.packSlug = packSlug; this.packName = packName; this.category = category; this.name = name;
        this.baseItem = baseItem; this.externalNs = externalNs; this.tree = tree;
    }

    /** 2 = flat sprite model, 3 = real 3D (box) model; filled in after the pack is generated */
    public int kind = 3;

    /** older pack formats: model files to write (output path -> json) and files to copy (pack path -> output path) */
    public final java.util.Map<String, JsonObject> models = new java.util.LinkedHashMap<>();
    public final java.util.Map<String, String> copies = new java.util.LinkedHashMap<>();

    /** different dimensions are only combined when both skins come from the same pack */
    public boolean canCombine(Skin o) { return o != null && (packSlug.equals(o.packSlug) || kind == o.kind); }

    public String key() { return packSlug + "/" + category + "/" + Util.slug(name); }
    public String previewId() { return "pv_" + Util.hash(key()); }
}
