package com.bleachskins.core;

import com.google.gson.JsonObject;

import java.util.Locale;

final class Util {
    private Util() {}

    /** Lower-case id safe for a resource namespace/path. */
    static String slug(String s) {
        String r = s.toLowerCase(Locale.ROOT).replaceAll("\\.(zip|jar)$", "").replaceAll("[^a-z0-9_.-]+", "_");
        r = r.replaceAll("^_+|_+$", "");
        return r.isEmpty() ? "x" : r;
    }

    static String hash(String s) {
        long h = 0xcbf29ce484222325L;
        for (int i = 0; i < s.length(); i++) { h ^= s.charAt(i); h *= 0x100000001b3L; }
        return Long.toHexString(h);
    }

    static String str(JsonObject o, String k) {
        return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : null;
    }
}
