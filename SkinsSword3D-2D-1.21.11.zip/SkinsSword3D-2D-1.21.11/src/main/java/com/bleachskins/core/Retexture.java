package com.bleachskins.core;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/** Writes the player's choices (pack skin, recolour or drawing) over vanilla textures in the generated pack. */
public final class Retexture {
    private Retexture() {}

    public interface Vanilla { byte[] read(String relativePath); }

    public static String safe(String s) { return s.replaceAll("[^\\p{L}\\p{M}\\p{N}_.-]", "+"); }

    public static BufferedImage image(byte[] png) {
        if (png == null) return null;
        try { return ImageIO.read(new ByteArrayInputStream(png)); } catch (IOException e) { return null; }
    }

    public static byte[] png(BufferedImage im) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        ImageIO.write(im, "png", o);
        return o.toByteArray();
    }

    /** Same shading, new colour. */
    public static BufferedImage tint(BufferedImage src, int rgb) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        int cr = (rgb >> 16) & 255, cg = (rgb >> 8) & 255, cb = rgb & 255;
        for (int y = 0; y < src.getHeight(); y++) for (int x = 0; x < src.getWidth(); x++) {
            int c = src.getRGB(x, y);
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            float l = Math.min(1.25f, (0.3f * r + 0.59f * g + 0.11f * b) / 255f * 1.25f);
            int nr = Math.min(255, (int) (cr * l)), ng = Math.min(255, (int) (cg * l)), nb = Math.min(255, (int) (cb * l));
            out.setRGB(x, y, (c & 0xFF000000) | (nr << 16) | (ng << 8) | nb);
        }
        return out;
    }

    /** Removes the bites of this stage (1..BITE_STAGES) from a food picture: round mouthfuls starting at the top right. */
    public static BufferedImage bitten(BufferedImage src, int stage) {
        int w = src.getWidth(), h = Math.min(src.getHeight(), w);
        int x0 = w, y0 = h, x1 = -1, y1 = -1;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if ((src.getRGB(x, y) >>> 24) != 0) {
            x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y);
        }
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        if (x1 < 0) return out;
        double bw = x1 - x0 + 1, bh = y1 - y0 + 1, r = Math.max(bw, bh);
        // mouthful centre (fraction of the food) and size, in the order they are eaten
        double[][] bites = {{1.0, 0.22, 0.27}, {0.92, 0.72, 0.27}, {0.5, 0.05, 0.27}};
        int count = stage;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int c = src.getRGB(x, y);
            boolean gone = false;
            for (int i = 0; i < count && i < bites.length && !gone; i++) {
                double dx = x + 0.5 - (x0 + bites[i][0] * bw), dy = y + 0.5 - (y0 + bites[i][1] * bh), a = Math.atan2(dy, dx);
                double edge = bites[i][2] * r * (1 + 0.12 * Math.cos(a * 5));   // scalloped: tooth marks
                gone = dx * dx + dy * dy < edge * edge;
            }
            if (!gone) out.setRGB(x, y, c);
        }
        keepBiggestPiece(out);
        return out;
    }

    /** Crumbs left floating by a bite look wrong: keep only the largest connected part. */
    private static void keepBiggestPiece(BufferedImage im) {
        int w = im.getWidth(), h = im.getHeight(), best = 0, bestId = 0, next = 0;
        int[] id = new int[w * h];
        java.util.ArrayDeque<Integer> q = new java.util.ArrayDeque<>();
        for (int i = 0; i < w * h; i++) {
            if (id[i] != 0 || (im.getRGB(i % w, i / w) >>> 24) == 0) continue;
            int size = 0;
            id[i] = ++next;
            q.add(i);
            while (!q.isEmpty()) {
                int c = q.poll(), x = c % w, y = c / w;
                size++;
                for (int[] d : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                    int nx = x + d[0], ny = y + d[1];
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                    int n = ny * w + nx;
                    if (id[n] == 0 && (im.getRGB(nx, ny) >>> 24) != 0) { id[n] = next; q.add(n); }
                }
            }
            if (size > best) { best = size; bestId = next; }
        }
        for (int i = 0; i < w * h; i++) if (id[i] != 0 && id[i] != bestId) im.setRGB(i % w, i / w, 0);
    }

    /** Writes bitten copies of the foods as item definitions bleachskins:bite/<food>_<stage>; only = just these sprites. */
    public static void writeBites(Path out, Vanilla vanilla, List<String> only) throws IOException {
        for (Map.Entry<String, String> e : Looks.FOODS.entrySet()) {
            if (only != null && !only.contains(e.getValue())) continue;
            Path own = out.resolve("assets/minecraft/textures/" + e.getValue() + ".png");
            BufferedImage src = image(Files.isRegularFile(own) ? Files.readAllBytes(own) : vanilla.read("assets/minecraft/textures/" + e.getValue() + ".png"));
            if (src == null) continue;
            for (int n = 1; n <= Looks.BITE_STAGES; n++) {
                String name = e.getKey() + "_" + n;
                Path tex = out.resolve("assets/bleachskins/textures/item/bite/" + name + ".png");
                Path model = out.resolve("assets/bleachskins/models/item/bite/" + name + ".json");
                Path def = out.resolve("assets/bleachskins/items/bite/" + name + ".json");
                Files.createDirectories(tex.getParent()); Files.createDirectories(model.getParent()); Files.createDirectories(def.getParent());
                Files.write(tex, png(bitten(src, n)));
                Files.writeString(model, "{\"parent\":\"minecraft:item/generated\",\"textures\":{\"layer0\":\"bleachskins:item/bite/" + name + "\"}}");
                Files.writeString(def, "{\"model\":{\"type\":\"minecraft:model\",\"model\":\"bleachskins:item/bite/" + name + "\"}}");
            }
        }
    }

    /**
     * Cobweb extras: web size and see-through go into the picture. The block model always has the wire cube, whose
     * sprite is simply empty while the frame is off, so switching it needs no resource reload.
     */
    private static void cobweb(Path out, Config cfg, Vanilla vanilla) throws IOException {
        Path own = out.resolve("assets/minecraft/textures/block/cobweb.png");
        BufferedImage src = image(Files.isRegularFile(own) ? Files.readAllBytes(own) : vanilla.read("assets/minecraft/textures/block/cobweb.png"));
        if (src == null) return;
        Files.createDirectories(own.getParent());
        if (cfg.cobwebSize < 1f || cfg.cobwebOpacity < 1f) Files.write(own, png(cobwebWeb(src, cfg.cobwebSize, cfg.cobwebOpacity)));

        int colour = 0xFFFFFF;
        Config.Choice c = cfg.choices.get("cobweb");
        if (c != null && "style".equals(c.kind)) colour = c.rgb;
        BufferedImage frame = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            float shade = ((x / 2 + y / 2) & 1) == 0 ? 1f : 0.86f;
            int r = (int) (((colour >> 16) & 255) * shade), g = (int) (((colour >> 8) & 255) * shade), b = (int) ((colour & 255) * shade);
            // the corner texel stays see-through: renderers such as Sodium treat a fully solid sprite as solid for good,
            // and then couldn't hide the frame later. The bars only use the middle of the picture.
            if (cfg.cobwebFrame && !(x == 0 && y == 0)) frame.setRGB(x, y, 0xFF000000 | (r << 16) | (g << 8) | b);
        }
        Path ft = out.resolve("assets/bleachskins/textures/block/cobweb_frame.png");
        Files.createDirectories(ft.getParent());
        Files.write(ft, png(frame));

        Path block = out.resolve("assets/minecraft/models/block/cobweb.json");
        Path item = out.resolve("assets/bleachskins/models/item/cobweb_framed.json"), def = out.resolve("assets/bleachskins/items/cobweb_framed.json");
        Files.createDirectories(block.getParent());
        Files.createDirectories(item.getParent());
        Files.createDirectories(def.getParent());
        Files.writeString(block, cobwebModel());
        Files.writeString(item, "{\"parent\":\"minecraft:block/cobweb\"}");   // shown instead of the flat item while the frame is on
        Files.writeString(def, "{\"model\":{\"type\":\"minecraft:model\",\"model\":\"bleachskins:item/cobweb_framed\"}}");
    }

    /** the web squeezed towards the middle of its square, and faded */
    static BufferedImage cobwebWeb(BufferedImage src, float size, float opacity) {
        int w = src.getWidth(), h = src.getHeight();
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        if (size <= 0f) return out;
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int sx = (int) Math.floor(((x + 0.5 - w / 2.0) / size) + w / 2.0), sy = (int) Math.floor(((y + 0.5 - h / 2.0) / size) + h / 2.0);
            if (sx < 0 || sy < 0 || sx >= w || sy >= h) continue;
            int c = src.getRGB(sx, sy), a = Math.round((c >>> 24) * opacity);
            out.setRGB(x, y, (a << 24) | (c & 0xFFFFFF));
        }
        return out;
    }

    private static String bar(float x1, float y1, float z1, float x2, float y2, float z2) {
        StringBuilder faces = new StringBuilder();
        for (String f : new String[] {"north", "south", "east", "west", "up", "down"}) {
            if (faces.length() > 0) faces.append(',');
            faces.append('"').append(f).append("\":{\"uv\":[4,4,12,12],\"texture\":\"#frame\"}");
        }
        return "{\"from\":[" + x1 + "," + y1 + "," + z1 + "],\"to\":[" + x2 + "," + y2 + "," + z2 + "],\"shade\":false,\"faces\":{" + faces + "}}";
    }

    private static String cobwebModel() {
        float t = 0.6f, e = 16f - t;
        List<String> parts = new java.util.ArrayList<>();
        for (float a : new float[] {0f, e}) for (float b : new float[] {0f, e}) {
            parts.add(bar(0, a, b, 16, a + t, b + t));          // along x
            parts.add(bar(a, 0, b, a + t, 16, b + t));          // along y
            parts.add(bar(a, b, 0, a + t, b + t, 16));          // along z
        }
        String rot = "\"rotation\":{\"origin\":[8,8,8],\"axis\":\"y\",\"angle\":45,\"rescale\":true},\"shade\":false";
        String uv = "{\"uv\":[0,0,16,16],\"texture\":\"#web\"}";
        parts.add("{\"from\":[0.8,0,8],\"to\":[15.2,16,8]," + rot + ",\"faces\":{\"north\":" + uv + ",\"south\":" + uv + "}}");
        parts.add("{\"from\":[8,0,0.8],\"to\":[8,16,15.2]," + rot + ",\"faces\":{\"west\":" + uv + ",\"east\":" + uv + "}}");
        return "{\"parent\":\"minecraft:block/block\",\"ambientocclusion\":false,\"textures\":{\"particle\":\"minecraft:block/cobweb\",\"web\":\"minecraft:block/cobweb\",\"frame\":\"bleachskins:block/cobweb_frame\"},\"elements\":["
            + String.join(",", parts) + "]}";
    }

    /** a 15x15 crosshair sprite */
    public static BufferedImage crosshair(String shape, int rgb) {
        BufferedImage im = new BufferedImage(15, 15, BufferedImage.TYPE_INT_ARGB);
        int c = 0xFF000000 | (rgb & 0xFFFFFF);
        for (int y = 0; y < 15; y++) for (int x = 0; x < 15; x++) {
            int dx = x - 7, dy = y - 7, ax = Math.abs(dx), ay = Math.abs(dy);
            double r = Math.sqrt(dx * dx + dy * dy);
            boolean on = switch (shape) {
                case "gap" -> (dx == 0 && ay >= 2 && ay <= 5) || (dy == 0 && ax >= 2 && ax <= 5);
                case "dot" -> ax == 0 && ay == 0;
                case "big_dot" -> r <= 1.5;
                case "circle" -> r > 3.4 && r <= 4.6;
                case "circle_dot" -> (r > 4.4 && r <= 5.6) || (ax == 0 && ay == 0);
                case "square" -> Math.max(ax, ay) == 4;
                case "x" -> ax == ay && ax >= 1 && ax <= 4;
                case "t" -> (dy == 0 && ax <= 4) || (dx == 0 && dy >= 0 && dy <= 5);
                case "chevron" -> ay == ax && dy >= 0 && dy <= 4 || (ax == 0 && ay == 0);
                case "corners" -> Math.max(ax, ay) == 5 && Math.min(ax, ay) >= 3;
                case "diamond" -> ax + ay == 4;
                default -> (dx == 0 && ay <= 4) || (dy == 0 && ax <= 4);
            };
            if (on) im.setRGB(x, y, c);
        }
        return im;
    }

    /** An icon for a crystal skin that only has the entity sheet: the glass face with the cube inside it. */
    public static BufferedImage crystalIcon(BufferedImage sheet) {
        int s = Math.max(1, sheet.getWidth() / 64);
        BufferedImage im = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = im.createGraphics();
        g.drawImage(sheet, 8, 8, 24, 24, 40 * s, 8 * s, 48 * s, 16 * s, null);
        g.drawImage(sheet, 0, 0, 32, 32, 8 * s, 8 * s, 16 * s, 16 * s, null);
        g.dispose();
        return im;
    }

    /** The front of a shield sheet. */
    public static BufferedImage shieldIcon(BufferedImage sheet) {
        int s = Math.max(1, sheet.getWidth() / 64);
        return sheet.getSubimage(s, s, Math.min(12 * s, sheet.getWidth() - s), Math.min(22 * s, sheet.getHeight() - s));
    }

    public static Path drawing(Path root, String group, String name) { return root.resolve(safe(group)).resolve(safe(name)); }

    /** After one group changed: remove its files, then write every choice that covers them. */
    public static void writeGroup(Path out, List<PackSource> packs, Config cfg, Path drawings, Vanilla vanilla, String group) throws IOException {
        List<String> files = Looks.files(group);
        for (String f : files) {
            Files.deleteIfExists(out.resolve("assets/minecraft/textures/" + f + ".png"));
            Files.deleteIfExists(out.resolve("assets/minecraft/textures/" + f + ".png.mcmeta"));
        }
        write(out, packs, cfg, drawings, vanilla, g -> Looks.files(g).stream().anyMatch(files::contains));
        if (files.contains("block/respawn_anchor_side0")) anchorCharges(out, cfg, vanilla);
        lowFire(out, cfg, vanilla, files);
        writeBites(out, vanilla, files);
        if (files.contains("block/cobweb")) cobweb(out, cfg, vanilla);
    }

    private static final List<String> FLAMES = List.of("block/fire_0", "block/fire_1", "block/soul_fire_0", "block/soul_fire_1");

    /** A skin that only has the empty anchor's side: the charged sides use it too, plus the game's charge marks. */
    private static void anchorCharges(Path out, Config cfg, Vanilla vanilla) throws IOException {
        Config.Choice c = cfg.choices.get("anchor");
        if (c == null || "style".equals(c.kind)) return;
        Path base = out.resolve("assets/minecraft/textures/block/respawn_anchor_side0.png");
        if (!Files.isRegularFile(base)) return;
        BufferedImage skin = image(Files.readAllBytes(base));
        BufferedImage v0 = image(vanilla.read("assets/minecraft/textures/block/respawn_anchor_side0.png"));
        if (skin == null) return;
        for (int n = 1; n <= 4; n++) {
            Path dst = out.resolve("assets/minecraft/textures/block/respawn_anchor_side" + n + ".png");
            if (Files.exists(dst)) continue;
            BufferedImage vn = image(vanilla.read("assets/minecraft/textures/block/respawn_anchor_side" + n + ".png"));
            BufferedImage im = new BufferedImage(skin.getWidth(), skin.getHeight(), BufferedImage.TYPE_INT_ARGB);
            for (int y = 0; y < im.getHeight(); y++) for (int x = 0; x < im.getWidth(); x++) {
                int px = skin.getRGB(x, y);
                if (v0 != null && vn != null && v0.getWidth() > 0 && vn.getWidth() == v0.getWidth()) {
                    int vx = x * v0.getWidth() / im.getWidth(), vy = y * v0.getHeight() / im.getHeight();
                    if (v0.getRGB(vx, vy) != vn.getRGB(vx, vy)) px = vn.getRGB(vx, vy);
                }
                im.setRGB(x, y, px);
            }
            Files.write(dst, png(im));
        }
    }

    /** Low fire: squashes each flame frame to the bottom of its square, leaving the top see-through. */
    private static void lowFire(Path out, Config cfg, Vanilla vanilla, List<String> only) throws IOException {
        float k = cfg.blockFireHeight;
        if (k >= 1f) return;
        for (String f : FLAMES) {
            if (!only.contains(f)) continue;
            Path dst = out.resolve("assets/minecraft/textures/" + f + ".png"), meta = out.resolve("assets/minecraft/textures/" + f + ".png.mcmeta");
            boolean own = Files.isRegularFile(dst);
            BufferedImage src = image(own ? Files.readAllBytes(dst) : vanilla.read("assets/minecraft/textures/" + f + ".png"));
            if (src == null) continue;
            int w = src.getWidth(), total = src.getHeight(), fh = total > w && total % w == 0 ? w : total, frames = total / fh;
            int keep = Math.max(1, Math.round(fh * k));
            BufferedImage im = new BufferedImage(w, total, BufferedImage.TYPE_INT_ARGB);
            for (int n = 0; n < frames; n++) for (int y = 0; y < keep; y++) {
                int sy = y * fh / keep, dy = fh - keep + y;
                for (int x = 0; x < w; x++) im.setRGB(x, n * fh + dy, src.getRGB(x, n * fh + sy));
            }
            Files.createDirectories(dst.getParent());
            Files.write(dst, png(im));
            if (!own) {
                byte[] m = vanilla.read("assets/minecraft/textures/" + f + ".png.mcmeta");
                if (m != null) Files.write(meta, m);
            }
        }
    }

    public static void write(Path out, List<PackSource> packs, Config cfg, Path drawings, Vanilla vanilla) throws IOException {
        write(out, packs, cfg, drawings, vanilla, g -> true);
        anchorCharges(out, cfg, vanilla);
        lowFire(out, cfg, vanilla, FLAMES);
        writeBites(out, vanilla, null);
        cobweb(out, cfg, vanilla);
        reserveSlots(out, packs, vanilla);
    }

    private static final int MAX_SLOT = 1024, MAX_MOVING = 128;

    /**
     * The game fixes each picture's room when it loads. Every look that some pack has in HD gets that much room now
     * (a bigger copy of what is in use), so switching to the HD one later is sharp at once, with no reload.
     */
    private static void reserveSlots(Path out, List<PackSource> packs, Vanilla vanilla) {
        java.util.Set<String> done = new java.util.HashSet<>();
        for (String[] files : Looks.FEATURED.values()) for (String f : files) {
            if (!done.add(f) || !(f.startsWith("item/") || f.startsWith("block/") || f.startsWith("gui/sprites/"))) continue;
            try {
                int room = 0;
                for (PackSource p : packs) {
                    String at = Looks.find(p, f);
                    if (at == null) continue;
                    byte[] data = p.read(at);
                    if (data == null || data.length < 24) continue;
                    // the size is in the first bytes of a PNG: no need to unpack the whole picture
                    int w = java.nio.ByteBuffer.wrap(data, 16, 4).getInt(), h = java.nio.ByteBuffer.wrap(data, 20, 4).getInt();
                    if (w <= 0 || h % w != 0) continue;
                    // moving pictures are sent to the graphics card every few ticks, so they stay smaller to keep FPS up
                    room = Math.max(room, Math.min(w, h > w || p.exists(at + ".mcmeta") ? MAX_MOVING : MAX_SLOT));
                }
                if (room == 0) continue;
                String rel = "assets/minecraft/textures/" + f + ".png";
                Path dst = out.resolve(rel);
                BufferedImage cur = image(Files.isRegularFile(dst) ? Files.readAllBytes(dst) : vanilla.read(rel));
                if (cur == null || cur.getHeight() % cur.getWidth() != 0 || cur.getWidth() >= room) continue;
                int high = cur.getHeight() * room / cur.getWidth();         // all frames of a moving picture
                BufferedImage big = new BufferedImage(room, high, BufferedImage.TYPE_INT_ARGB);
                for (int y = 0; y < high; y++) for (int x = 0; x < room; x++)
                    big.setRGB(x, y, cur.getRGB(x * cur.getWidth() / room, y * cur.getHeight() / high));
                byte[] meta = Files.isRegularFile(dst) ? null : vanilla.read(rel + ".mcmeta");
                if (meta != null) {
                    Files.createDirectories(dst.getParent());
                    Files.write(out.resolve(rel + ".mcmeta"), meta);
                }
                Files.createDirectories(dst.getParent());
                Files.write(dst, png(big));
            } catch (Exception ignored) {
                // a broken file in one pack only costs that look its extra room
            }
        }
    }

    private static void write(Path out, List<PackSource> packs, Config cfg, Path drawings, Vanilla vanilla, java.util.function.Predicate<String> which) throws IOException {
        for (Map.Entry<String, Config.Choice> e : cfg.choices.entrySet()) {
            if (!which.test(e.getKey())) continue;
            Config.Choice c = e.getValue();
            for (String f : Looks.files(e.getKey())) {
                Path dst = out.resolve("assets/minecraft/textures/" + f + ".png");
                Path meta = out.resolve("assets/minecraft/textures/" + f + ".png.mcmeta");
                Files.createDirectories(dst.getParent());
                switch (c.kind) {
                    case "pack" -> {
                        for (PackSource p : packs) if (p.slug().equals(c.pack)) {
                            String src = Looks.find(p, f);
                            if (src == null) continue;
                            Files.write(dst, p.read(src));
                            if (p.exists(src + ".mcmeta")) Files.write(meta, p.read(src + ".mcmeta"));
                        }
                    }
                    case "style" -> {
                        BufferedImage im = image(vanilla.read("assets/minecraft/textures/" + f + ".png"));
                        if (im == null) continue;
                        Files.write(dst, png(tint(im, c.rgb)));
                        byte[] m = vanilla.read("assets/minecraft/textures/" + f + ".png.mcmeta");
                        if (m != null) Files.write(meta, m);
                    }
                    case "erase" -> {                 // keeps size and animation so it can be switched live
                        BufferedImage im = image(vanilla.read("assets/minecraft/textures/" + f + ".png"));
                        if (im == null) continue;
                        Files.write(dst, png(new BufferedImage(im.getWidth(), im.getHeight(), BufferedImage.TYPE_INT_ARGB)));
                        byte[] m = vanilla.read("assets/minecraft/textures/" + f + ".png.mcmeta");
                        if (m != null) Files.write(meta, m);
                    }
                    case "shape" -> {
                        if (f.equals("gui/sprites/hud/crosshair")) Files.write(dst, png(crosshair(c.drawn, c.rgb)));
                    }
                    case "drawn" -> {
                        Path dir = drawing(drawings, e.getKey(), c.drawn);
                        Path p = dir.resolve(safe(f) + ".png"), pm = dir.resolve(safe(f) + ".png.mcmeta");
                        if (!Files.isRegularFile(p)) continue;
                        Files.copy(p, dst, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        if (Files.isRegularFile(pm)) Files.copy(pm, meta, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    }
                    default -> { }
                }
            }
        }
    }
}
