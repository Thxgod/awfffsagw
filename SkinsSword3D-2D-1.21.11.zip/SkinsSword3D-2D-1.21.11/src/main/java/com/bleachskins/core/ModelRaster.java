package com.bleachskins.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tiny software renderer for item models: turns a skin into a picture you can spin 360 degrees.
 * It reads the models/textures of the generated pack (so it shows exactly what the game would load), has no
 * Minecraft dependency and returns plain ARGB ints that the GUI uploads into a texture.
 */
public final class ModelRaster {
    private ModelRaster() {}

    /** Tweaks applied on top of the skin, same meaning as in {@link Loadout}. */
    public static final class Params {
        public float length = 1f, width = 1f, depth = 2f;
        public int color = -1;
        public static Params of(Loadout l) {
            Params p = new Params();
            p.length = l.length; p.width = l.width; p.depth = l.depth; p.color = l.color;
            return p;
        }
    }

    private static final class Quad {
        float[][] v = new float[4][3];
        float[][] uv = new float[4][2];
        BufferedImage tex;
        boolean tint;
        float[] n = new float[3];
    }

    /** A loaded, ready-to-spin model. */
    public static final class Scene {
        private final List<Quad> quads = new ArrayList<>();
        private float cx, cy, cz, radius = 1;
        private float pvx, pvy, pvz;   // roll pivot (about the grip), model space
        private int tintRgb = -1;
        public boolean isEmpty() { return quads.isEmpty(); }
    }

    // ------------------------------------------------------------------ loading

    /** Model ids shown for an item-definition tree (fallbacks / first entries; composites show all layers). */
    public static List<String> modelsOf(JsonObject tree) {
        List<String> out = new ArrayList<>();
        walk(tree, out);
        return out;
    }

    private static void walk(JsonElement e, List<String> out) {
        if (e == null || !e.isJsonObject()) return;
        JsonObject o = e.getAsJsonObject();
        String type = Util.str(o, "type");
        if (type == null) return;
        type = type.replace("minecraft:", "");
        switch (type) {
            case "model": { String m = Util.str(o, "model"); if (m != null) out.add(m); break; }
            case "composite": if (o.has("models")) for (JsonElement m : o.getAsJsonArray("models")) walk(m, out); break;
            case "condition": walk(o.get("on_false"), out); break;
            case "select": case "range_dispatch": {
                if ("select".equals(type) && "minecraft:display_context".equals(Util.str(o, "property")) && o.has("cases")) {
                    JsonElement pick = null;           // the look used in the GUI
                    for (JsonElement c : o.getAsJsonArray("cases")) {
                        JsonElement w = c.getAsJsonObject().get("when");
                        boolean gui = w != null && (w.isJsonPrimitive() ? "gui".equals(w.getAsString())
                            : w.isJsonArray() && w.getAsJsonArray().toString().contains("\"gui\""));
                        if (gui) { pick = c.getAsJsonObject().get("model"); break; }
                    }
                    if (pick != null) { walk(pick, out); break; }
                }
                if (o.has("fallback") && !isVanilla(o.get("fallback"))) { walk(o.get("fallback"), out); break; }
                JsonArray a = o.has("cases") ? o.getAsJsonArray("cases") : o.has("entries") ? o.getAsJsonArray("entries") : null;
                if (a != null && a.size() > 0) walk(a.get(0).getAsJsonObject().get("model"), out);
                break;
            }
            default: break;
        }
    }

    private static boolean isVanilla(JsonElement e) {
        List<String> l = new ArrayList<>();
        walk(e, l);
        for (String m : l) if (!m.startsWith("minecraft:")) return false;
        return true;
    }

    /** 3 if the skin uses real box models, 2 if it is a flat sprite */
    public static int kindOf(Path root, JsonObject tree) {
        boolean any = false;
        for (String id : modelsOf(tree)) {
            JsonObject m = flatten(root, id);
            if (m == null) continue;
            any = true;
            if (m.has("elements")) return 3;
        }
        return any ? 2 : 3;
    }

    public static Scene load(Path root, JsonObject tree, Params p) {
        Scene s = new Scene();
        s.tintRgb = p.color;
        Map<String, BufferedImage> cache = new HashMap<>();
        for (String id : modelsOf(tree)) {
            try { addModel(s, root, id, p, cache); } catch (Exception ignored) {}
        }
        finish(s);
        return s;
    }

    public static Scene loadModel(Path root, String modelId, Params p) {
        Scene s = new Scene();
        s.tintRgb = p.color;
        try { addModel(s, root, modelId, p, new HashMap<>()); } catch (Exception ignored) {}
        finish(s);
        return s;
    }

    private static void addModel(Scene s, Path root, String id, Params p, Map<String, BufferedImage> cache) throws IOException {
        JsonObject m = flatten(root, id);
        if (m == null) return;
        JsonObject tex = m.has("textures") ? m.getAsJsonObject("textures") : new JsonObject();
        JsonArray elements = m.has("elements") ? m.getAsJsonArray("elements") : null;
        boolean sprite = false;
        if (elements == null) {                     // flat 2D sprite -> boxes (the same ones the game gets)
            List<BufferedImage> layers = new ArrayList<>();
            for (int i = 0; tex.has("layer" + i); i++) {
                BufferedImage im = image(root, resolve(tex, "#layer" + i), cache);
                if (im == null) return;
                layers.add(im);
            }
            if (layers.isEmpty()) return;
            elements = Voxel.extrude(layers, p.depth > 0 ? p.depth : 1f);
            if (elements == null) return;
            sprite = true;
        }
        // display.gui orientation (vanilla: scale, then Rx*Ry*Rz rotation about the centre, then translation)
        float[] rot = {0, 0, 0}, tr = {0, 0, 0}, sc = {1, 1, 1};
        JsonObject disp = m.has("display") && m.getAsJsonObject("display").has("gui") ? m.getAsJsonObject("display").getAsJsonObject("gui") : null;
        if (disp != null) {
            read3(disp, "rotation", rot); read3(disp, "translation", tr); read3(disp, "scale", sc);
        }
        for (JsonElement el : elements) {
            JsonObject e = el.getAsJsonObject();
            float[] from = new float[3], to = new float[3];
            read3(e, "from", from); read3(e, "to", to);
            JsonObject faces = e.getAsJsonObject("faces");
            if (faces == null) continue;
            for (Map.Entry<String, JsonElement> fe : faces.entrySet()) {
                JsonObject f = fe.getValue().getAsJsonObject();
                String t = Util.str(f, "texture");
                if (t == null) continue;
                BufferedImage im = image(root, resolve(tex, t), cache);
                if (im == null) continue;
                im = Voxel.firstFrame(im);
                Quad q = new Quad();
                q.tex = im;
                q.tint = p.color >= 0 || (f.has("tintindex") && f.get("tintindex").getAsInt() >= 0);
                float[] uv = uvOf(f, fe.getKey(), from, to);
                int rotF = f.has("rotation") ? f.get("rotation").getAsInt() / 90 : 0;
                float[][] corners = faceVerts(fe.getKey(), from, to);
                if (corners == null) continue;
                float[][] cuv = {{uv[0], uv[1]}, {uv[0], uv[3]}, {uv[2], uv[3]}, {uv[2], uv[1]}};
                for (int i = 0; i < 4; i++) {
                    q.v[i] = corners[i].clone();
                    q.uv[i] = cuv[(((i + rotF) % 4) + 4) % 4];
                }
                // element rotation
                if (e.has("rotation") && e.get("rotation").isJsonObject()) {
                    JsonObject r = e.getAsJsonObject("rotation");
                    float[] o = {8, 8, 8};
                    read3(r, "origin", o);
                    String axis = Util.str(r, "axis");
                    float ang = (float) Math.toRadians(r.has("angle") ? r.get("angle").getAsFloat() : 0);
                    if (axis != null) for (int i = 0; i < 4; i++) rotAxis(q.v[i], o, axis, ang);
                    else for (String ax : new String[] {"z", "y", "x"}) if (r.has(ax)) {          // newer format: {x, y, z}
                        float a2 = (float) Math.toRadians(r.get(ax).getAsFloat());
                        for (int i = 0; i < 4; i++) rotAxis(q.v[i], o, ax, a2);
                    }
                }
                // sprite models scale x/y by length; real models: y = blade axis
                float sx, sy, sz;
                if (sprite) { sx = p.length; sy = p.length; sz = p.width; } else { sx = p.width; sy = p.length; sz = p.width; }
                for (int i = 0; i < 4; i++) {
                    float[] v = q.v[i];
                    v[0] = (v[0] - 8) * sx; v[1] = (v[1] - 8) * sy; v[2] = (v[2] - 8) * sz;
                    v[0] *= sc[0]; v[1] *= sc[1]; v[2] *= sc[2];
                    rotXYZ(v, rot);
                    v[0] += tr[0]; v[1] += tr[1]; v[2] += tr[2];
                }
                s.quads.add(q);
            }
        }
    }

    private static void finish(Scene s) {
        if (s.quads.isEmpty()) return;
        float[] mn = {1e9f, 1e9f, 1e9f}, mx = {-1e9f, -1e9f, -1e9f};
        for (Quad q : s.quads) for (float[] v : q.v) for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], v[k]); mx[k] = Math.max(mx[k], v[k]); }
        s.cx = (mn[0] + mx[0]) / 2; s.cy = (mn[1] + mx[1]) / 2; s.cz = (mn[2] + mx[2]) / 2;
        float r = 0;
        for (Quad q : s.quads) for (float[] v : q.v)
            r = Math.max(r, (float) Math.sqrt(sq(v[0] - s.cx) + sq(v[1] - s.cy) + sq(v[2] - s.cz)));
        s.radius = Math.max(1, r);
        s.pvx = mn[0] + 0.25f * (mx[0] - mn[0]); s.pvy = mn[1] + 0.2f * (mx[1] - mn[1]); s.pvz = s.cz;
    }

    private static float sq(float a) { return a * a; }

    private static void read3(JsonObject o, String k, float[] into) {
        if (o.has(k) && o.get(k).isJsonArray() && o.getAsJsonArray(k).size() >= 3)
            for (int i = 0; i < 3; i++) into[i] = o.getAsJsonArray(k).get(i).getAsFloat();
    }

    private static void rotAxis(float[] v, float[] o, String axis, float a) {
        float x = v[0] - o[0], y = v[1] - o[1], z = v[2] - o[2];
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        if ("x".equals(axis)) { float ny = y * c - z * s, nz = y * s + z * c; y = ny; z = nz; }
        else if ("y".equals(axis)) { float nx = x * c + z * s, nz = -x * s + z * c; x = nx; z = nz; }
        else { float nx = x * c - y * s, ny = x * s + y * c; x = nx; y = ny; }
        v[0] = x + o[0]; v[1] = y + o[1]; v[2] = z + o[2];
    }

    /** vanilla order: Rx * Ry * Rz applied to the vector, i.e. Z first */
    private static void rotXYZ(float[] v, float[] deg) {
        float[] z = {0, 0, 0};
        rotAxis(v, z, "z", (float) Math.toRadians(deg[2]));
        rotAxis(v, z, "y", (float) Math.toRadians(deg[1]));
        rotAxis(v, z, "x", (float) Math.toRadians(deg[0]));
    }

    private static float[][] faceVerts(String face, float[] f, float[] t) {
        float x1 = f[0], y1 = f[1], z1 = f[2], x2 = t[0], y2 = t[1], z2 = t[2];
        return switch (face) {
            case "down" -> new float[][] {{x1, y1, z2}, {x1, y1, z1}, {x2, y1, z1}, {x2, y1, z2}};
            case "up" -> new float[][] {{x1, y2, z1}, {x1, y2, z2}, {x2, y2, z2}, {x2, y2, z1}};
            case "north" -> new float[][] {{x2, y2, z1}, {x2, y1, z1}, {x1, y1, z1}, {x1, y2, z1}};
            case "south" -> new float[][] {{x1, y2, z2}, {x1, y1, z2}, {x2, y1, z2}, {x2, y2, z2}};
            case "west" -> new float[][] {{x1, y2, z1}, {x1, y1, z1}, {x1, y1, z2}, {x1, y2, z2}};
            case "east" -> new float[][] {{x2, y2, z2}, {x2, y1, z2}, {x2, y1, z1}, {x2, y2, z1}};
            default -> null;
        };
    }

    /** explicit uv, or vanilla's default projection of the element box */
    private static float[] uvOf(JsonObject face, String dir, float[] f, float[] t) {
        if (face.has("uv") && face.getAsJsonArray("uv").size() == 4) {
            JsonArray a = face.getAsJsonArray("uv");
            return new float[] {a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.get(2).getAsFloat(), a.get(3).getAsFloat()};
        }
        return switch (dir) {
            case "down" -> new float[] {f[0], 16 - t[2], t[0], 16 - f[2]};
            case "up" -> new float[] {f[0], f[2], t[0], t[2]};
            case "north" -> new float[] {16 - t[0], 16 - t[1], 16 - f[0], 16 - f[1]};
            case "south" -> new float[] {f[0], 16 - t[1], t[0], 16 - f[1]};
            case "west" -> new float[] {f[2], 16 - t[1], t[2], 16 - f[1]};
            default -> new float[] {16 - t[2], 16 - t[1], 16 - f[2], 16 - f[1]};
        };
    }

    private static String resolve(JsonObject tex, String ref) {
        for (int i = 0; i < 8 && ref != null && ref.startsWith("#"); i++) ref = Util.str(tex, ref.substring(1));
        return ref;
    }

    private static BufferedImage image(Path root, String ref, Map<String, BufferedImage> cache) {
        if (ref == null || ref.startsWith("#")) return null;
        return cache.computeIfAbsent(ref, r -> {
            int c = r.indexOf(':');
            String ns = c < 0 ? "minecraft" : r.substring(0, c), path = c < 0 ? r : r.substring(c + 1);
            Path f = root.resolve("assets/" + ns + "/textures/" + path + ".png");
            try {
                return Files.isRegularFile(f) ? javax.imageio.ImageIO.read(f.toFile()) : null;
            } catch (IOException e) { return null; }
        });
    }

    private static JsonObject readModel(Path root, String id) {
        int c = id.indexOf(':');
        String ns = c < 0 ? "minecraft" : id.substring(0, c), path = c < 0 ? id : id.substring(c + 1);
        Path f = root.resolve("assets/" + ns + "/models/" + path + ".json");
        try {
            if (Files.isRegularFile(f)) return JsonParser.parseString(Files.readString(f)).getAsJsonObject();
        } catch (Exception ignored) {}
        return null;
    }

    /** parent chain merged into one model; unknown (vanilla) parents are dropped */
    private static JsonObject flatten(Path root, String id) {
        JsonObject first = readModel(root, id);
        if (first == null) return null;
        List<JsonObject> chain = new ArrayList<>();
        chain.add(first);
        JsonObject cur = first;
        for (int i = 0; i < 16; i++) {
            String p = Util.str(cur, "parent");
            if (p == null) break;
            JsonObject po = readModel(root, p);
            if (po == null) break;
            chain.add(po);
            cur = po;
        }
        JsonObject res = new JsonObject(), tex = new JsonObject(), disp = new JsonObject();
        for (int i = chain.size() - 1; i >= 0; i--) {
            for (Map.Entry<String, JsonElement> en : chain.get(i).entrySet()) {
                switch (en.getKey()) {
                    case "parent": break;
                    case "textures": for (Map.Entry<String, JsonElement> t : en.getValue().getAsJsonObject().entrySet()) tex.add(t.getKey(), t.getValue()); break;
                    case "display": for (Map.Entry<String, JsonElement> d : en.getValue().getAsJsonObject().entrySet()) disp.add(d.getKey(), d.getValue()); break;
                    default: res.add(en.getKey(), en.getValue());
                }
            }
        }
        res.add("textures", tex);
        res.add("display", disp);
        return res;
    }

    // ------------------------------------------------------------------ rendering

    /**
     * @param yaw   degrees around the vertical axis (spin)
     * @param pitch degrees, tilt towards the camera
     * @return size*size ARGB pixels (transparent background)
     */
    public static int[] render(Scene s, float yaw, float pitch, int size) { return render(s, yaw, pitch, 0f, size); }

    /** @param roll degrees clockwise in the picture plane, around the grip: used for the swing animation */
    public static int[] render(Scene s, float yaw, float pitch, float roll, int size) {
        int ss = 2, W = size * ss;
        int[] col = new int[W * W];
        float[] zb = new float[W * W];
        java.util.Arrays.fill(zb, -1e9f);
        if (!s.quads.isEmpty()) {
            float scale = W * (roll != 0 ? 0.36f : 0.46f) / s.radius;
            float cr = (float) Math.cos(Math.toRadians(roll)), sr = (float) Math.sin(Math.toRadians(roll));
            float cy = (float) Math.cos(Math.toRadians(yaw)), sy = (float) Math.sin(Math.toRadians(yaw));
            float cp = (float) Math.cos(Math.toRadians(pitch)), sp = (float) Math.sin(Math.toRadians(pitch));
            float[] light = norm(-0.35f, 0.65f, 0.7f);
            for (Quad q : s.quads) {
                float[][] p = new float[4][3];
                for (int i = 0; i < 4; i++) {
                    float x = q.v[i][0] - s.cx, y = q.v[i][1] - s.cy, z = q.v[i][2] - s.cz;
                    float nx = x * cy + z * sy, nz = -x * sy + z * cy; x = nx; z = nz;       // yaw (Y axis)
                    float ny = y * cp - z * sp; nz = y * sp + z * cp; y = ny; z = nz;       // pitch (X axis)
                    if (roll != 0) {                                                          // roll around the grip
                        float ax = s.pvx - s.cx, ay = s.pvy - s.cy, az = s.pvz - s.cz;
                        float pnx = ax * cy + az * sy, pnz = -ax * sy + az * cy; ax = pnx; az = pnz;
                        float pny = ay * cp - az * sp; ay = pny;
                        float dx = x - ax, dy = y - ay;
                        x = ax + dx * cr + dy * sr; y = ay - dx * sr + dy * cr;
                    }
                    p[i][0] = W / 2f + x * scale; p[i][1] = W / 2f - y * scale; p[i][2] = z;
                }
                // normal from the rotated quad (in y-up space) for shading
                float ax = p[1][0] - p[0][0], ay = -(p[1][1] - p[0][1]), az = p[1][2] - p[0][2];
                float bx = p[2][0] - p[1][0], by = -(p[2][1] - p[1][1]), bz = p[2][2] - p[1][2];
                float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1e-6f) continue;
                nx /= len; ny /= len; nz /= len;
                if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
                float shade = 0.55f + 0.45f * Math.max(0, nx * light[0] + ny * light[1] + nz * light[2]);
                tri(col, zb, W, q, p, 0, 1, 2, shade, s.tintRgb);
                tri(col, zb, W, q, p, 0, 2, 3, shade, s.tintRgb);
            }
        }
        int[] out = new int[size * size];     // 2x2 box filter
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
            int a = 0, r = 0, g = 0, b = 0;
            for (int j = 0; j < ss; j++) for (int i = 0; i < ss; i++) {
                int c = col[(y * ss + j) * W + x * ss + i];
                int ca = c >>> 24;
                a += ca; r += ((c >> 16) & 255) * ca; g += ((c >> 8) & 255) * ca; b += (c & 255) * ca;
            }
            if (a == 0) continue;
            out[y * size + x] = ((a / (ss * ss)) << 24) | ((r / a) << 16) | ((g / a) << 8) | (b / a);
        }
        return out;
    }

    private static float[] norm(float x, float y, float z) {
        float l = (float) Math.sqrt(x * x + y * y + z * z);
        return new float[] {x / l, y / l, z / l};
    }

    private static void tri(int[] col, float[] zb, int W, Quad q, float[][] p, int i0, int i1, int i2, float shade, int tintRgb) {
        float x0 = p[i0][0], y0 = p[i0][1], x1 = p[i1][0], y1 = p[i1][1], x2 = p[i2][0], y2 = p[i2][1];
        float den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2);
        if (Math.abs(den) < 1e-9f) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(x0, Math.min(x1, x2)))), maxX = Math.min(W - 1, (int) Math.ceil(Math.max(x0, Math.max(x1, x2))));
        int minY = Math.max(0, (int) Math.floor(Math.min(y0, Math.min(y1, y2)))), maxY = Math.min(W - 1, (int) Math.ceil(Math.max(y0, Math.max(y1, y2))));
        int tw = q.tex.getWidth(), th = q.tex.getHeight();
        for (int y = minY; y <= maxY; y++) for (int x = minX; x <= maxX; x++) {
            float px = x + 0.5f, py = y + 0.5f;
            float l0 = ((y1 - y2) * (px - x2) + (x2 - x1) * (py - y2)) / den;
            float l1 = ((y2 - y0) * (px - x2) + (x0 - x2) * (py - y2)) / den;
            float l2 = 1 - l0 - l1;
            if (l0 < -0.001f || l1 < -0.001f || l2 < -0.001f) continue;
            float z = l0 * p[i0][2] + l1 * p[i1][2] + l2 * p[i2][2];
            if (z <= zb[y * W + x]) continue;
            float u = l0 * q.uv[i0][0] + l1 * q.uv[i1][0] + l2 * q.uv[i2][0];
            float v = l0 * q.uv[i0][1] + l1 * q.uv[i1][1] + l2 * q.uv[i2][1];
            int tx = Math.max(0, Math.min(tw - 1, (int) (u / 16f * tw)));
            int ty = Math.max(0, Math.min(th - 1, (int) (v / 16f * th)));
            int c = q.tex.getRGB(tx, ty);
            if ((c >>> 24) < 16) continue;
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if (q.tint && tintRgb >= 0) {
                r = r * ((tintRgb >> 16) & 255) / 255; g = g * ((tintRgb >> 8) & 255) / 255; b = b * (tintRgb & 255) / 255;
            }
            r = Math.min(255, (int) (r * shade)); g = Math.min(255, (int) (g * shade)); b = Math.min(255, (int) (b * shade));
            zb[y * W + x] = z;
            col[y * W + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
        }
    }
}
