package com.bleachskins.core;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Weapon skins in older pack formats, turned into the same Skin objects as modern ones:
 * custom_model_data overrides (1.14 - 1.21.3), plain replaced tool models/textures (any version), OptiFine/MCPatcher CIT.
 */
final class LegacyScanner {
    private LegacyScanner() {}

    /** tool names used before Minecraft 1.13 */
    static String modern(String id) {
        return id.replace("wood_", "wooden_").replace("gold_", "golden_").replace("_spade", "_shovel");
    }

    static void scan(PackSource p, Map<String, Skin> out) {
        Set<String> done = new HashSet<>();
        for (String f : p.list("assets/minecraft/models/item/")) {
            if (!f.endsWith(".json")) continue;
            String id = f.substring("assets/minecraft/models/item/".length(), f.length() - 5);
            if (id.contains("/")) continue;
            try { models(p, f, id, out, done); } catch (Exception ignored) {}
        }
        for (String dir : new String[] {"item", "items"})
            for (String f : p.list("assets/minecraft/textures/" + dir + "/")) {
                if (!f.endsWith(".png")) continue;
                String file = f.substring(f.lastIndexOf('/') + 1, f.length() - 4), id = modern(file);
                String cat = Categories.of(id);
                // only real vanilla tools: anything else is a texture sheet used by one of the pack's models
                if (!Categories.isTool(cat) || !Categories.items(cat).contains(id) || !done.add(id)) continue;
                String to = "item/plain_" + Retexture.safe(id).replace('+', '_');
                Skin s = sprite(p, Scanner.pretty(id), cat, "plain_" + id, to);
                s.copies.put(f, "assets/bs_" + p.slug() + "/textures/" + to + ".png");
                if (p.exists(f + ".mcmeta")) s.copies.put(f + ".mcmeta", "assets/bs_" + p.slug() + "/textures/" + to + ".png.mcmeta");
                out.putIfAbsent(s.key(), s);
            }
        Map<String, String> files = new HashMap<>();                  // lower case path -> real path (packs often get the case wrong)
        for (String f : p.list("assets/")) files.put(f.toLowerCase(Locale.ROOT), f);
        List<String> props = new ArrayList<>();
        for (String f : files.values())
            if (f.endsWith(".properties") && (f.contains("/optifine/cit/") || f.contains("/mcpatcher/cit/"))) props.add(f);
        java.util.Collections.sort(props);
        // main-hand versions first: an off-hand file of the same name is only that weapon's second look
        props.sort(java.util.Comparator.comparing(f -> isOffHand(p, f)));
        Set<String> names = new HashSet<>();
        for (String f : props) try { cit(p, f, files, names, out); } catch (Exception ignored) {}
    }

    private static void models(PackSource p, String f, String rawId, Map<String, Skin> out, Set<String> done) throws Exception {
        JsonObject o = JsonParser.parseString(new String(p.read(f), StandardCharsets.UTF_8)).getAsJsonObject();
        String id = modern(rawId), cat = Categories.of(id);
        boolean any = false;
        if (o.has("overrides") && o.get("overrides").isJsonArray())
            for (JsonElement e : o.getAsJsonArray("overrides")) {
                JsonObject ov = e.getAsJsonObject();
                if (!ov.has("predicate") || !ov.getAsJsonObject("predicate").has("custom_model_data") || !ov.has("model")) continue;
                String model = ov.get("model").getAsString();
                out.putIfAbsent(skinOf(p, cat, Scanner.pretty(model.substring(model.indexOf(':') + 1)), model).key(),
                    skinOf(p, cat, Scanner.pretty(model.substring(model.indexOf(':') + 1)), model));
                any = true;
            }
        if (!any && Categories.isTool(cat) && Categories.items(cat).contains(id) && done.add(id)) {
            Skin s = skinOf(p, cat, Scanner.pretty(id), "item/" + rawId);
            out.putIfAbsent(s.key(), s);
        }
    }

    private static Skin skinOf(PackSource p, String cat, String name, String model) {
        JsonObject tree = new JsonObject();
        tree.addProperty("type", "minecraft:model");
        tree.addProperty("model", model.contains(":") ? model : "minecraft:" + model);
        Scanner.rewrite(tree, p);
        String m = tree.get("model").getAsString(), ns = m.substring(0, m.indexOf(':'));
        return new Skin(p.slug(), p.name(), cat, name, null, ns.equals("minecraft") || ns.startsWith("bs_") ? null : ns, tree);
    }

    /** a flat handheld item made from one sprite */
    private static Skin sprite(PackSource p, String name, String cat, String modelName, String texturePath) {
        String path = "item/gen_" + Util.hash(modelName);
        JsonObject tree = new JsonObject();
        tree.addProperty("type", "minecraft:model");
        tree.addProperty("model", "bs_" + p.slug() + ":" + path);
        JsonObject model = new JsonObject(), tex = new JsonObject();
        model.addProperty("parent", "minecraft:item/handheld");
        tex.addProperty("layer0", "bs_" + p.slug() + ":" + texturePath);
        model.add("textures", tex);
        Skin s = new Skin(p.slug(), p.name(), cat, name, null, null, tree);
        s.models.put("assets/bs_" + p.slug() + "/models/" + path + ".json", model);
        return s;
    }

    private static boolean isOffHand(PackSource p, String f) {
        try {
            Properties pr = new Properties();
            pr.load(new ByteArrayInputStream(p.read(f)));
            return "off".equalsIgnoreCase(pr.getProperty("hand", "").trim());
        } catch (Exception e) { return false; }
    }

    /** OptiFine path rules: next to the .properties file, "~/" = the optifine folder, or from assets/minecraft/. */
    private static String resolve(Map<String, String> files, String dir, String ref, String ext) {
        ref = ref.trim().replace('\\', '/');
        if (ref.startsWith("./")) ref = ref.substring(2);
        int c = ref.indexOf(':');
        if (c >= 0) ref = ref.substring(c + 1);
        if (ref.endsWith(ext)) ref = ref.substring(0, ref.length() - ext.length());
        String optifine = dir.substring(0, dir.indexOf("/cit/") + 1);
        String[] tries = ref.startsWith("~/") ? new String[] {optifine + ref.substring(2)}
            : new String[] {dir + ref, "assets/minecraft/" + ref, optifine + ref, optifine + "cit/" + ref,
                "assets/minecraft/textures/" + ref, "assets/minecraft/models/" + ref};
        for (String t : tries) {
            String real = files.get((t + ext).toLowerCase(Locale.ROOT));
            if (real != null) return real;
        }
        return null;
    }

    private static void cit(PackSource p, String f, Map<String, String> files, Set<String> names, Map<String, Skin> out) throws Exception {
        Properties pr = new Properties();
        pr.load(new ByteArrayInputStream(p.read(f)));
        if (!"item".equals(pr.getProperty("type", "item").trim())) return;
        String items = pr.getProperty("items", pr.getProperty("matchItems", "")).trim();
        if (items.isEmpty()) return;
        String first = items.split("\\s+")[0];
        first = modern(first.substring(first.indexOf(':') + 1));
        String cat = Categories.of(first);
        String dir = f.substring(0, f.lastIndexOf('/') + 1), base = f.substring(dir.length(), f.length() - ".properties".length());
        String name = pr.getProperty("nbt.display.Name", base).replaceAll("^i?(pattern|regex):", "").replaceAll("[&§][0-9a-fk-or]", "").replaceAll("[*()|^$\\\\]", "").trim();
        if (name.isEmpty()) name = base;
        boolean off = "off".equalsIgnoreCase(pr.getProperty("hand", "").trim());
        boolean taken = !names.add(cat + "/" + name.toLowerCase(Locale.ROOT));
        if (taken && off) return;                                     // the same weapon's other hand
        if (taken) name = Scanner.pretty(base);                       // same item name, different look (e.g. colours)
        String key = "cit_" + Util.hash(f);

        String modelRef = pr.getProperty("model");
        if (modelRef == null) modelRef = pr.getProperty("model.bow_standby");
        String modelFile = modelRef == null ? null : resolve(files, dir, modelRef, ".json");
        Skin s;
        if (modelFile != null) {
            s = new Skin(p.slug(), p.name(), cat, name, null, null, new JsonObject());
            s.tree.addProperty("type", "minecraft:model");
            s.tree.addProperty("model", citModel(p, modelFile, files, s, 0));
        } else {
            String src = resolve(files, dir, pr.getProperty("texture", base), ".png");
            if (src == null) return;
            String to = "item/cit_" + Util.hash(src);
            s = sprite(p, name, cat, key, to);
            copyTexture(p, src, to, s);
        }
        out.putIfAbsent(s.key(), s);
    }

    private static void copyTexture(PackSource p, String src, String to, Skin s) {
        String dst = "assets/bs_" + p.slug() + "/textures/" + to + ".png";
        s.copies.put(src, dst);
        if (p.exists(src + ".mcmeta")) s.copies.put(src + ".mcmeta", dst + ".mcmeta");
    }

    /** Copies a CIT model (and its parents and textures) into the generated pack; returns its model id. */
    private static String citModel(PackSource p, String file, Map<String, String> files, Skin s, int depth) throws Exception {
        String path = "item/citm_" + Util.hash(file), id = "bs_" + p.slug() + ":" + path;
        String dst = "assets/bs_" + p.slug() + "/models/" + path + ".json";
        if (s.models.containsKey(dst) || depth > 8) return id;
        JsonObject m = JsonParser.parseString(new String(p.read(file), StandardCharsets.UTF_8)).getAsJsonObject();
        String dir = file.substring(0, file.lastIndexOf('/') + 1);
        if (m.has("parent")) {
            String parent = m.get("parent").getAsString();
            String own = parent.startsWith("builtin/") || parent.startsWith("minecraft:builtin/") ? null : resolve(files, dir, parent, ".json");
            if (own != null) m.addProperty("parent", citModel(p, own, files, s, depth + 1));
            else if (parent.endsWith("builtin/generated")) m.addProperty("parent", "minecraft:item/generated");
            else if (parent.endsWith("builtin/entity")) m.remove("parent");
            else m.addProperty("parent", Scanner.vanillaPath(parent));
        }
        if (m.has("textures")) for (Map.Entry<String, JsonElement> t : m.getAsJsonObject("textures").entrySet()) {
            if (!t.getValue().isJsonPrimitive()) continue;
            String ref = t.getValue().getAsString();
            if (ref.startsWith("#")) continue;
            String src = resolve(files, dir, ref, ".png");
            if (src == null) { t.setValue(new com.google.gson.JsonPrimitive(Scanner.vanillaPath(ref))); continue; }
            String to = "item/cit_" + Util.hash(src);
            copyTexture(p, src, to, s);
            t.setValue(new com.google.gson.JsonPrimitive("bs_" + p.slug() + ":" + to));
        }
        Scanner.dropBrokenFaces(m);
        s.models.put(dst, m);
        return id;
    }
}
