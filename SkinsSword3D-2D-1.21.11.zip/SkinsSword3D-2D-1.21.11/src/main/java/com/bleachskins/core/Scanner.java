package com.bleachskins.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds skins in a resource pack written for the 1.21.4+ item-definition format (older formats: LegacyScanner).
 * Recognised:
 *  1. vanilla item definitions that pick a model by custom NAME            (the Bleach pack)
 *  2. vanilla item definitions that pick a model by custom_model_data      (string select, or float range_dispatch)
 *  3. stand-alone item definitions in any other namespace (assets/&lt;ns&gt;/items/foo.json)
 */
public final class Scanner {
    private Scanner() {}

    private static final Pattern DEF = Pattern.compile("assets/([a-z0-9_.-]+)/items/([a-z0-9_./-]+)\\.json");
    private static final String CMD = "minecraft:custom_model_data";

    /** What the skin "looks like" to the item definition: a custom name, a cmd string, or a cmd float. */
    private record Variant(char kind, String s, double f) {}

    public static Map<String, Skin> scan(PackSource p) {
        Map<String, Skin> out = new LinkedHashMap<>();
        LegacyScanner.scan(p, out);
        for (String f : p.list("assets/")) {
            Matcher m = DEF.matcher(f);
            if (!m.matches()) continue;
            String ns = m.group(1), id = m.group(2);
            JsonObject def;
            try {
                def = JsonParser.parseString(new String(p.read(f), StandardCharsets.UTF_8)).getAsJsonObject();
            } catch (Exception e) { continue; }
            if (!def.has("model") || !def.get("model").isJsonObject()) continue;
            JsonObject model = def.getAsJsonObject("model");

            if (ns.equals("minecraft")) {
                String cat = Categories.of(id);
                Map<String, Variant> variants = new LinkedHashMap<>();
                Map<String, String> display = new LinkedHashMap<>();
                collect(model, variants, display);
                for (Map.Entry<String, Variant> v : variants.entrySet()) {
                    JsonObject tree = spec(model, v.getValue(), id).getAsJsonObject();
                    rewrite(tree, p);
                    Skin s = new Skin(p.slug(), p.name(), cat, display.get(v.getKey()), id, null, tree);
                    out.putIfAbsent(s.key(), s);
                }
            } else {
                JsonObject tree = model.deepCopy();
                Skin s = new Skin(p.slug(), p.name(), Categories.guess(id), pretty(id), null, ns, tree);
                out.putIfAbsent(s.key(), s);
            }
        }
        return out;
    }

    static String pretty(String id) {
        String base = id.substring(id.lastIndexOf('/') + 1).replace('_', ' ').replace('-', ' ');
        StringBuilder sb = new StringBuilder();
        for (String w : base.split(" ")) if (!w.isEmpty()) sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------ node tests

    private static boolean isNameSelect(JsonObject o) {
        return "minecraft:select".equals(Util.str(o, "type"))
            && "minecraft:component".equals(Util.str(o, "property"))
            && "minecraft:custom_name".equals(Util.str(o, "component"));
    }

    private static boolean isNameCondition(JsonObject o) {
        return "minecraft:condition".equals(Util.str(o, "type"))
            && "minecraft:has_component".equals(Util.str(o, "property"))
            && "minecraft:custom_name".equals(Util.str(o, "component"));
    }

    private static boolean isCmdSelect(JsonObject o) {
        return "minecraft:select".equals(Util.str(o, "type")) && CMD.equals(Util.str(o, "property")) && indexZero(o);
    }

    private static boolean isCmdRange(JsonObject o) {
        return "minecraft:range_dispatch".equals(Util.str(o, "type")) && CMD.equals(Util.str(o, "property")) && indexZero(o);
    }

    private static boolean indexZero(JsonObject o) {
        return !o.has("index") || o.get("index").getAsInt() == 0;
    }

    // ------------------------------------------------------------------ discovering variants

    private static void collect(JsonElement e, Map<String, Variant> variants, Map<String, String> display) {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if ((isNameSelect(o) || isCmdSelect(o)) && o.has("cases")) {
                char kind = isNameSelect(o) ? 'n' : 's';
                for (JsonElement c : o.getAsJsonArray("cases")) {
                    JsonElement when = c.getAsJsonObject().get("when");
                    if (when == null) continue;
                    if (when.isJsonArray()) for (JsonElement w : when.getAsJsonArray()) addString(variants, display, kind, w);
                    else addString(variants, display, kind, when);
                }
            } else if (isCmdRange(o) && o.has("entries")) {
                for (JsonElement en : o.getAsJsonArray("entries")) {
                    JsonObject eo = en.getAsJsonObject();
                    if (!eo.has("threshold")) continue;
                    double t = eo.get("threshold").getAsDouble();
                    String key = "r:" + t;
                    if (variants.containsKey(key)) continue;
                    String mid = firstModel(eo.get("model"));
                    variants.put(key, new Variant('r', null, t));
                    display.put(key, mid != null ? pretty(mid.substring(mid.indexOf(':') + 1)) : "Model " + (t == Math.rint(t) ? String.valueOf((long) t) : String.valueOf(t)));
                }
            }
            for (Map.Entry<String, JsonElement> en : o.entrySet()) collect(en.getValue(), variants, display);
        } else if (e.isJsonArray()) {
            for (JsonElement x : e.getAsJsonArray()) collect(x, variants, display);
        }
    }

    private static String firstModel(JsonElement e) {
        if (e == null) return null;
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if ("minecraft:model".equals(Util.str(o, "type")) && Util.str(o, "model") != null) return Util.str(o, "model");
            for (Map.Entry<String, JsonElement> en : o.entrySet()) { String r = firstModel(en.getValue()); if (r != null) return r; }
        } else if (e.isJsonArray()) {
            for (JsonElement x : e.getAsJsonArray()) { String r = firstModel(x); if (r != null) return r; }
        }
        return null;
    }

    private static void addString(Map<String, Variant> variants, Map<String, String> display, char kind, JsonElement w) {
        if (!w.isJsonPrimitive() || !w.getAsJsonPrimitive().isString()) return;
        String s = w.getAsString();
        String low = s.toLowerCase(Locale.ROOT);
        String key = kind + ":" + low;
        String shown = kind == 's' ? pretty(s) : s;
        String cur = display.get(key);
        variants.putIfAbsent(key, new Variant(kind, low, 0));
        if (cur == null || (cur.equals(low) && !shown.equals(low))) display.put(key, shown);
    }

    // ------------------------------------------------------------------ specialising a tree for one variant

    private static JsonObject vanilla(String baseItem) {
        JsonObject v = new JsonObject();
        v.addProperty("type", "minecraft:model");
        v.addProperty("model", "minecraft:item/" + baseItem);
        return v;
    }

    private static boolean whenHas(JsonObject c, String s) {
        JsonElement when = c.get("when");
        if (when == null) return false;
        if (when.isJsonArray()) {
            for (JsonElement w : when.getAsJsonArray()) if (w.isJsonPrimitive() && w.getAsString().equalsIgnoreCase(s)) return true;
            return false;
        }
        return when.isJsonPrimitive() && when.getAsString().equalsIgnoreCase(s);
    }

    private static JsonElement spec(JsonElement e, Variant v, String base) {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();

            if (isNameSelect(o) || isCmdSelect(o)) {
                char mine = isNameSelect(o) ? 'n' : 's';
                if (v.kind == mine && o.has("cases"))
                    for (JsonElement c : o.getAsJsonArray("cases"))
                        if (whenHas(c.getAsJsonObject(), v.s)) return spec(c.getAsJsonObject().get("model"), v, base);
                return o.has("fallback") ? spec(o.get("fallback"), v, base) : vanilla(base);
            }
            if (isCmdRange(o)) {
                if (v.kind == 'r' && o.has("entries")) {
                    JsonObject best = null; double bt = Double.NEGATIVE_INFINITY;
                    for (JsonElement en : o.getAsJsonArray("entries")) {
                        JsonObject eo = en.getAsJsonObject();
                        double t = eo.get("threshold").getAsDouble();
                        if (t <= v.f && t > bt) { bt = t; best = eo; }
                    }
                    if (best != null) return spec(best.get("model"), v, base);
                }
                return o.has("fallback") ? spec(o.get("fallback"), v, base) : vanilla(base);
            }
            if (isNameCondition(o)) {
                JsonElement pick = v.kind == 'n' ? o.get("on_true") : o.get("on_false");
                return pick == null ? vanilla(base) : spec(pick, v, base);
            }
            JsonObject r = new JsonObject();
            for (Map.Entry<String, JsonElement> en : o.entrySet()) r.add(en.getKey(), spec(en.getValue(), v, base));
            return r;
        }
        if (e.isJsonArray()) {
            JsonArray a = new JsonArray();
            for (JsonElement x : e.getAsJsonArray()) a.add(spec(x, v, base));
            return a;
        }
        return e;
    }

    // ------------------------------------------------------------------ model id rewriting

    /** Point model ids at the pack's own copies (namespace bs_<pack>) when the pack provides them. */
    static void rewrite(JsonElement e, PackSource p) {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if ("minecraft:model".equals(Util.str(o, "type")) && Util.str(o, "model") != null)
                o.addProperty("model", qualify(p, Util.str(o, "model"), "models", ".json"));
            for (Map.Entry<String, JsonElement> en : o.entrySet()) rewrite(en.getValue(), p);
        } else if (e.isJsonArray()) {
            for (JsonElement x : e.getAsJsonArray()) rewrite(x, p);
        }
    }

    /** Faces pointing at a texture the model never defines can't be baked and break the whole model: drop them. */
    static void dropBrokenFaces(JsonObject model) {
        if (model.has("parent") || !model.has("elements") || !model.get("elements").isJsonArray()) return;
        JsonObject tex = model.has("textures") && model.get("textures").isJsonObject() ? model.getAsJsonObject("textures") : new JsonObject();
        for (JsonElement el : model.getAsJsonArray("elements")) {
            if (!el.isJsonObject() || !el.getAsJsonObject().has("faces")) continue;
            JsonObject faces = el.getAsJsonObject().getAsJsonObject("faces");
            for (String side : new java.util.ArrayList<>(faces.keySet())) {
                String t = Util.str(faces.getAsJsonObject(side), "texture");
                if (t != null && t.startsWith("#") && !tex.has(t.substring(1))) faces.remove(side);
            }
        }
    }

    /** A vanilla model/texture name as it is called today ("items/x" -> "item/x", "blocks/x" -> "block/x"). */
    static String vanillaPath(String ref) {
        String path = ref.substring(ref.indexOf(':') + 1);
        if (path.startsWith("items/")) path = "item/" + path.substring(6);
        if (path.startsWith("blocks/")) path = "block/" + path.substring(7);
        return "minecraft:" + path;
    }

    static String qualify(PackSource p, String ref, String kind, String ext) {
        if (ref.startsWith("#")) return ref;
        String ns = "minecraft", path = ref;
        int c = ref.indexOf(':');
        if (c >= 0) { ns = ref.substring(0, c); path = ref.substring(c + 1); }
        if (ns.equals("minecraft") && p.exists("assets/minecraft/" + kind + "/" + path + ext)) return "bs_" + p.slug() + ":" + path;
        return ns.equals("minecraft") ? vanillaPath(path) : ns + ":" + path;
    }
}
