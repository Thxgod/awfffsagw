package com.bleachskins.core;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Builds the single resource pack the game actually loads:
 *  - copies only the models/textures the skins need, renamed into bs_&lt;pack&gt; namespaces so packs can't clash
 *  - bleachskins:pv_*  item definitions, used for GUI previews
 *  - bleachskins:lo_*  item definitions for each saved "my skin"
 *  - minecraft:items/* overrides for every active "my skin" (this is what changes the swords in your hand)
 */
public final class Generator {
    private static final Gson GSON = new Gson();

    private final Path out;
    private final Map<String, PackSource> bySlug = new HashMap<>();
    private final Set<String> done = new HashSet<>();
    private final Map<String, String> derived = new HashMap<>();

    /** Vanilla display transforms for flat item models (approximate copies of item/generated and item/handheld). */
    private static final Map<String, JsonObject> FLAT_DISPLAY = new HashMap<>();
    static {
        String gen = "{\"ground\":{\"translation\":[0,2,0],\"scale\":[0.5,0.5,0.5]},"
            + "\"head\":{\"rotation\":[0,180,0],\"translation\":[0,13,7]},"
            + "\"gui\":{},\"fixed\":{\"rotation\":[0,180,0]},"
            + "\"thirdperson_righthand\":{\"translation\":[0,3,1],\"scale\":[0.55,0.55,0.55]},"
            + "\"thirdperson_lefthand\":{\"translation\":[0,3,1],\"scale\":[0.55,0.55,0.55]},"
            + "\"firstperson_righthand\":{\"rotation\":[0,-90,25],\"translation\":[1.13,3.2,1.13],\"scale\":[0.68,0.68,0.68]},"
            + "\"firstperson_lefthand\":{\"rotation\":[0,90,-25],\"translation\":[1.13,3.2,1.13],\"scale\":[0.68,0.68,0.68]}}";
        JsonObject g = JsonParser.parseString(gen).getAsJsonObject();
        JsonObject h = g.deepCopy();
        h.add("thirdperson_righthand", JsonParser.parseString("{\"rotation\":[0,-90,55],\"translation\":[0,4,0.5],\"scale\":[0.85,0.85,0.85]}"));
        h.add("thirdperson_lefthand", JsonParser.parseString("{\"rotation\":[0,90,-55],\"translation\":[0,4,0.5],\"scale\":[0.85,0.85,0.85]}"));
        FLAT_DISPLAY.put("minecraft:item/generated", g);
        FLAT_DISPLAY.put("minecraft:item/handheld", h);
    }

    private Generator(Path out, List<PackSource> packs) {
        this.out = out;
        for (PackSource p : packs) bySlug.put(p.slug(), p);
    }

    /** @return ids of the "lo_*" item definitions written (one per look), so callers know what is loaded */
    public static java.util.Set<String> generate(Path out, List<PackSource> packs, List<Skin> skins, Config cfg) throws IOException {
        deleteTree(out);
        Files.createDirectories(out);
        Files.writeString(out.resolve("pack.mcmeta"),
            "{\"pack\":{\"description\":\"Skins Sword 3D-2D - generated, do not edit\",\"min_format\":69,\"max_format\":99}}");
        Generator g = new Generator(out, packs);
        Map<String, Skin> byKey = new HashMap<>();
        for (Skin s : skins) byKey.put(s.key(), s);

        // 1) previews of every library skin
        for (Skin s : skins) {
            g.copyAssets(s);
            String item = Categories.previewItem(s.category);
            g.writeItem("bleachskins", s.previewId(), swapBase(s.tree, s.baseItem, item));
        }
        // 2) one definition per LOOK (lo_<sig>): every library skin with default tweaks, plus every saved "my skin".
        //    The game picks a look by giving the held item that item_model at runtime, so equipping needs no reload.
        java.util.Set<String> written = new java.util.LinkedHashSet<>();
        java.util.List<Loadout> looks = new java.util.ArrayList<>();
        for (Skin s : skins) looks.add(Loadout.plain(s.category, s.key()));
        looks.addAll(cfg.loadouts);
        for (Loadout l : looks) {
            String id = "lo_" + l.sig();
            if (!written.add(id)) continue;
            JsonObject t = g.build(l, byKey, Categories.previewItem(l.category));
            if (t != null) g.writeItem("bleachskins", id, t); else written.remove(id);
        }
        for (Skin s : skins) s.kind = ModelRaster.kindOf(out, s.tree);
        return written;
    }

    /** Different looks per hand: left-hand display contexts use `left`, everything else uses `right`. */
    static JsonObject combineHands(JsonObject right, JsonObject left, String item) {
        if (left == null) return right;
        if (right == null) {
            right = new JsonObject();
            right.addProperty("type", "minecraft:model");
            right.addProperty("model", "minecraft:item/" + item);
        }
        JsonObject sel = new JsonObject();
        sel.addProperty("type", "minecraft:select");
        sel.addProperty("property", "minecraft:display_context");
        JsonArray cases = new JsonArray();
        JsonObject c = new JsonObject();
        JsonArray when = new JsonArray();
        when.add("firstperson_lefthand"); when.add("thirdperson_lefthand");
        c.add("when", when);
        c.add("model", left);
        cases.add(c);
        sel.add("cases", cases);
        sel.add("fallback", right);
        return sel;
    }

    // ------------------------------------------------------------------ building item trees

    private JsonObject build(Loadout l, Map<String, Skin> byKey, String item) throws IOException {
        Skin a = byKey.get(l.skin);
        if (a == null) return null;
        JsonObject ta = customize(swapBase(a.tree, a.baseItem, item), l);
        Skin b = l.overlay == null ? null : byKey.get(l.overlay);
        if (b == null) return ta;
        JsonObject tb = customize(swapBase(b.tree, b.baseItem, item), l);
        JsonObject comp = new JsonObject();
        comp.addProperty("type", "minecraft:composite");
        JsonArray arr = new JsonArray();
        arr.add(ta); arr.add(tb);
        comp.add("models", arr);
        return comp;
    }

    /** Replace the skin's reference to its original vanilla model with the target item's own model. */
    static JsonObject swapBase(JsonObject tree, String baseItem, String target) {
        JsonObject c = tree.deepCopy();
        if (baseItem != null) swapWalk(c, "minecraft:item/" + baseItem, "minecraft:item/" + target);
        return c;
    }

    private static void swapWalk(JsonElement e, String from, String to) {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if ("minecraft:model".equals(Util.str(o, "type")) && from.equals(Util.str(o, "model"))) o.addProperty("model", to);
            for (Map.Entry<String, JsonElement> en : o.entrySet()) swapWalk(en.getValue(), from, to);
        } else if (e.isJsonArray()) for (JsonElement x : e.getAsJsonArray()) swapWalk(x, from, to);
    }

    private JsonObject customize(JsonObject tree, Loadout l) throws IOException {
        if (!l.customized()) return tree;
        customizeWalk(tree, l);
        return tree;
    }

    private void customizeWalk(JsonElement e, Loadout l) throws IOException {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if ("minecraft:model".equals(Util.str(o, "type")) && Util.str(o, "model") != null) {
                o.addProperty("model", derive(l, Util.str(o, "model")));
                if (l.color >= 0) {
                    JsonArray tints = new JsonArray();
                    JsonObject t = new JsonObject();
                    t.addProperty("type", "minecraft:constant");
                    t.addProperty("value", l.color & 0xFFFFFF);
                    tints.add(t);
                    o.add("tints", tints);
                }
            }
            for (Map.Entry<String, JsonElement> en : o.entrySet()) customizeWalk(en.getValue(), l);
        } else if (e.isJsonArray()) for (JsonElement x : e.getAsJsonArray()) customizeWalk(x, l);
    }

    /** Writes a tweaked copy of a model (blade length/thickness via display scale, tint via tintindex). */
    private String derive(Loadout l, String id) throws IOException {
        String key = id + "|" + l.length + "|" + l.width + "|" + (l.color >= 0) + "|" + l.depth;
        String hit = derived.get(key);
        if (hit != null) return hit;
        JsonObject flat = flatten(id);
        String result = id;
        if (flat != null && flat.has("elements")) {
            boolean scale = l.length != 1f || l.width != 1f;
            if (scale && flat.has("display")) {
                JsonObject disp = flat.getAsJsonObject("display");
                for (Map.Entry<String, JsonElement> en : disp.entrySet()) {
                    JsonObject ctx = en.getValue().getAsJsonObject();
                    float[] s = {1, 1, 1};
                    if (ctx.has("scale")) for (int i = 0; i < 3; i++) s[i] = ctx.getAsJsonArray("scale").get(i).getAsFloat();
                    JsonArray n = new JsonArray();
                    n.add(Math.min(4f, s[0] * l.width));
                    n.add(Math.min(4f, s[1] * l.length));   // model Y axis = blade axis
                    n.add(Math.min(4f, s[2] * l.width));
                    ctx.add("scale", n);
                }
            }
            if (l.color >= 0) {
                for (JsonElement el : flat.getAsJsonArray("elements")) {
                    JsonObject faces = el.getAsJsonObject().getAsJsonObject("faces");
                    if (faces != null) for (Map.Entry<String, JsonElement> f : faces.entrySet())
                        f.getValue().getAsJsonObject().addProperty("tintindex", 0);
                }
            }
            String name = "gen/" + Util.hash(key);
            writeJson(out.resolve("assets/bleachskins/models/" + name + ".json"), flat);
            result = "bleachskins:" + name;
        } else if (flat != null && FLAT_DISPLAY.containsKey(Util.str(flat, "parent"))
                   && (l.length != 1f || l.width != 1f || l.depth > 0f)) {
            // flat 2D sprite: give it real thickness (voxel boxes) and/or scale it
            JsonArray els = l.depth > 0f ? voxelize(flat, l.depth) : null;
            if (els != null || l.length != 1f || l.width != 1f) {
                JsonObject disp = new JsonObject();
                for (Map.Entry<String, JsonElement> d : FLAT_DISPLAY.get(Util.str(flat, "parent")).entrySet()) disp.add(d.getKey(), d.getValue().deepCopy());
                if (flat.has("display")) for (Map.Entry<String, JsonElement> d : flat.getAsJsonObject("display").entrySet()) disp.add(d.getKey(), d.getValue().deepCopy());
                for (Map.Entry<String, JsonElement> en : disp.entrySet()) {
                    JsonObject ctx = en.getValue().getAsJsonObject();
                    float[] s = {1, 1, 1};
                    if (ctx.has("scale")) for (int i = 0; i < 3; i++) s[i] = ctx.getAsJsonArray("scale").get(i).getAsFloat();
                    JsonArray n = new JsonArray();
                    n.add(Math.min(4f, s[0] * l.length)); n.add(Math.min(4f, s[1] * l.length)); n.add(Math.min(4f, s[2] * l.width));
                    ctx.add("scale", n);
                }
                flat.add("display", disp);
                if (els != null) {
                    flat.remove("parent");
                    flat.add("elements", els);
                    if (l.color >= 0) for (JsonElement el : els)
                        for (Map.Entry<String, JsonElement> f : el.getAsJsonObject().getAsJsonObject("faces").entrySet())
                            f.getValue().getAsJsonObject().addProperty("tintindex", 0);
                }
                String name = "gen/" + Util.hash(key);
                writeJson(out.resolve("assets/bleachskins/models/" + name + ".json"), flat);
                result = "bleachskins:" + name;
            }
        }
        derived.put(key, result);
        return result;
    }

    /** Box elements for a flat model's sprite layers, or null when the texture can't be read (e.g. vanilla sprite). */
    private JsonArray voxelize(JsonObject flat, float depth) {
        if (!flat.has("textures")) return null;
        JsonObject tex = flat.getAsJsonObject("textures");
        java.util.List<java.awt.image.BufferedImage> layers = new java.util.ArrayList<>();
        for (int i = 0; tex.has("layer" + i); i++) {
            String ref = Util.str(tex, "layer" + i);
            if (ref == null) return null;
            int c = ref.indexOf(':');
            String ns = c < 0 ? "minecraft" : ref.substring(0, c), path = c < 0 ? ref : ref.substring(c + 1);
            Path f = out.resolve("assets/" + ns + "/textures/" + path + ".png");
            try {
                if (!Files.isRegularFile(f)) return null;
                java.awt.image.BufferedImage im = javax.imageio.ImageIO.read(f.toFile());
                if (im == null) return null;
                layers.add(im);
            } catch (IOException e) { return null; }
        }
        return layers.isEmpty() ? null : Voxel.extrude(layers, depth);
    }

    private JsonObject readOut(String id) {
        int c = id.indexOf(':');
        String ns = c < 0 ? "minecraft" : id.substring(0, c), path = c < 0 ? id : id.substring(c + 1);
        Path f = out.resolve("assets/" + ns + "/models/" + path + ".json");
        try {
            if (Files.isRegularFile(f)) return JsonParser.parseString(Files.readString(f)).getAsJsonObject();
        } catch (Exception ignored) {}
        return null;
    }

    /** Resolve the parent chain so display/elements/textures are all in one model. */
    private JsonObject flatten(String id) {
        JsonObject first = readOut(id);
        if (first == null) return null;
        java.util.ArrayList<JsonObject> chain = new java.util.ArrayList<>();
        chain.add(first);
        String vanillaParent = null;
        JsonObject cur = first;
        for (int i = 0; i < 16; i++) {
            String p = Util.str(cur, "parent");
            if (p == null) break;
            JsonObject po = readOut(p);
            if (po == null) { vanillaParent = p; break; }
            chain.add(po);
            cur = po;
        }
        JsonObject res = new JsonObject();
        JsonObject textures = new JsonObject(), display = new JsonObject();
        for (int i = chain.size() - 1; i >= 0; i--) {   // root first, child overrides
            JsonObject o = chain.get(i);
            for (Map.Entry<String, JsonElement> en : o.entrySet()) {
                switch (en.getKey()) {
                    case "parent": break;
                    case "textures": for (Map.Entry<String, JsonElement> t : en.getValue().getAsJsonObject().entrySet()) textures.add(t.getKey(), t.getValue()); break;
                    case "display": for (Map.Entry<String, JsonElement> d : en.getValue().getAsJsonObject().entrySet()) display.add(d.getKey(), d.getValue().deepCopy()); break;
                    default: res.add(en.getKey(), en.getValue().deepCopy());
                }
            }
        }
        res.add("textures", textures);
        if (display.size() > 0) res.add("display", display);
        if (vanillaParent != null) res.addProperty("parent", vanillaParent);
        return res;
    }

    // ------------------------------------------------------------------ copying pack assets

    private void copyAssets(Skin s) throws IOException {
        PackSource p = bySlug.get(s.packSlug);
        if (p == null) return;
        for (Map.Entry<String, JsonObject> m : s.models.entrySet()) writeJson(out.resolve(m.getKey()), m.getValue());
        for (Map.Entry<String, String> c : s.copies.entrySet()) copyRaw(p, c.getKey(), c.getValue());
        if (s.externalNs != null) {
            if (done.add("ns:" + p.slug() + ":" + s.externalNs)) {
                for (String f : p.list("assets/" + s.externalNs + "/")) copyRaw(p, f, f);
            }
        }
        copyTree(s.tree);
    }

    private void copyTree(JsonElement e) throws IOException {
        if (e.isJsonObject()) {
            JsonObject o = e.getAsJsonObject();
            if ("minecraft:model".equals(Util.str(o, "type")) && Util.str(o, "model") != null) copyModel(Util.str(o, "model"));
            for (Map.Entry<String, JsonElement> en : o.entrySet()) copyTree(en.getValue());
        } else if (e.isJsonArray()) for (JsonElement x : e.getAsJsonArray()) copyTree(x);
    }

    private void copyModel(String id) throws IOException {
        int c = id.indexOf(':');
        if (c < 0) return;
        String ns = id.substring(0, c), path = id.substring(c + 1);
        if (!ns.startsWith("bs_") || !done.add("m:" + id)) return;
        PackSource p = bySlug.get(ns.substring(3));
        if (p == null) return;
        String src = "assets/minecraft/models/" + path + ".json";
        if (!p.exists(src)) return;
        JsonObject m = JsonParser.parseString(new String(p.read(src), StandardCharsets.UTF_8)).getAsJsonObject();
        String parent = Util.str(m, "parent");
        if (parent != null) {
            if (parent.endsWith("builtin/generated")) parent = "minecraft:item/generated";
            String q = Scanner.qualify(p, parent, "models", ".json");
            if (parent.endsWith("builtin/entity")) m.remove("parent");
            else m.addProperty("parent", q);
            copyModel(q);
        }
        if (m.has("textures")) {
            JsonObject tex = m.getAsJsonObject("textures");
            for (Map.Entry<String, JsonElement> t : tex.entrySet()) {
                if (!t.getValue().isJsonPrimitive()) continue;
                String q = Scanner.qualify(p, t.getValue().getAsString(), "textures", ".png");
                t.setValue(new com.google.gson.JsonPrimitive(q));
                if (q.startsWith("bs_")) {
                    String tp = q.substring(q.indexOf(':') + 1);
                    String from = "assets/minecraft/textures/" + tp + ".png";
                    String tp2 = atlasPath(tp);
                    if (!tp2.equals(tp)) t.setValue(new com.google.gson.JsonPrimitive("bs_" + p.slug() + ":" + tp2));
                    String to = "assets/bs_" + p.slug() + "/textures/" + tp2 + ".png";
                    if (done.add("t:" + to)) {
                        copyRaw(p, from, to);
                        if (p.exists(from + ".mcmeta")) copyRaw(p, from + ".mcmeta", to + ".mcmeta");
                    }
                }
            }
        }
        Scanner.dropBrokenFaces(m);
        writeJson(out.resolve("assets/" + ns + "/models/" + path + ".json"), m);
    }

    /** The game only stitches textures from item/ and block/ folders, so anything else moves under item/. */
    private static String atlasPath(String path) {
        if (path.startsWith("item/") || path.startsWith("block/")) return path;
        if (path.startsWith("items/")) return "item/" + path.substring(6);
        if (path.startsWith("blocks/")) return "block/" + path.substring(7);
        return "item/pk_" + path.replace('/', '_');
    }

    private void copyRaw(PackSource p, String from, String to) throws IOException {
        if (!p.exists(from)) return;
        Path dst = out.resolve(to);
        Files.createDirectories(dst.getParent());
        Files.write(dst, p.read(from));
    }

    private void writeItem(String ns, String id, JsonObject tree) throws IOException {
        JsonObject def = new JsonObject();
        def.add("model", tree);
        writeJson(out.resolve("assets/" + ns + "/items/" + id + ".json"), def);
    }

    private static void writeJson(Path f, JsonElement e) throws IOException {
        Files.createDirectories(f.getParent());
        Files.writeString(f, GSON.toJson(e));
    }

    public static void deleteTree(Path p) throws IOException {
        if (!Files.exists(p)) return;
        try (Stream<Path> s = Files.walk(p)) {
            for (Path x : (Iterable<Path>) s.sorted(Comparator.reverseOrder())::iterator) Files.delete(x);
        }
    }
}
