package com.bleachskins.core;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/** Effect ids shared by client and server (no Minecraft classes here). */
public final class FxIds {
    private FxIds() {}

    public static final String[] IDS = {
        "none", "flame", "soul_flame", "end_rod", "enchant", "crit", "electric_spark", "snowflake", "glow", "witch", "totem",
        "dust", "colored", "portal", "cloud"
    };
    public static final Set<String> VALID = Set.of(IDS);

    /** slash that is drawn in the air for every swing ("none" = off); names are particle types plus the vanilla sweep */
    public static final String[] SWING_IDS = {"none", "flame", "soul_flame", "end_rod", "electric_spark", "snowflake", "crit", "dust", "colored", "sweep"};
    public static final Set<String> SWING_VALID = Set.of(SWING_IDS);

    /** short key -> vanilla sound event id */
    public static final Map<String, String> SOUNDS = new LinkedHashMap<>();
    static {
        SOUNDS.put("none", "");
        SOUNDS.put("swoosh", "minecraft:entity.player.attack.sweep");
        SOUNDS.put("slash", "minecraft:entity.player.attack.strong");
        SOUNDS.put("whoosh", "minecraft:item.trident.return");
        SOUNDS.put("chime", "minecraft:block.amethyst_block.chime");
        SOUNDS.put("fire", "minecraft:item.firecharge.use");
        SOUNDS.put("blaze", "minecraft:entity.blaze.shoot");
        SOUNDS.put("spell", "minecraft:entity.evoker.cast_spell");
        SOUNDS.put("wither", "minecraft:entity.wither.shoot");
        SOUNDS.put("enchant", "minecraft:block.enchantment_table.use");
        SOUNDS.put("beacon", "minecraft:block.beacon.power_select");
        SOUNDS.put("bell", "minecraft:block.bell.use");
    }
    public static final String[] SOUND_KEYS = SOUNDS.keySet().toArray(new String[0]);
}
