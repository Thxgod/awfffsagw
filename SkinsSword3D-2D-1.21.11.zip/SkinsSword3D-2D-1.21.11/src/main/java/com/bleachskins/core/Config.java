package com.bleachskins.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Everything remembered between sessions: which library packs are on, my skins, which one is active. */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** pack slug -> enabled (missing = enabled) */
    public Map<String, Boolean> packs = new LinkedHashMap<>();
    public List<Loadout> loadouts = new ArrayList<>();
    /** category -> loadout id currently applied to the game */
    public Map<String, String> active = new LinkedHashMap<>();
    /** category -> loadout id shown in the LEFT hand (item display side); missing = same as the right hand */
    public Map<String, String> activeLeft = new LinkedHashMap<>();
    public boolean autoApply = false;
    /** GUI look: preset + the player's own tweaks */
    public Theme theme = Theme.preset("neon");
    public boolean introCopied = false;
    /** multiplayer: what you send / what you show of other mod users */
    public boolean shareMine = true, showOthersSkins = true, showOthersFx = true;
    public float othersVolume = 1f;
    /** size of the on-screen totem pop: 1 = normal, 0 = hidden */
    public float totemPopScale = 1f;
    /** height of the fire on your screen while burning: 1 = normal, 0 = hidden */
    public float fireHeight = 1f;
    /** height of fire blocks in the world: 1 = normal (the flame picture is squashed to the bottom of its square) */
    public float blockFireHeight = 1f;
    /** crosshair size: 1 = normal */
    public float crosshairScale = 1f;
    /** combat hitboxes: on/off, show every box or only the one you aim at, colour of the box you aim at */
    public boolean combatBox = false, combatBoxAll = true;
    public int combatReady = 0x4CE05A;
    /** easy mode: no fog at all; fog distance in chunks (0 = the game's); where fog starts and how far clouds fade, as a share */
    public int easySet = -1;     // the ready-made set in use, 3 = changed by hand, -1 = not known yet
    public boolean fogOff = false;
    /** brightness beyond the game's limit: on/off and the level (1 = the game's 100%) */
    public boolean gammaOn = false;
    public float gamma = 15f;
    public int fogDistance = 0;
    public float fogStart = 1f, cloudFog = 1f;
    /** colour while hitting; -1 means the same as the aim colour */
    public int combatHit = -1;
    /** the box you aim at: how much darker than the chosen colour (0..0.7), and how thick the lines are (1 = the game's) */
    public float combatDarker = 0.25f, combatWidth = 1.6f;
    public int combatHitColour() { return combatHit < 0 ? combatReady : combatHit; }
    /** no particles while mining or breaking blocks */
    public boolean noBlockParticles = false;
    public boolean noExplosionFx = true;
    public boolean noRain = false;
    /** cobweb: a wire cube around the block, size of the web in the middle (0 = none), how solid the web is */
    public boolean cobwebFrame = false;
    public float cobwebSize = 1f, cobwebOpacity = 1f;
    /** first-person size of held items: item id (path) -> size, others use heldAll */
    public Map<String, Float> heldScale = new LinkedHashMap<>();
    public float heldAll = 1f;
    /** size food shrinks to by the end of eating: 1 = no shrink */
    public float eatShrink = 0.25f;
    /** look group (Looks) -> what replaces its vanilla textures; missing = vanilla */
    public Map<String, Choice> choices = new LinkedHashMap<>();

    public static final class Choice {
        public String kind = "style";      // "pack", "style", "drawn" or "shape" (crosshair: drawn = shape name, rgb = colour)
        public String pack;                // kind pack: pack slug
        public int rgb;                    // kind style: colour
        public String drawn;               // kind drawn: drawing name
    }

    public boolean enabled(String slug) { return packs.getOrDefault(slug, true); }

    public Loadout loadout(String id) {
        if (id == null) return null;
        for (Loadout l : loadouts) if (id.equals(l.id)) return l;
        return null;
    }

    public Loadout activeFor(String cat) { return loadout(active.get(cat)); }
    public Loadout activeLeftFor(String cat) { return loadout(activeLeft.get(cat)); }

    public static Config load(Path file) {
        try {
            if (Files.exists(file)) {
                Config c = GSON.fromJson(Files.readString(file), Config.class);
                if (c != null) {
                    if (c.packs == null) c.packs = new LinkedHashMap<>();
                    if (c.loadouts == null) c.loadouts = new ArrayList<>();
                    if (c.active == null) c.active = new LinkedHashMap<>();
                    if (c.activeLeft == null) c.activeLeft = new LinkedHashMap<>();
                    if (c.heldScale == null) c.heldScale = new LinkedHashMap<>();
                    if (c.choices == null) c.choices = new LinkedHashMap<>();
                    if (c.theme == null) c.theme = Theme.preset("neon");
                    return c;
                }
            }
        } catch (Exception ignored) {}
        return new Config();
    }

    public void save(Path file) {
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, GSON.toJson(this));
        } catch (IOException ignored) {}
    }
}
