package com.bleachskins.core;

/** A "my skin": a base skin plus tweaks. Saved in the config file. */
public final class Loadout {
    public String id;
    public String name = "My skin";
    public String category = "sword";
    public String skin;            // Skin.key() of the base look, null = none
    public String overlay;         // optional second skin layered on top (combine)
    public int color = -1;         // 0xRRGGBB tint, -1 = no tint
    public float length = 1f;      // blade length multiplier
    public float width = 1f;       // blade thickness multiplier
    public String particle = "none";
    public int rate = 2;           // particles per tick
    public float depth = 2f;       // 3D thickness for flat 2D sprites (model units, 0 = leave flat)
    public String swing = "none"; // slash effect drawn on every swing (FxIds.SWING_IDS)
    public int fxColor = -1;       // effect colour (0xRRGGBB), -1 = white / follow blade tint
    public float fxSize = 1f;      // effect particle size
    public String sound = "none";  // FxIds.SOUNDS key, played on every swing
    public float volume = 0.6f;
    public float pitch = 1f;

    public Loadout() {}

    public Loadout copy() {
        Loadout l = new Loadout();
        l.id = id; l.name = name; l.category = category; l.skin = skin; l.overlay = overlay;
        l.color = color; l.length = length; l.width = width; l.particle = particle; l.rate = rate;
        l.swing = swing; l.depth = depth; l.fxColor = fxColor; l.fxSize = fxSize; l.sound = sound; l.volume = volume; l.pitch = pitch;
        return l;
    }

    /** Identifies the LOOK (skin, combine, tint, size, 3D depth) - effects/sounds/name don't change it. */
    public String sig() {
        return Util.hash(category + "|" + skin + "|" + overlay + "|" + color + "|" + length + "|" + width + "|" + depth);
    }

    /** a skin with default tweaks: what "just pick it" means */
    public static Loadout plain(String category, String skinKey) {
        Loadout l = new Loadout();
        l.category = category; l.skin = skinKey;
        return l;
    }

    public boolean customized() { return color >= 0 || length != 1f || width != 1f || depth > 0f; }
}
