package com.bleachskins.core;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** The folder the player drops resource packs into. */
public final class Library {
    private Library() {}

    public static List<PackSource> open(Path dir) {
        List<PackSource> r = new ArrayList<>();
        try {
            Files.createDirectories(dir);
            try (Stream<Path> s = Files.list(dir)) {
                for (Path p : (Iterable<Path>) s.sorted()::iterator) {
                    try {
                        String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                        PackSource src = Files.isRegularFile(p) && n.endsWith(".zip") ? new ZipPackSource(p)
                            : Files.isDirectory(p) ? new DirPackSource(p) : null;
                        if (src == null) continue;
                        if (isGenerated(src)) src.close(); else r.add(src);
                    } catch (IOException | RuntimeException ignored) { /* broken pack: skip */ }
                }
            }
        } catch (IOException ignored) {}
        return r;
    }

    /** A copy of the pack this mod builds: reading it back would list every look again as a broken skin. */
    private static boolean isGenerated(PackSource p) {
        return !p.list("assets/bleachskins/items/").isEmpty();
    }

    public static void closeAll(List<PackSource> l) { for (PackSource p : l) p.close(); }
}
