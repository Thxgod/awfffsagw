package com.bleachskins.core;

import java.io.IOException;
import java.util.List;

/** Read-only view of one resource pack (zip or folder). Paths use '/' and are relative to the pack root. */
public interface PackSource extends AutoCloseable {
    String name();
    String slug();
    boolean exists(String path);
    byte[] read(String path) throws IOException;
    /** All file paths starting with prefix. */
    List<String> list(String prefix);
    @Override void close();
}
