package com.bleachskins.core;

import java.util.ArrayList;
import java.util.List;

/** Groups vanilla items so one skin can be applied to every item of its kind (all swords, ...). */
public final class Categories {
    private Categories() {}

    private static final String[] TOOLS = {"sword", "pickaxe", "axe", "shovel", "hoe", "spear"};
    private static final String[] MATS = {"wooden", "stone", "copper", "iron", "golden", "diamond", "netherite"};

    public static String of(String itemPath) {
        for (String t : TOOLS) if (itemPath.endsWith("_" + t)) return t;
        return itemPath;
    }

    public static boolean isTool(String cat) {
        for (String t : TOOLS) if (t.equals(cat)) return true;
        return false;
    }

    /** Every vanilla item id (path only) the category covers. */
    public static List<String> items(String cat) {
        List<String> l = new ArrayList<>();
        if (isTool(cat)) for (String m : MATS) l.add(m + "_" + cat);
        else l.add(cat);
        return l;
    }

    public static String previewItem(String cat) {
        return isTool(cat) ? "netherite_" + cat : cat;
    }

    /** Best guess for skins that arrive as stand-alone item definitions. */
    public static String guess(String name) {
        String n = name.toLowerCase();
        for (String k : new String[] {"bow", "pickaxe", "axe", "shovel", "hoe", "spear", "trident", "shield"})
            if (n.contains(k)) return k;
        return "sword";
    }

    public static String label(String cat) {
        return Character.toUpperCase(cat.charAt(0)) + cat.substring(1).replace('_', ' ') + (cat.endsWith("s") ? "" : "s");
    }
}
