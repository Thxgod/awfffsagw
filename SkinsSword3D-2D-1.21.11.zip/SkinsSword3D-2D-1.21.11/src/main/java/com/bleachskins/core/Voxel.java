package com.bleachskins.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.awt.image.BufferedImage;
import java.util.List;

/**
 * Turns flat 2D item sprites into real 3D models: every row of opaque pixels becomes one box element
 * (so a 16x16 sword is a few dozen boxes) with the sprite colours on all sides.
 */
public final class Voxel {
    private Voxel() {}

    public static final int MAX_ELEMENTS = 700;

    /** First animation frame: tall strips (h = n * w) are cut to a square. */
    public static BufferedImage firstFrame(BufferedImage im) {
        int w = im.getWidth(), h = im.getHeight();
        return (h > w && h % w == 0) ? im.getSubimage(0, 0, w, w) : im;
    }

    private static float r(float v) { return Math.round(v * 1000f) / 1000f; }

    private static JsonArray arr(float... v) {
        JsonArray a = new JsonArray();
        for (float f : v) a.add(r(f));
        return a;
    }

    private static JsonObject face(String tex, float u1, float v1, float u2, float v2) {
        JsonObject f = new JsonObject();
        f.add("uv", arr(u1, v1, u2, v2));
        f.addProperty("texture", tex);
        return f;
    }

    /**
     * @param layers   one image per sprite layer (layer0, layer1, ...)
     * @param depth    thickness in model units (1 unit = 1/16 block); the vanilla flat item is about 1
     * @return the "elements" array, or null if the sprite is empty or too detailed
     */
    public static JsonArray extrude(List<BufferedImage> layers, float depth) {
        JsonArray out = new JsonArray();
        for (int li = 0; li < layers.size(); li++) {
            BufferedImage im = firstFrame(layers.get(li));
            int w = im.getWidth(), h = im.getHeight();
            float sx = 16f / w, sy = 16f / h;
            float d = depth + 0.08f * li;           // later layers a hair thicker so they never z-fight
            float z1 = 8 - d / 2, z2 = 8 + d / 2;
            String tex = "#layer" + li;
            for (int py = 0; py < h; py++) {
                int px = 0;
                while (px < w) {
                    if (alpha(im, px, py) == 0) { px++; continue; }
                    int xa = px;
                    while (px < w && alpha(im, px, py) != 0) px++;
                    int xb = px;                    // run = [xa, xb)
                    float top = 16 - py * sy, bot = 16 - (py + 1) * sy;
                    float x1 = xa * sx, x2 = xb * sx;
                    JsonObject el = new JsonObject();
                    el.add("from", arr(x1, bot, z1));
                    el.add("to", arr(x2, top, z2));
                    JsonObject faces = new JsonObject();
                    float v1 = py * sy, v2 = (py + 1) * sy;
                    faces.add("south", face(tex, x1, v1, x2, v2));
                    faces.add("north", face(tex, x2, v1, x1, v2));
                    faces.add("west", face(tex, x1, v1, x1 + sx, v2));
                    faces.add("east", face(tex, x2 - sx, v1, x2, v2));
                    faces.add("up", face(tex, x1, v1, x2, v1 + sy * 0.5f));
                    faces.add("down", face(tex, x1, v2 - sy * 0.5f, x2, v2));
                    el.add("faces", faces);
                    out.add(el);
                    if (out.size() > MAX_ELEMENTS) return null;
                }
            }
        }
        return out.isEmpty() ? null : out;
    }

    private static int alpha(BufferedImage im, int x, int y) {
        return ((im.getRGB(x, y) >>> 24) & 255) < 16 ? 0 : 1;
    }
}
