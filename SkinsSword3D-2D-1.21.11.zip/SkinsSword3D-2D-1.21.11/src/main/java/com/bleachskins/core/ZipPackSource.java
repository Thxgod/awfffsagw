package com.bleachskins.core;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class ZipPackSource implements PackSource {
    private final ZipFile zip;
    private final String name, slug;
    private String root = ""; // some zips wrap everything in one folder

    public ZipPackSource(Path file) throws IOException {
        this.zip = new ZipFile(file.toFile());
        String fn = file.getFileName().toString();
        this.name = fn.replaceAll("(?i)\\.zip$", "");
        this.slug = Util.slug(fn);
        Enumeration<? extends ZipEntry> en = zip.entries();
        int best = Integer.MAX_VALUE;
        while (en.hasMoreElements()) {
            String n = en.nextElement().getName();
            if (n.equals("pack.mcmeta") || n.endsWith("/pack.mcmeta")) {
                int depth = n.split("/").length;
                if (depth < best) { best = depth; root = n.substring(0, n.length() - "pack.mcmeta".length()); }
            }
        }
    }

    @Override public String name() { return name; }
    @Override public String slug() { return slug; }
    @Override public boolean exists(String path) {
        ZipEntry e = zip.getEntry(root + path);
        return e != null && !e.isDirectory();
    }
    @Override public byte[] read(String path) throws IOException {
        ZipEntry e = zip.getEntry(root + path);
        if (e == null) throw new IOException("missing " + path);
        try (InputStream in = zip.getInputStream(e)) { return in.readAllBytes(); }
    }
    @Override public List<String> list(String prefix) {
        List<String> r = new ArrayList<>();
        Enumeration<? extends ZipEntry> en = zip.entries();
        while (en.hasMoreElements()) {
            ZipEntry e = en.nextElement();
            String n = e.getName();
            if (!e.isDirectory() && n.startsWith(root + prefix)) r.add(n.substring(root.length()));
        }
        return r;
    }
    @Override public void close() { try { zip.close(); } catch (IOException ignored) {} }
}
