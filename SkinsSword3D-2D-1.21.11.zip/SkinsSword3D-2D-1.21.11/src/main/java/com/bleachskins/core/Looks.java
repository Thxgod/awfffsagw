package com.bleachskins.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Things you can re-skin anywhere in the game. A group is one or more vanilla textures that change together. */
public final class Looks {
    private Looks() {}

    public static final String SINGLE = "tex:";
    public static final Map<String, String[]> FEATURED = new LinkedHashMap<>();
    static {
        FEATURED.put("combat", new String[0]);                 // settings only, no textures
        FEATURED.put("plants", new String[] {"block/short_grass", "block/tall_grass_top", "block/tall_grass_bottom", "block/fern", "block/large_fern_top", "block/large_fern_bottom",
            "block/bush", "block/short_dry_grass", "block/tall_dry_grass", "block/dead_bush", "block/seagrass", "block/tall_seagrass_top", "block/tall_seagrass_bottom",
            "block/nether_sprouts", "block/crimson_roots", "block/warped_roots", "block/firefly_bush"});
        FEATURED.put("crystal", new String[] {"entity/end_crystal/end_crystal", "item/end_crystal", "entity/end_crystal/end_crystal_beam"});
        FEATURED.put("anchor", new String[] {"block/respawn_anchor_side0", "block/respawn_anchor_side1", "block/respawn_anchor_side2",
            "block/respawn_anchor_side3", "block/respawn_anchor_side4", "block/respawn_anchor_top", "block/respawn_anchor_top_off", "block/respawn_anchor_bottom"});
        FEATURED.put("totem", new String[] {"item/totem_of_undying"});
        FEATURED.put("pearl", new String[] {"item/ender_pearl"});
        FEATURED.put("gapple", new String[] {"item/golden_apple"});
        FEATURED.put("shield", new String[] {"entity/shield_base_nopattern", "entity/shield_base"});
        FEATURED.put("glowstone", new String[] {"block/glowstone"});
        FEATURED.put("obsidian", new String[] {"block/obsidian", "block/crying_obsidian"});
        FEATURED.put("fire", new String[] {"block/fire_0", "block/fire_1", "block/campfire_fire", "block/campfire_log_lit"});
        FEATURED.put("soul_fire", new String[] {"block/soul_fire_0", "block/soul_fire_1", "block/soul_campfire_fire", "block/soul_campfire_log_lit"});
        FEATURED.put("tnt", new String[] {"block/tnt_side", "block/tnt_top", "block/tnt_bottom"});
        FEATURED.put("cobweb", new String[] {"block/cobweb"});
        FEATURED.put("stone", new String[] {"block/stone"});
        FEATURED.put("deepslate", new String[] {"block/deepslate"});
        FEATURED.put("grass", new String[] {"block/grass_block_top", "block/grass_block_side", "block/grass_block_side_overlay"});
        FEATURED.put("snow", new String[] {"block/snow", "block/grass_block_snow"});
        FEATURED.put("mace", new String[] {"item/mace"});
        FEATURED.put("glint", new String[] {"misc/enchanted_glint_item", "misc/enchanted_glint_armor"});
        FEATURED.put("hearts", new String[] {"gui/sprites/hud/heart/full", "gui/sprites/hud/heart/full_blinking"});
        FEATURED.put("food", new String[] {"gui/sprites/hud/food_full"});
        FEATURED.put("crosshair", new String[] {"gui/sprites/hud/crosshair"});
        FEATURED.put("sun", new String[] {"environment/celestial/sun"});
    }

    /** look group -> vanilla item shown as its icon */
    public static final Map<String, String> ICONS = new LinkedHashMap<>();
    static {
        String[][] i = {{"combat", "iron_sword"}, {"plants", "wheat_seeds"}, {"crystal", "end_crystal"}, {"anchor", "respawn_anchor"}, {"totem", "totem_of_undying"}, {"pearl", "ender_pearl"}, {"gapple", "golden_apple"},
            {"shield", "shield"}, {"glowstone", "glowstone"}, {"obsidian", "obsidian"}, {"fire", "blaze_powder"}, {"soul_fire", "soul_torch"}, {"tnt", "tnt"}, {"cobweb", "cobweb"},
            {"stone", "stone"}, {"deepslate", "deepslate"}, {"grass", "grass_block"}, {"snow", "snow_block"}, {"mace", "mace"}, {"glint", "enchanted_book"},
            {"hearts", "red_dye"}, {"food", "cooked_beef"}, {"crosshair", "spyglass"}, {"sun", "sunflower"}};
        for (String[] e : i) ICONS.put(e[0], e[1]);
    }

    /** look group -> the item you hold; groups that are not something you hold are left out */
    public static String heldItem(String group) {
        if (group.startsWith(SINGLE)) {
            String f = group.substring(SINGLE.length());
            return f.startsWith("item/") || f.startsWith("block/") ? f.substring(f.indexOf('/') + 1) : null;
        }
        return switch (group) {
            case "crystal", "anchor", "totem", "pearl", "gapple", "shield", "glowstone", "obsidian", "tnt", "cobweb", "stone", "deepslate", "grass", "snow", "mace" -> ICONS.get(group);
            default -> null;
        };
    }

    /** foods that get bite marks while eaten: item id -> its sprite */
    public static final Map<String, String> FOODS = new LinkedHashMap<>();
    static {
        for (String f : new String[] {"apple", "golden_apple", "carrot", "golden_carrot", "potato", "baked_potato", "poisonous_potato", "beetroot", "bread", "cookie",
            "melon_slice", "glistering_melon_slice", "sweet_berries", "glow_berries", "pumpkin_pie", "dried_kelp", "chorus_fruit", "beef", "cooked_beef", "porkchop", "cooked_porkchop",
            "chicken", "cooked_chicken", "mutton", "cooked_mutton", "rabbit", "cooked_rabbit", "cod", "cooked_cod", "salmon", "cooked_salmon", "tropical_fish", "pufferfish",
            "rotten_flesh", "spider_eye", "honey_bottle"}) FOODS.put(f, "item/" + f);
        FOODS.remove("honey_bottle");
        FOODS.remove("glistering_melon_slice");
        FOODS.put("enchanted_golden_apple", "item/golden_apple");
    }
    public static final int BITE_STAGES = 3;

    public static final String[] CROSSHAIRS = {"plus", "gap", "dot", "big_dot", "circle", "circle_dot", "square", "x", "t", "chevron", "corners", "diamond"};

    /** The picture that stands for a group on its cards, when it isn't simply the group's first texture. */
    public static String iconFile(String group) { return "crystal".equals(group) ? "item/end_crystal" : files(group).get(0); }

    /** name -> colour of the ready-made recolours */
    public static final Map<String, Integer> STYLES = new LinkedHashMap<>();
    static {
        STYLES.put("Crimson", 0xE0483E); STYLES.put("Frost", 0x5CE1FF); STYLES.put("Toxic", 0x4CE05A); STYLES.put("Royal", 0x9B5CFF);
        STYLES.put("Gilded", 0xFFC83B); STYLES.put("Sakura", 0xFF7AC8); STYLES.put("Ocean", 0x3B8CFF); STYLES.put("Snow", 0xFFFFFF); STYLES.put("Shadow", 0x555566);
        STYLES.put("Lava", 0xFF6A1F); STYLES.put("Lemon", 0xFFF04A); STYLES.put("Lime", 0xA6FF3B); STYLES.put("Mint", 0x5CFFC0);
        STYLES.put("Aqua", 0x2EE6D6); STYLES.put("Sky", 0x8FD6FF); STYLES.put("Violet", 0xC77DFF); STYLES.put("Magenta", 0xFF3BD0);
        STYLES.put("Rose", 0xFF4F7B); STYLES.put("Copper", 0xC8703A); STYLES.put("Silver", 0xB8C4D0);
    }

    public static List<String> files(String group) {
        if (group.startsWith(SINGLE)) return List.of(group.substring(SINGLE.length()));
        String[] f = FEATURED.get(group);
        return f == null ? List.of() : List.of(f);
    }

    private static final Map<String, String> OLD_NAMES = new LinkedHashMap<>();
    static {
        OLD_NAMES.put("item/totem_of_undying", "items/totem");
        OLD_NAMES.put("item/golden_apple", "items/apple_golden");
        OLD_NAMES.put("entity/end_crystal/end_crystal", "entity/endercrystal/endercrystal");
        OLD_NAMES.put("entity/end_crystal/end_crystal_beam", "entity/endercrystal/endercrystal_beam");
    }

    /** Where a pack may keep this texture: today's path, then the paths used before Minecraft 1.13. */
    public static List<String> candidates(String file) {
        List<String> l = new ArrayList<>();
        l.add(file);
        if (OLD_NAMES.containsKey(file)) l.add(OLD_NAMES.get(file));
        if (file.startsWith("item/")) l.add("items/" + file.substring(5));
        if (file.startsWith("block/")) l.add("blocks/" + file.substring(6));
        return l;
    }

    /** The texture path inside the pack ("assets/minecraft/textures/....png"), or null. */
    public static String find(PackSource p, String file) {
        for (String c : candidates(file)) {
            String path = "assets/minecraft/textures/" + c + ".png";
            if (p.exists(path)) return path;
        }
        return null;
    }
}
