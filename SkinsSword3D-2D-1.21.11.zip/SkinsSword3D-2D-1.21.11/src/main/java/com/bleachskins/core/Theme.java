package com.bleachskins.core;

/** Look of the GUI. Colours are 0xRRGGBB. Saved inside the config, so every tweak is remembered. */
public final class Theme {
    public static final String[] IDS = {"neon", "arena", "mono", "soul", "hollow", "quincy", "sakura", "glass", "classic"};
    public static final int STATIC = 0, RAINBOW = 1, PULSE = 2;

    public String preset = "neon";
    public int bg, panel, card, hot, text, dim, accent;
    public int mode = STATIC;          // accent animation
    public float opacity = 0.95f;      // panels / cards, 0.05 .. 1
    public int cardSize = 1;           // 0 compact, 1 normal, 2 large
    public boolean gradientBar = true; // glowing line under the top bar
    public boolean border = true;      // thin accent outline on cards
    public int style = 0;              // 0 = flat squares, 1 = glass: rounded cards, pill tabs, slanted action buttons
    public int action = 0x3FD16A;      // colour of the main "Equip" button
    public String bgImage = "";        // file name in bleachskins/backgrounds, "" = none
    public int bgColor = 0xFFFFFF;     // multiplied with the image (white = unchanged)
    public float bgOpacity = 0.6f;     // 0 .. 1

    private static Theme make(String id, int bg, int panel, int card, int hot, int text, int dim, int accent,
                              int mode, float opacity, boolean bar) {
        Theme t = new Theme();
        t.preset = id; t.bg = bg; t.panel = panel; t.card = card; t.hot = hot; t.text = text; t.dim = dim;
        t.accent = accent; t.mode = mode; t.opacity = opacity; t.gradientBar = bar;
        return t;
    }

    public static Theme preset(String id) {
        return switch (id) {
            case "arena"   -> arena(id);
            case "mono"    -> mono(id);
            case "soul"    -> make(id, 0x0A0A0A, 0x151515, 0x1E1E1E, 0x333333, 0xF2F2F2, 0x9A9A9A, 0xFFFFFF, STATIC, 0.96f, true);
            case "hollow"  -> make(id, 0x0D0508, 0x1A0A10, 0x261018, 0x3D1822, 0xFFE9E9, 0xB08A92, 0xFF2A4A, PULSE, 0.96f, true);
            case "quincy"  -> make(id, 0x06101F, 0x0C1B33, 0x12294A, 0x1C3E70, 0xEAF6FF, 0x7FA6CC, 0x5CE1FF, STATIC, 0.96f, true);
            case "sakura"  -> make(id, 0x140A14, 0x241228, 0x321A38, 0x4A2850, 0xFFEFFA, 0xC79BC4, 0xFF7AC8, PULSE, 0.96f, true);
            case "glass"   -> make(id, 0x000000, 0x101820, 0x1A2430, 0x2B3A4C, 0xFFFFFF, 0xA0B0C0, 0x7CFFB2, STATIC, 0.55f, true);
            case "classic" -> make(id, 0x2B2B2B, 0x3C3C3C, 0x4A4A4A, 0x5C5C5C, 0xFFFFFF, 0xBBBBBB, 0x55FF55, STATIC, 1.0f, false);
            default        -> make("neon", 0x0B0D14, 0x141826, 0x1C2236, 0x2A3354, 0xE8ECFF, 0x8791B5, 0x8FD6FF, RAINBOW, 0.95f, true);
        };
    }

    private static Theme arena(String id) {
        Theme t = make(id, 0x0E0E12, 0x17171C, 0x1F1F25, 0x2B2B33, 0xFFFFFF, 0x8E8E99, 0xF08A2E, STATIC, 0.96f, false);
        t.style = 1; t.action = 0x3FD16A;
        return t;
    }

    private static Theme mono(String id) {
        Theme t = make(id, 0x0C0C0C, 0x161616, 0x202020, 0x3A3A3A, 0xF4F4F4, 0xA8A8A8, 0xFFFFFF, STATIC, 0.62f, false);
        t.style = 1; t.action = 0xE8E8E8; t.border = false;
        return t;
    }

    public int radius() { return style == 1 ? 6 : 0; }

    /** ARGB with this theme's opacity. */
    public int a(int rgb) { return ((int) (Math.max(0.05f, Math.min(1f, opacity)) * 255) << 24) | (rgb & 0xFFFFFF); }

    public int solid(int rgb) { return 0xFF000000 | (rgb & 0xFFFFFF); }

    /** Current accent colour (opaque ARGB), animated according to `mode`. */
    public int accentAt(long ms) {
        switch (mode) {
            case RAINBOW: return 0xFF000000 | hsv((ms % 8000L) / 8000f, 0.55f, 1f);
            case PULSE: {
                double k = 0.65 + 0.35 * Math.sin(ms / 400.0);
                int r = (int) (((accent >> 16) & 255) * k), g = (int) (((accent >> 8) & 255) * k), b = (int) ((accent & 255) * k);
                return 0xFF000000 | (r << 16) | (g << 8) | b;
            }
            default: return solid(accent);
        }
    }

    public static int hsv(float h, float s, float v) {
        float r, g, b;
        float hh = (h - (float) Math.floor(h)) * 6f;
        int i = (int) hh; float f = hh - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        switch (i) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public Theme copy() {
        Theme t = new Theme();
        t.preset = preset; t.bg = bg; t.panel = panel; t.card = card; t.hot = hot; t.text = text; t.dim = dim; t.accent = accent;
        t.mode = mode; t.opacity = opacity; t.cardSize = cardSize; t.gradientBar = gradientBar; t.border = border;
        t.style = style; t.action = action; t.bgImage = bgImage; t.bgColor = bgColor; t.bgOpacity = bgOpacity;
        return t;
    }
}
