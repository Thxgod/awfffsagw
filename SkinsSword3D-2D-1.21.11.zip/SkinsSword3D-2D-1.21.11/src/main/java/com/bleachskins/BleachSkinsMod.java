package com.bleachskins;

import com.bleachskins.core.FxIds;
import com.bleachskins.net.EffectsPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Common (client + server) side. Only relays effect lists between players: a player who has the mod
 * sends their effects up, the server forwards them to the OTHER players who also have the mod.
 * Players without the mod never receive or render anything (they see vanilla swords, no effects). Needs the mod on the server (or LAN/singleplayer host).
 */
public class BleachSkinsMod implements ModInitializer {
    /** latest effect list per online player */
    private static final Map<UUID, List<EffectsPayload.Entry>> STATE = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(EffectsPayload.TYPE, EffectsPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(EffectsPayload.TYPE, EffectsPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(EffectsPayload.TYPE, (payload, context) -> {
            ServerPlayer sender = context.player();
            List<EffectsPayload.Entry> clean = sanitize(payload.entries());
            if (clean.isEmpty()) STATE.remove(sender.getUUID()); else STATE.put(sender.getUUID(), clean);
            broadcast(context.server(), sender, new EffectsPayload(sender.getUUID(), clean));
        });

        // tell a newly joined player about everyone who already has effects
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer joined = handler.getPlayer();
            for (Map.Entry<UUID, List<EffectsPayload.Entry>> e : STATE.entrySet()) {
                if (e.getKey().equals(joined.getUUID())) continue;
                if (ServerPlayNetworking.canSend(joined, EffectsPayload.TYPE))
                    ServerPlayNetworking.send(joined, new EffectsPayload(e.getKey(), e.getValue()));
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer left = handler.getPlayer();
            if (STATE.remove(left.getUUID()) != null)
                broadcast(server, left, new EffectsPayload(left.getUUID(), List.of()));
        });
    }

    private static void broadcast(MinecraftServer server, ServerPlayer from, EffectsPayload payload) {
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other == from) continue;
            if (ServerPlayNetworking.canSend(other, EffectsPayload.TYPE)) ServerPlayNetworking.send(other, payload);
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Float.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v));
    }

    /** Never trust the client: clamp everything. */
    private static List<EffectsPayload.Entry> sanitize(List<EffectsPayload.Entry> in) {
        List<EffectsPayload.Entry> out = new ArrayList<>();
        for (EffectsPayload.Entry e : in) {
            if (out.size() >= EffectsPayload.MAX_ENTRIES) break;
            boolean hasSkin = e.skin().matches("pv_[0-9a-f]{1,16}");
            boolean hasFx = FxIds.VALID.contains(e.particle()) && !"none".equals(e.particle());
            boolean hasSound = FxIds.SOUNDS.containsKey(e.sound()) && !"none".equals(e.sound());
            boolean hasSwing = FxIds.SWING_VALID.contains(e.swing()) && !"none".equals(e.swing());
            if (!hasSkin && !hasFx && !hasSound && !hasSwing) continue;
            if (e.category().isEmpty() || !e.category().matches("[a-z0-9_]+")) continue;
            out.add(new EffectsPayload.Entry(e.category(), e.hand() == 1 ? 1 : 0, hasSkin ? e.skin() : "",
                hasFx ? e.particle() : "none", e.color(), Math.max(1, Math.min(8, e.rate())),
                clamp(e.length(), 0.5f, 2f), clamp(e.size(), 0.3f, 3f),
                hasSound ? e.sound() : "none", clamp(e.volume(), 0f, 1f), clamp(e.pitch(), 0.5f, 2f), hasSwing ? e.swing() : "none"));
        }
        return out;
    }
}
