package com.bleachskins.net;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * "This player's weapons look like this and have these effects (particles, sound)."
 * Client -> server: the player's own effects (uuid ignored).
 * Server -> other clients: same list tagged with the owner's uuid. An empty list means "no effects".
 */
public record EffectsPayload(UUID player, List<Entry> entries) implements CustomPacketPayload {
    public static final Type<EffectsPayload> TYPE =
        new Type<>(Identifier.fromNamespaceAndPath("bleachskins", "effects"));

    public static final StreamCodec<RegistryFriendlyByteBuf, EffectsPayload> CODEC =
        StreamCodec.ofMember((p, buf) -> p.write(buf), EffectsPayload::read);

    public static final int MAX_ENTRIES = 12;

    /**
     * hand: 0 = right display side, 1 = left. category = weapon kind ("sword", "bow", ...).
     * skin = preview id of the base skin ("pv_..."), empty = none; other mod users show it if they own the same pack.
     */
    public record Entry(String category, int hand, String skin, String particle, int color, int rate, float length,
                        float size, String sound, float volume, float pitch, String swing) {}

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    private void write(RegistryFriendlyByteBuf buf) {
        buf.writeUUID(player);
        int n = Math.min(MAX_ENTRIES, entries.size());
        buf.writeVarInt(n);
        for (int i = 0; i < n; i++) {
            Entry e = entries.get(i);
            buf.writeUtf(e.category(), 32);
            buf.writeByte(e.hand());
            buf.writeUtf(e.skin(), 32);
            buf.writeUtf(e.particle(), 32);
            buf.writeInt(e.color());
            buf.writeByte(e.rate());
            buf.writeFloat(e.length());
            buf.writeFloat(e.size());
            buf.writeUtf(e.sound(), 32);
            buf.writeFloat(e.volume());
            buf.writeFloat(e.pitch());
            buf.writeUtf(e.swing(), 32);
        }
    }

    private static EffectsPayload read(RegistryFriendlyByteBuf buf) {
        UUID id = buf.readUUID();
        int n = Math.min(MAX_ENTRIES, buf.readVarInt());
        List<Entry> l = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            l.add(new Entry(buf.readUtf(32), buf.readByte(), buf.readUtf(32), buf.readUtf(32), buf.readInt(), buf.readByte(),
                buf.readFloat(), buf.readFloat(), buf.readUtf(32), buf.readFloat(), buf.readFloat(), buf.readUtf(32)));
        }
        return new EffectsPayload(id, l);
    }
}
