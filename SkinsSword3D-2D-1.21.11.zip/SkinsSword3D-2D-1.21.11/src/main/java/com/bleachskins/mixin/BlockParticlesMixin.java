package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No particles while mining or when a block breaks. */
@Mixin(ClientLevel.class)
abstract class BlockParticlesMixin {
    @Inject(method = "addDestroyBlockEffect", at = @At("HEAD"), cancellable = true)
    private void bleachskins$noBreak(BlockPos pos, BlockState state, CallbackInfo ci) {
        if (SkinManager.cfg.noBlockParticles) ci.cancel();
    }

    @Inject(method = "addBreakingBlockEffect", at = @At("HEAD"), cancellable = true)
    private void bleachskins$noMining(BlockPos pos, Direction side, CallbackInfo ci) {
        if (SkinManager.cfg.noBlockParticles) ci.cancel();
    }
}
