package com.bleachskins.mixin;

import com.bleachskins.client.FogTweak;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Fog distance, start and "no fog" from the easy mode page. */
@Mixin(FogRenderer.class)
abstract class FogRendererMixin {
    private static final String UPDATE = "Lnet/minecraft/client/renderer/fog/FogRenderer;updateBuffer(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V";

    @Inject(method = "setupFog", at = @At("HEAD"))
    private void bleachskins$begin(Camera camera, int a, DeltaTracker delta, float b, ClientLevel level, CallbackInfoReturnable<Vector4f> cir) {
        FogTweak.air = false;
    }

    @ModifyArg(method = "setupFog", at = @At(value = "INVOKE", target = UPDATE), index = 3)
    private float bleachskins$envStart(float v) { return FogTweak.environment(v); }
    @ModifyArg(method = "setupFog", at = @At(value = "INVOKE", target = UPDATE), index = 4)
    private float bleachskins$envEnd(float v) { return FogTweak.environment(v); }
    @ModifyArg(method = "setupFog", at = @At(value = "INVOKE", target = UPDATE), index = 5)
    private float bleachskins$start(float v) { return FogTweak.start(v); }
    @ModifyArg(method = "setupFog", at = @At(value = "INVOKE", target = UPDATE), index = 6)
    private float bleachskins$end(float v) { return FogTweak.end(v); }
    @ModifyArg(method = "setupFog", at = @At(value = "INVOKE", target = UPDATE), index = 7)
    private float bleachskins$sky(float v) { return FogTweak.sky(v); }
    @ModifyArg(method = "setupFog", at = @At(value = "INVOKE", target = UPDATE), index = 8)
    private float bleachskins$cloud(float v) { return FogTweak.cloud(v); }
}
