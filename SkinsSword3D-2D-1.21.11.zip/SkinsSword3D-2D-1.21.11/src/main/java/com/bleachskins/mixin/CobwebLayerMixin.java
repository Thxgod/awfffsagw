package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** A see-through cobweb has to be drawn in the translucent layer (the normal one is all or nothing per pixel). */
@Mixin(ItemBlockRenderTypes.class)
abstract class CobwebLayerMixin {
    @Inject(method = "getChunkRenderType", at = @At("HEAD"), cancellable = true)
    private static void bleachskins$cobweb(BlockState state, CallbackInfoReturnable<ChunkSectionLayer> cir) {
        if (SkinManager.cfg.cobwebOpacity < 1f && state.is(Blocks.COBWEB)) cir.setReturnValue(ChunkSectionLayer.TRANSLUCENT);
    }
}
