package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Crosshair size, and real colours for a customised crosshair (the normal one inverts what is behind it). */
@Mixin(Gui.class)
abstract class GuiCrosshairMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"))
    private void bleachskins$sizeStart(GuiGraphics g, DeltaTracker delta, CallbackInfo ci) {
        float k = SkinManager.cfg.crosshairScale;
        float cx = (g.guiWidth() - 15) / 2 + 7.5f, cy = (g.guiHeight() - 15) / 2 + 7.5f;
        g.pose().pushMatrix();
        g.pose().translate(cx, cy);
        g.pose().scale(k, k);
        g.pose().translate(-cx, -cy);
    }

    @Inject(method = "renderCrosshair", at = @At("RETURN"))
    private void bleachskins$sizeEnd(GuiGraphics g, DeltaTracker delta, CallbackInfo ci) {
        g.pose().popMatrix();
    }

    @ModifyArg(method = "renderCrosshair", index = 0, require = 0, at = @At(value = "INVOKE",
        target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/Identifier;IIII)V"))
    private RenderPipeline bleachskins$realColours(RenderPipeline pipeline) {
        return SkinManager.cfg.choices.containsKey("crosshair") ? RenderPipelines.GUI_TEXTURED : pipeline;
    }
}
