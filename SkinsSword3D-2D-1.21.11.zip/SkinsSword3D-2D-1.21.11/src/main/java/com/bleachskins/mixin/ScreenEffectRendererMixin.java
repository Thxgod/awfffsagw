package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.ScreenEffectRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.SubmitNodeCollector;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Size of the totem that pops up on screen, height of the fire while burning. */
@Mixin(ScreenEffectRenderer.class)
abstract class ScreenEffectRendererMixin {
    @Inject(method = "renderItemActivationAnimation", at = @At("HEAD"), cancellable = true)
    private void bleachskins$hidePop(PoseStack pose, float delta, SubmitNodeCollector nodes, CallbackInfo ci) {
        if (SkinManager.cfg.totemPopScale <= 0f) ci.cancel();
    }

    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void bleachskins$hideFire(PoseStack pose, MultiBufferSource buffers, TextureAtlasSprite sprite, CallbackInfo ci) {
        if (SkinManager.cfg.fireHeight <= 0f) ci.cancel();
    }

    /** low fire: pushes the on-screen flames down */
    @ModifyConstant(method = "renderFire", constant = @Constant(floatValue = -0.3f))
    private static float bleachskins$fireHeight(float vanilla) {
        return vanilla - (1f - SkinManager.cfg.fireHeight) * 0.6f;
    }

    @ModifyConstant(method = "renderItemActivationAnimation", constant = @Constant(floatValue = 0.8f))
    private float bleachskins$popSize(float vanilla) {
        return vanilla * SkinManager.cfg.totemPopScale;
    }
}
