package com.bleachskins.mixin;

import com.bleachskins.client.CustomizeScreen;
import com.bleachskins.client.MainScreen;
import com.bleachskins.client.Ui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Sliders inside this mod's menu are drawn as a glowing rail; everywhere else they stay the game's own. */
@Mixin(AbstractSliderButton.class)
abstract class SliderLookMixin {
    @Shadow protected double value;

    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void bleachskins$rail(GuiGraphics g, int mx, int my, float delta, CallbackInfo ci) {
        Screen s = Minecraft.getInstance().screen;
        if (!(s instanceof MainScreen || s instanceof CustomizeScreen)) return;
        ci.cancel();
        if ((Object) this instanceof Ui.SelfPainted) return;      // draws itself on top of the page
        AbstractWidget w = (AbstractWidget) (Object) this;
        Ui.rail(g, w.getX(), w.getY(), w.getWidth(), w.getHeight(), (float) value, w.getMessage().getString(), w.isHoveredOrFocused());
    }
}
