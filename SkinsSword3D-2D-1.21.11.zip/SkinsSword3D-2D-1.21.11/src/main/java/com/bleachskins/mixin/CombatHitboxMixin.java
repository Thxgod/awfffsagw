package com.bleachskins.mixin;

import com.bleachskins.client.CombatBox;
import net.minecraft.client.renderer.debug.EntityHitboxDebugRenderer;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hitbox colours: the entity under your crosshair changes colour, everything else stays normal. */
@Mixin(EntityHitboxDebugRenderer.class)
abstract class CombatHitboxMixin {
    @Unique private Entity bleachskins$entity;
    @Unique private boolean bleachskins$server;

    @Inject(method = "showHitboxes", at = @At("HEAD"), cancellable = true)
    private void bleachskins$start(Entity entity, float delta, boolean server, CallbackInfo ci) {
        bleachskins$entity = entity;
        bleachskins$server = server;
        if (CombatBox.hide(entity)) ci.cancel();
    }

    // the entity comes from the field above; the box you aim at also gets your colour strength and line width
    @Redirect(method = "showHitboxes", at = @At(value = "INVOKE", ordinal = 0,
        target = "Lnet/minecraft/gizmos/GizmoStyle;stroke(I)Lnet/minecraft/gizmos/GizmoStyle;"))
    private GizmoStyle bleachskins$style(int colour) {
        if (bleachskins$server || bleachskins$entity == null || !CombatBox.aimed(bleachskins$entity)) return GizmoStyle.stroke(colour);
        return GizmoStyle.stroke(CombatBox.colour(bleachskins$entity, colour), CombatBox.lineWidth());
    }
}
