package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import net.minecraft.client.multiplayer.ClientLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The smoke and bits that follow an explosion. */
@Mixin(ClientLevel.class)
abstract class ExplosionDebrisMixin {
    @Inject(method = "trackExplosionEffects", at = @At("HEAD"), cancellable = true)
    private void bleachskins$noDebris(CallbackInfo ci) {
        if (SkinManager.cfg != null && SkinManager.cfg.noExplosionFx) ci.cancel();
    }
}
