package com.bleachskins.mixin;

import com.bleachskins.client.QuietOverlay;
import com.bleachskins.client.SkinManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.client.gui.screens.Overlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Reloads started from our GUI use QuietOverlay instead of the full-screen loading logo. */
@Mixin(Minecraft.class)
abstract class MinecraftMixin {
    @ModifyVariable(method = "setOverlay", at = @At("HEAD"), argsOnly = true)
    private Overlay bleachskins$quietReload(Overlay overlay) {
        if (SkinManager.quietReload && overlay instanceof LoadingOverlay && !(overlay instanceof QuietOverlay)) {
            LoadingOverlayAccessor a = (LoadingOverlayAccessor) overlay;
            return new QuietOverlay((Minecraft) (Object) this, a.bleachskins$reload(), a.bleachskins$onFinish());
        }
        return overlay;
    }
}
