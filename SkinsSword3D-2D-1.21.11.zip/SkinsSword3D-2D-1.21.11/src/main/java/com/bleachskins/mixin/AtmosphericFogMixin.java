package com.bleachskins.mixin;

import com.bleachskins.client.FogTweak;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.fog.FogData;
import net.minecraft.client.renderer.fog.environment.AtmosphericFogEnvironment;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Marks this frame's fog as the normal fog in the air. */
@Mixin(AtmosphericFogEnvironment.class)
abstract class AtmosphericFogMixin {
    @Inject(method = "setupFog", at = @At("HEAD"))
    private void bleachskins$air(FogData data, Camera camera, ClientLevel level, float distance, DeltaTracker delta, CallbackInfo ci) {
        FogTweak.air = true;
    }
}
