package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No rain, snow or storm on your screen; only your own client sees clear weather. */
@Mixin(Level.class)
abstract class NoRainMixin {
    @Inject(method = {"getRainLevel", "getThunderLevel"}, at = @At("HEAD"), cancellable = true)
    private void bleachskins$clear(float delta, CallbackInfoReturnable<Float> cir) {
        if ((Object) this instanceof ClientLevel && SkinManager.cfg != null && SkinManager.cfg.noRain) cir.setReturnValue(0f);
    }
}
