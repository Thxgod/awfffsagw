package com.bleachskins.mixin;

import com.bleachskins.client.HeldSize;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Size of items held in first person, and the shrink while eating. Only changes what you see. */
@Mixin(ItemInHandRenderer.class)
abstract class HeldItemSizeMixin {
    @Inject(method = "renderItem", at = @At("HEAD"))
    private void bleachskins$sizeStart(LivingEntity entity, ItemStack stack, ItemDisplayContext ctx, PoseStack pose, SubmitNodeCollector nodes, int light, CallbackInfo ci) {
        pose.pushPose();
        float k = HeldSize.of(entity, stack, ctx);
        pose.scale(k, k, k);
    }

    @Inject(method = "renderItem", at = @At("RETURN"))
    private void bleachskins$sizeEnd(LivingEntity entity, ItemStack stack, ItemDisplayContext ctx, PoseStack pose, SubmitNodeCollector nodes, int light, CallbackInfo ci) {
        pose.popPose();
    }
}
