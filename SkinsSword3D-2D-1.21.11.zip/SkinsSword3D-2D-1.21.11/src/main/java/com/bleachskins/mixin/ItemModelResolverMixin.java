package com.bleachskins.mixin;

import com.bleachskins.client.RemoteSkins;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Swaps the model id right after the game reads it from the item, without touching the item. */
@Mixin(ItemModelResolver.class)
abstract class ItemModelResolverMixin {
    @ModifyVariable(method = "appendItemLayers", at = @At("STORE"), ordinal = 0)
    private Identifier bleachskins$heldSkin(Identifier id, ItemStackRenderState state, ItemStack stack, ItemDisplayContext ctx,
                                            Level level, ItemOwner owner, int seed) {
        return RemoteSkins.modelFor(RemoteSkins.cobweb(id), stack, ctx, owner);
    }
}
