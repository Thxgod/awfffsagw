package com.bleachskins.mixin;

import net.minecraft.client.gui.render.GuiRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Item icons are cached in their own texture, which has to be redrawn after a look changes. */
@Mixin(GuiRenderer.class)
public interface GuiRendererInvoker {
    @Invoker("invalidateItemAtlas") void bleachskins$invalidate();
}
