package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No big explosion clouds: they cover the screen and cost a lot of frames. */
@Mixin(ParticleEngine.class)
abstract class ExplosionFxMixin {
    @Inject(method = "createParticle", at = @At("HEAD"), cancellable = true)
    private void bleachskins$noExplosion(ParticleOptions options, double x, double y, double z, double dx, double dy, double dz, CallbackInfoReturnable<Particle> cir) {
        if (SkinManager.cfg == null || !SkinManager.cfg.noExplosionFx) return;
        var type = options.getType();
        if (type == ParticleTypes.EXPLOSION || type == ParticleTypes.EXPLOSION_EMITTER) cir.setReturnValue(null);
    }
}
