package com.bleachskins.mixin;

import com.bleachskins.client.SkinManager;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.renderer.LightTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;

/** Brightness beyond the game's 100%, used only where light is worked out, so the saved option stays valid. */
@Mixin(LightTexture.class)
abstract class GammaMixin {
    @Redirect(method = "updateLightTexture",
        slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/client/Options;gamma()Lnet/minecraft/client/OptionInstance;")),
        at = @At(value = "INVOKE", ordinal = 0, target = "Lnet/minecraft/client/OptionInstance;get()Ljava/lang/Object;"))
    private Object bleachskins$gamma(OptionInstance<?> option) {
        var cfg = SkinManager.cfg;
        return cfg != null && cfg.gammaOn ? Double.valueOf(cfg.gamma) : option.get();
    }
}
