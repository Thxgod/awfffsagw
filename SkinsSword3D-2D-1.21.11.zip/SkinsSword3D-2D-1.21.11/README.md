# Skins Sword 3D-2D (Fabric, Minecraft 1.21.11)

Drop any weapon resource pack (1.21.4+ item-definition format, incl. custom_model_data packs) into `bleachskins/packs/`
(or drag the zip onto the GUI). The mod lists every skin with a preview, and you equip them without enabling the pack
in the vanilla Resource Packs screen.

* Open: Mod Menu -> Skins Sword 3D-2D -> Configure, or press K (rebind in Controls).
* **3D viewer**: click the preview in the right panel -> big viewer, drag to turn the weapon 360 degrees; length / width /
  3D depth sliders update live.
* **Flat 2D sprites become real 3D**: "3D depth" turns every sprite pixel row into boxes (0 = vanilla flat).
* Customize: length, width, 3D depth, blade tint, effect (particle type, density, size, colour), swing sound
  (12 sounds, volume, pitch), combine two skins, save "my skins", separate left/right hand skins (visual only).
* Multiplayer: only players who ALSO have the mod (client + server) see your skin, particles and sounds. Players without the
  mod see vanilla items. A remote skin is only shown if you own the same pack; blade tint/length/3D depth are local to you.
  Packs tab has switches: share mine / show others' skins / show others' effects / others' volume.
* Themes: 9 presets, glass/flat style, translucent background picture (tint + opacity) in Theme tab.

How it works: the mod builds ONE resource pack, `resourcepacks/SkinsSword3D2D_Generated`, from your library and enables it.
The 360 viewer is a small software renderer (`ModelRaster`) that reads the same generated models.

Build: JDK 21, `gradle build` -> `build/libs/SkinsSword3D-2D-1.0.0.jar`. Not compiled/tested inside Minecraft yet: if a
build error appears (GuiGraphics.blit overload, DynamicTexture/NativeImage.setPixel, Matrix3x2fStack, ColorParticleOption,
BuiltInRegistries.SOUND_EVENT.getValue, versions in gradle.properties) it is a one-line fix.
